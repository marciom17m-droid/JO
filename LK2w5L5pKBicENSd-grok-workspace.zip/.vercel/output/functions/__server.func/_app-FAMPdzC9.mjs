import { o as __toESM } from "./_runtime.mjs";
import { S as Navigate, Z as require_react, _ as Outlet, m as useRouterState, w as require_jsx_runtime, x as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { i as signOut } from "./_ssr/client-1vAx-gM_.mjs";
import { _ as CalendarDays, d as ListChecks, f as Leaf, r as TreePine, t as Users, u as LogOut } from "./_libs/lucide-react.mjs";
import { E as useCurrentUserState, T as useCurrentUser, _ as initials, f as cx, n as Boot, r as Button } from "./_ssr/ui-DsFOv00P.mjs";
import { a as useWorkspace, t as WorkspaceProvider } from "./_ssr/store-g2R_JrHC.mjs";
import { a as hasGateSessionMarker } from "./_ssr/server-Bo98eTxU.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_app-FAMPdzC9.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* Auth state components — plain wrappers around `useCurrentUserState()`.
*
* With auth on, visitors are signed out until they authenticate — in the sandbox
* live preview too, which does real sign-in. The shared dev user appears only
* when auth is disabled (`VITE_AUTH_ENABLED=false`, the shipped default).
* While the session is still resolving, gates that care about signed-out state
* render nothing so there's no signed-out flash on hard reload.
*/
/** Where `RedirectToSignIn` sends signed-out visitors. Create this route. */
var SIGN_IN_PATH = "/login";
/**
* Client-side redirect to the sign-in route (TanStack `<Navigate>` — NOT a full
* `window.location` reload). A hard navigation re-bootstraps the SPA and re-runs
* session loading, which feels like a second "Loading…" on /login.
*
* Guard routes by waiting out `isPending` first (see `use-current-user`), then
* render this.
*/
function RedirectToSignIn({ to = SIGN_IN_PATH }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to });
}
var NAV = [
	{
		to: "/",
		label: "Hoje",
		icon: ListChecks,
		exact: true
	},
	{
		to: "/agenda",
		label: "Agenda",
		icon: CalendarDays,
		exact: false
	},
	{
		to: "/jardins",
		label: "Jardins",
		icon: TreePine,
		exact: false
	},
	{
		to: "/equipa",
		label: "Equipa",
		icon: Users,
		exact: false
	}
];
var subscribe = () => () => {};
function Identity() {
	const user = useCurrentUser();
	const [busy, setBusy] = (0, import_react.useState)(false);
	const gate = (0, import_react.useSyncExternalStore)(subscribe, hasGateSessionMarker, () => false);
	if (!user) return null;
	const label = user.displayName ?? user.primaryEmail ?? "Conta";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-2",
		children: [
			user.profileImageUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: user.profileImageUrl,
				alt: "",
				className: "h-9 w-9 rounded-full object-cover"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "grid h-9 w-9 place-items-center rounded-full bg-leaf-soft text-xs font-semibold text-leaf",
				children: initials(label)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "hidden max-w-32 truncate text-sm font-medium md:inline",
				children: label
			}),
			!gate ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				disabled: busy,
				onClick: () => {
					setBusy(true);
					signOut("/login").catch(() => setBusy(false));
				},
				className: "grid h-11 w-11 place-items-center rounded-lg text-muted hover:bg-paper hover:text-ink disabled:opacity-50",
				"aria-label": busy ? "A sair" : "Sair",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "h-4 w-4" })
			}) : null
		]
	});
}
function NavLink({ to, label, icon: Icon, exact, stacked }) {
	const pathname = useRouterState({ select: (state) => state.location.pathname });
	const active = exact ? pathname === to : pathname === to || pathname.startsWith(`${to}/`);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to,
		className: cx("flex items-center gap-2 rounded-lg text-sm font-semibold transition-colors", stacked ? "h-14 flex-1 flex-col justify-center gap-0.5 text-xs" : "h-11 px-3", active ? "bg-leaf-soft text-leaf" : "text-muted hover:bg-paper hover:text-ink"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-5 w-5" }), label]
	});
}
function Shell({ children }) {
	const { offline, stale, error } = useWorkspace();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh md:grid md:grid-cols-[15rem_minmax(0,1fr)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "hidden border-r border-line bg-card md:sticky md:top-0 md:flex md:h-dvh md:flex-col md:px-4 md:py-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "px-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-2xl leading-none text-leaf",
						children: "Jardins"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "e outros"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "mt-8 flex flex-col gap-1",
					children: NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLink, { ...item }, item.to))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-auto px-1",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Identity, {})
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "sticky top-0 z-20 flex items-center justify-between bg-paper/95 px-4 py-3 backdrop-blur md:hidden",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-xl text-leaf",
						children: "Jardins e outros"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Identity, {})]
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "bg-clay-soft px-4 py-2 text-center text-sm text-clay",
					children: error
				}) : offline || stale ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "bg-clay-soft px-4 py-2 text-center text-sm text-clay",
					children: offline ? "Sem ligação — a mostrar a última versão guardada neste telemóvel." : "A mostrar dados guardados. A ligação à equipa falhou."
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					className: "mx-auto w-full max-w-5xl px-4 pt-2 app-pad md:px-8 md:pt-8 md:pb-12",
					children
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "nav-safe fixed inset-x-0 bottom-0 z-30 flex border-t border-line bg-card md:hidden",
					children: NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLink, {
						...item,
						stacked: true
					}, item.to))
				})
			]
		})]
	});
}
function AppLayout() {
	const { user, isPending } = useCurrentUserState();
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setReady(true), []);
	if (!ready || isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Boot, {});
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WorkspaceProvider, {
		userId: user.id,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TeamGate, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }) })
	});
}
function TeamGate({ children }) {
	const { snap, loading } = useWorkspace();
	if (loading && !snap) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Boot, {});
	if (snap?.blocked) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WaitingRoom, {});
	return children;
}
function WaitingRoom() {
	const user = useCurrentUser();
	const [busy, setBusy] = (0, import_react.useState)(false);
	const email = user?.primaryEmail ?? "o teu email";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "grid min-h-dvh place-items-center bg-paper px-6 py-12",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-md rounded-xl border border-line bg-card p-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grid h-12 w-12 place-items-center rounded-xl bg-leaf text-card",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Leaf, { className: "h-6 w-6" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-4 font-display text-3xl",
					children: "Ainda não estás na equipa"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-sm text-muted",
					children: [
						"Pede a um colega para te convidar com ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-semibold text-ink",
							children: email
						}),
						". Quando o convite estiver feito, entra outra vez — ficas com as mesmas permissões que os outros."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "mt-5",
					variant: "secondary",
					disabled: busy,
					onClick: () => {
						setBusy(true);
						signOut("/login").catch(() => setBusy(false));
					},
					children: busy ? "A sair…" : "Sair"
				})
			]
		})
	});
}
//#endregion
export { AppLayout as component };
