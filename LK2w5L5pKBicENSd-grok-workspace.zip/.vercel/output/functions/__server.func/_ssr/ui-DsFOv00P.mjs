import { o as __toESM } from "../_runtime.mjs";
import { Z as require_react, w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as authClient } from "./client-1vAx-gM_.mjs";
import { f as Leaf } from "../_libs/lucide-react.mjs";
import { a as format, f as addDays, i as isToday, n as isYesterday, r as isTomorrow, t as pt, u as differenceInCalendarDays } from "../_libs/date-fns.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ui-DsFOv00P.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* Current user + loading state. Same behavior in live preview and when deployed:
*   - Auth enabled -> the real signed-in user; `user` is `null` while
*                            the session resolves (`isPending: true`) and when
*                            signed out (`isPending: false`). Session comes from
*                            Better Auth `useSession()` → `/api/auth/get-session`
*                            (cookie when deployed; bearer in live preview).
*   - Auth disabled (`VITE_AUTH_ENABLED=false`) -> `DEV_USER`, never pending.
*
* Protect a route by waiting out `isPending` before acting on `user` —
* redirecting on `user: null` alone bounces signed-in visitors to sign-in on
* every hard reload:
*
*   import { RedirectToSignIn } from "@/lib/auth/gates";
*   const { user, isPending } = useCurrentUserState();
*   if (isPending) return null;              // still resolving — don't redirect yet
*   if (!user) return <RedirectToSignIn />;  // definitely signed out
*
* `authEnabled` is a module-level constant fixed at load, so the guarded hook
* call keeps a stable hook order across every render of a given component.
*/
function useCurrentUserState() {
	return useSessionUserState();
}
function useSessionUserState() {
	const { data, isPending } = authClient.useSession();
	const id = data?.user.id;
	const displayName = data?.user.name ?? null;
	const primaryEmail = data?.user.email ?? null;
	const profileImageUrl = data?.user.image ?? null;
	const user = (0, import_react.useMemo)(() => id ? {
		id,
		displayName,
		primaryEmail,
		profileImageUrl,
		isDevFallback: false
	} : null, [
		id,
		displayName,
		primaryEmail,
		profileImageUrl
	]);
	return (0, import_react.useMemo)(() => ({
		user,
		isPending
	}), [user, isPending]);
}
/**
* Convenience view of `useCurrentUserState().user` for display (e.g.
* `user?.displayName ?? "Guest"`). NOTE: `null` means *loading OR signed out* —
* for redirects/guards use `useCurrentUserState()` and check `isPending`.
*/
function useCurrentUser() {
	return useCurrentUserState().user;
}
function ymd(date) {
	return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}
function parseDay(iso) {
	const [y, m, d] = iso.split("-").map(Number);
	return new Date(y, (m ?? 1) - 1, d ?? 1);
}
function addDay(iso, days) {
	return ymd(addDays(parseDay(iso), days));
}
function todayIso() {
	return ymd(/* @__PURE__ */ new Date());
}
function weekdayStart(iso) {
	const date = parseDay(iso);
	const day = date.getDay();
	const delta = day === 0 ? -6 : 1 - day;
	return ymd(addDays(date, delta));
}
function dayLabel(iso) {
	const date = parseDay(iso);
	if (isToday(date)) return "Hoje";
	if (isTomorrow(date)) return "Amanhã";
	if (isYesterday(date)) return "Ontem";
	return format(date, "EEE, d MMM", { locale: pt }).replace(".", "");
}
function longDate(iso) {
	const label = format(parseDay(iso), "EEEE, d 'de' MMMM", { locale: pt });
	return label.charAt(0).toUpperCase() + label.slice(1);
}
function monthTitle(iso) {
	const label = format(parseDay(iso), "MMMM yyyy", { locale: pt });
	return label.charAt(0).toUpperCase() + label.slice(1);
}
function shortWeekday(iso) {
	const label = format(parseDay(iso), "EEE", { locale: pt }).replace(".", "");
	return label.charAt(0).toUpperCase() + label.slice(1);
}
function greeting(name) {
	const hour = (/* @__PURE__ */ new Date()).getHours();
	const hello = hour < 12 ? "Bom dia" : hour < 19 ? "Boa tarde" : "Boa noite";
	const first = (name ?? "").trim().split(/\s+/)[0];
	return first ? `${hello}, ${first}` : hello;
}
function initials(name) {
	const parts = name.trim().split(/\s+/).filter(Boolean);
	if (parts.length === 0) return "?";
	if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
	return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}
function formatMinutes(total) {
	if (total <= 0) return "0 min";
	const h = Math.floor(total / 60);
	const m = total % 60;
	if (h === 0) return `${m} min`;
	if (m === 0) return `${h} h`;
	return `${h} h ${m} min`;
}
function interventionCopy(iso) {
	if (!iso) return {
		lead: "Ainda sem intervenção",
		when: "",
		stale: true
	};
	const days = differenceInCalendarDays(parseDay(todayIso()), parseDay(iso));
	let rel = "hoje";
	if (days === 1) rel = "ontem";
	else if (days > 1 && days < 14) rel = `há ${days} dias`;
	else if (days >= 14 && days < 60) {
		const weeks = Math.floor(days / 7);
		rel = weeks === 1 ? "há 1 semana" : `há ${weeks} semanas`;
	} else if (days >= 60 && days < 365) {
		const months = Math.max(1, Math.floor(days / 30));
		rel = months === 1 ? "há 1 mês" : `há ${months} meses`;
	} else if (days >= 365) {
		const years = Math.floor(days / 365);
		rel = years === 1 ? "há 1 ano" : `há ${years} anos`;
	} else if (days < 0) rel = "hoje";
	const when = format(parseDay(iso), "d MMM yyyy", { locale: pt }).replace(/\./g, "");
	return {
		lead: `Última vez ${rel}`,
		when,
		stale: days >= 21
	};
}
function mapsUrl(location) {
	return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(location)}`;
}
var STATUS_LABEL = {
	ativo: "Ativo",
	pausado: "Pausado",
	sazonal: "Sazonal",
	concluido: "Concluído",
	agendada: "Agendada",
	feita: "Feita"
};
var SERVICE_LABEL = {
	corte: "Corte de relva",
	poda: "Poda",
	rega: "Rega",
	plantacao: "Plantação",
	limpeza: "Limpeza",
	adubacao: "Adubação",
	bordaduras: "Bordaduras",
	outro: "Outro"
};
function cx(...parts) {
	return parts.filter(Boolean).join(" ");
}
function Boot() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "grid min-h-dvh place-items-center bg-leaf px-6 text-card",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col items-center gap-3 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grid h-14 w-14 place-items-center rounded-xl bg-card text-leaf",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Leaf, { className: "h-7 w-7" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl",
					children: "Jardins e outros"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-leaf-soft",
					children: "A abrir o caderno da equipa…"
				})
			]
		})
	});
}
function Button({ variant = "primary", className, type = "button", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		className: cx("inline-flex h-11 items-center justify-center gap-2 rounded-lg px-4 text-sm font-semibold transition-colors disabled:cursor-not-allowed disabled:opacity-50", variant === "primary" && "bg-leaf text-card hover:bg-leaf-bright", variant === "secondary" && "border border-line bg-card text-ink hover:bg-paper", variant === "ghost" && "text-ink hover:bg-leaf-soft", variant === "danger" && "bg-clay text-card hover:bg-clay/90", variant === "soft" && "bg-leaf-soft text-leaf hover:bg-leaf-soft/70", className),
		...props
	});
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block space-y-1.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-sm font-medium text-ink",
			children: label
		}), children]
	});
}
var fieldClass = "h-11 w-full rounded-lg border border-line bg-card px-3 text-ink outline-none placeholder:text-muted/70";
function TextArea({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cx(fieldClass, "h-24 py-2", className),
		...props
	});
}
function Sheet({ open, title, onClose, children }) {
	if (!open) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-40",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			"aria-label": "Fechar",
			className: "absolute inset-0 bg-ink/40",
			onClick: onClose
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-modal": "true",
			"aria-label": title,
			className: "absolute inset-x-0 bottom-0 max-h-[92dvh] overflow-y-auto rounded-t-xl bg-paper px-4 pt-4 pb-6 shadow-xl md:inset-auto md:top-1/2 md:left-1/2 md:w-full md:max-w-lg md:-translate-x-1/2 md:-translate-y-1/2 md:rounded-xl",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl text-ink",
					children: title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onClose,
					className: "grid h-11 w-11 place-items-center rounded-lg text-muted hover:bg-card",
					"aria-label": "Fechar",
					children: "×"
				})]
			}), children]
		})]
	});
}
function Pill({ children, tone = "leaf" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cx("inline-flex items-center rounded-full px-2.5 py-1 text-xs font-semibold", tone === "leaf" && "bg-leaf-soft text-leaf", tone === "clay" && "bg-clay-soft text-clay", tone === "muted" && "bg-paper text-muted ring-1 ring-line"),
		children
	});
}
function Avatars({ members, ids }) {
	const people = ids.map((id) => members.find((member) => member.id === id)).filter((member) => Boolean(member));
	if (!people.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "text-xs text-muted",
		children: "Sem pessoas"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "flex items-center gap-1",
		children: people.map((person) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			title: person.name,
			className: "grid h-7 w-7 place-items-center rounded-full bg-leaf-soft text-xs font-semibold text-leaf",
			children: initials(person.name)
		}, person.id))
	});
}
function Empty({ title, body, action }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border border-dashed border-line bg-card px-5 py-8 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-display text-xl text-ink",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mx-auto mt-2 max-w-sm text-sm text-muted",
				children: body
			}),
			action ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 flex justify-center",
				children: action
			}) : null
		]
	});
}
//#endregion
export { shortWeekday as C, weekdayStart as D, useCurrentUserState as E, ymd as O, parseDay as S, useCurrentUser as T, initials as _, Field as a, mapsUrl as b, STATUS_LABEL as c, addDay as d, cx as f, greeting as g, formatMinutes as h, Empty as i, Sheet as l, fieldClass as m, Boot as n, Pill as o, dayLabel as p, Button as r, SERVICE_LABEL as s, Avatars as t, TextArea as u, interventionCopy as v, todayIso as w, monthTitle as x, longDate as y };
