import { o as __toESM } from "../_runtime.mjs";
import { Z as require_react, w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { m as ChevronLeft, p as ChevronRight, s as Plus } from "../_libs/lucide-react.mjs";
import { c as eachDayOfInterval, d as startOfWeek, f as addDays, l as endOfMonth, o as endOfWeek, s as startOfMonth } from "../_libs/date-fns.mjs";
import { C as shortWeekday, D as weekdayStart, O as ymd, S as parseDay, d as addDay, f as cx, i as Empty, r as Button, w as todayIso, x as monthTitle, y as longDate } from "./ui-DsFOv00P.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as useWorkspace } from "./store-g2R_JrHC.mjs";
import { n as LogSheet, r as TaskSheet } from "./sheets-DcH8jWP5.mjs";
import { t as TaskCard } from "./task-card-DcsBSUsK.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/agenda-y7DRgW70.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AgendaPage() {
	const { snap, markDone, postpone, removeTask } = useWorkspace();
	const [cursor, setCursor] = (0, import_react.useState)(todayIso());
	const [selected, setSelected] = (0, import_react.useState)(todayIso());
	const [mode, setMode] = (0, import_react.useState)("semana");
	const [open, setOpen] = (0, import_react.useState)(false);
	const [editing, setEditing] = (0, import_react.useState)(null);
	const [logging, setLogging] = (0, import_react.useState)(null);
	const tasks = snap?.tasks ?? [];
	const members = snap?.members ?? [];
	const gardens = snap?.gardens ?? [];
	const availability = snap?.availability ?? [];
	const weekDays = (0, import_react.useMemo)(() => {
		const start = weekdayStart(mode === "semana" ? selected : cursor);
		return Array.from({ length: 7 }, (_, index) => addDay(start, index));
	}, [
		mode,
		selected,
		cursor
	]);
	const monthDays = (0, import_react.useMemo)(() => {
		const anchor = parseDay(cursor);
		const start = startOfWeek(startOfMonth(anchor), { weekStartsOn: 1 });
		const end = endOfWeek(endOfMonth(anchor), { weekStartsOn: 1 });
		return eachDayOfInterval({
			start,
			end
		}).map(ymd);
	}, [cursor]);
	const dayTasks = tasks.filter((task) => task.scheduledDate === selected);
	const gardenName = (id) => gardens.find((garden) => garden.id === id)?.name;
	function shift(dir) {
		if (mode === "semana") {
			const next = addDay(selected, dir * 7);
			setSelected(next);
			setCursor(next);
			return;
		}
		const next = ymd(addDays(startOfMonth(parseDay(cursor)), dir > 0 ? 32 : -1));
		const landed = ymd(startOfMonth(parseDay(next)));
		setCursor(landed);
		setSelected(landed);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-4xl",
					children: "Agenda"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Tarefas marcadas, feitas e quem está livre."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-2 rounded-lg bg-card p-1 ring-1 ring-line",
						children: ["semana", "mes"].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setMode(item),
							className: cx("h-10 rounded-md px-3 text-sm font-semibold", mode === item ? "bg-leaf text-card" : "text-muted"),
							children: item === "semana" ? "Semana" : "Mês"
						}, item))
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: () => {
							setEditing(null);
							setOpen(true);
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), "Tarefa"]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "grid h-11 w-11 place-items-center rounded-lg hover:bg-card",
						onClick: () => shift(-1),
						"aria-label": "Anterior",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "h-5 w-5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-2xl capitalize",
						children: mode === "mes" ? monthTitle(cursor) : longDate(selected)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "grid h-11 w-11 place-items-center rounded-lg hover:bg-card",
						onClick: () => shift(1),
						"aria-label": "Seguinte",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-5 w-5" })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-[minmax(0,1fr)_22rem]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [mode === "semana" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-7 gap-1",
					children: weekDays.map((day) => {
						const count = tasks.filter((task) => task.scheduledDate === day);
						const people = availability.filter((slot) => slot.day === day && (slot.morning || slot.afternoon));
						const on = day === selected;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setSelected(day),
							className: cx("flex min-h-20 flex-col items-center rounded-lg px-1 py-2", on ? "bg-leaf text-card" : "bg-card text-ink ring-1 ring-line"),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: cx("text-xs", on ? "text-leaf-soft" : "text-muted"),
									children: shortWeekday(day)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-display text-lg tabular-nums",
									children: parseDay(day).getDate()
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "mt-1 flex h-2 gap-0.5",
									children: [count.some((task) => task.status !== "feita") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: cx("h-1.5 w-1.5 rounded-full", on ? "bg-card" : "bg-leaf") }) : null, count.some((task) => task.status === "feita") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: cx("h-1.5 w-1.5 rounded-full", on ? "bg-leaf-soft" : "bg-clay") }) : null]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: cx("text-xs", on ? "text-leaf-soft" : "text-muted"),
									children: people.length || ""
								})
							]
						}, day);
					})
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mb-1 grid grid-cols-7 text-center text-xs font-semibold text-muted",
					children: weekDays.map((day) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: shortWeekday(day) }, day))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-7 gap-1",
					children: monthDays.map((day) => {
						const inMonth = parseDay(day).getMonth() === parseDay(cursor).getMonth();
						const count = tasks.filter((task) => task.scheduledDate === day);
						const on = day === selected;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setSelected(day),
							className: cx("flex min-h-14 flex-col items-center justify-center rounded-lg text-sm tabular-nums", on ? "bg-leaf text-card" : "bg-card ring-1 ring-line", !inMonth && !on && "opacity-40"),
							children: [parseDay(day).getDate(), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "mt-1 flex h-1.5 gap-0.5",
								children: [count.some((task) => task.status !== "feita") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: cx("h-1.5 w-1.5 rounded-full", on ? "bg-card" : "bg-leaf") }) : null, count.some((task) => task.status === "feita") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: cx("h-1.5 w-1.5 rounded-full", on ? "bg-leaf-soft" : "bg-clay") }) : null]
							})]
						}, day);
					})
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 flex flex-wrap gap-3 text-xs text-muted",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "inline-flex items-center gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: "h-2 w-2 rounded-full bg-leaf" }), " Por fazer"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "inline-flex items-center gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: "h-2 w-2 rounded-full bg-clay" }), " Feita"]
					})]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "space-y-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl",
						children: longDate(selected)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AvailabilityLine, { day: selected })] }), dayTasks.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
						title: "Nada marcado",
						body: "Este dia ainda não tem tarefas. Podes marcar vários jardins de uma vez.",
						action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: () => {
								setEditing(null);
								setOpen(true);
							},
							children: "Marcar neste dia"
						})
					}) : dayTasks.map((task) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TaskCard, {
						task,
						gardenName: gardenName(task.gardenId),
						members,
						onDone: () => void markDone(task.id, task.status !== "feita"),
						onPostpone: (date) => {
							postpone(task.id, date).then((ok) => ok && toast.success("Tarefa adiada"));
						},
						onEdit: () => {
							setEditing(task);
							setOpen(true);
						},
						onLog: () => setLogging(task),
						onDelete: () => void removeTask(task.id)
					}, task.id))]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TaskSheet, {
				open,
				task: editing,
				initialDate: selected,
				members,
				gardens,
				onClose: () => setOpen(false)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogSheet, {
				open: Boolean(logging),
				task: logging,
				onClose: () => setLogging(null)
			})
		]
	});
}
function AvailabilityLine({ day }) {
	const { snap } = useWorkspace();
	const slots = (snap?.availability ?? []).filter((slot) => slot.day === day && (slot.morning || slot.afternoon));
	if (!slots.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted",
		children: "Sem disponibilidade marcada."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "text-sm text-muted",
		children: [
			"Livres:",
			" ",
			slots.map((slot) => {
				const name = snap?.members.find((member) => member.id === slot.userId)?.name ?? "Colega";
				const when = slot.morning && slot.afternoon ? "dia" : slot.morning ? "manhã" : "tarde";
				return `${name.split(" ")[0]} (${when})`;
			}).join(", ")
		]
	});
}
//#endregion
export { AgendaPage as component };
