import { o as __toESM } from "../_runtime.mjs";
import { Z as require_react, w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { T as useCurrentUser, a as Field, c as STATUS_LABEL, f as cx, l as Sheet, m as fieldClass, r as Button, s as SERVICE_LABEL, u as TextArea } from "./ui-DsFOv00P.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as useWorkspace } from "./store-g2R_JrHC.mjs";
import { n as SERVICE_TYPES, t as GARDEN_STATUSES } from "./types-LTjSWxWC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/sheets-DcH8jWP5.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var MAX_EDGE = 1280;
var MAX_CHARS = 55e4;
function compressImage(file) {
	return new Promise((resolve, reject) => {
		const url = URL.createObjectURL(file);
		const img = new Image();
		img.onload = () => {
			const scale = Math.min(1, MAX_EDGE / Math.max(img.width, img.height));
			const width = Math.max(1, Math.round(img.width * scale));
			const height = Math.max(1, Math.round(img.height * scale));
			const canvas = document.createElement("canvas");
			canvas.width = width;
			canvas.height = height;
			const ctx = canvas.getContext("2d");
			if (!ctx) {
				URL.revokeObjectURL(url);
				reject(/* @__PURE__ */ new Error("Não foi possível tratar a foto."));
				return;
			}
			ctx.drawImage(img, 0, 0, width, height);
			const data = canvas.toDataURL("image/jpeg", .72);
			URL.revokeObjectURL(url);
			if (!data.startsWith("data:image/jpeg") || data.length > MAX_CHARS) {
				reject(/* @__PURE__ */ new Error("A foto ficou demasiado grande. Tenta outra, mais próxima."));
				return;
			}
			resolve(data);
		};
		img.onerror = () => {
			URL.revokeObjectURL(url);
			reject(/* @__PURE__ */ new Error("Não foi possível ler esta imagem."));
		};
		img.src = url;
	});
}
function GardenSheet({ open, garden, onClose }) {
	const { saveGarden } = useWorkspace();
	const [name, setName] = (0, import_react.useState)("");
	const [location, setLocation] = (0, import_react.useState)("");
	const [notes, setNotes] = (0, import_react.useState)("");
	const [status, setStatus] = (0, import_react.useState)("ativo");
	const [busy, setBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		setName(garden?.name ?? "");
		setLocation(garden?.location ?? "");
		setNotes(garden?.notes ?? "");
		setStatus(garden?.status ?? "ativo");
	}, [open, garden]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
		open,
		title: garden ? "Editar jardim" : "Novo jardim",
		onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "space-y-4",
			onSubmit: (event) => {
				event.preventDefault();
				setBusy(true);
				saveGarden({
					id: garden?.id,
					name,
					location,
					notes,
					status
				}).then((ok) => {
					setBusy(false);
					if (ok) {
						toast.success(garden ? "Jardim atualizado" : "Jardim criado");
						onClose();
					}
				});
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Nome",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: fieldClass,
						value: name,
						onChange: (e) => setName(e.target.value),
						required: true,
						maxLength: 120,
						placeholder: "Quinta da Ribeira"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Localização",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: fieldClass,
						value: location,
						onChange: (e) => setLocation(e.target.value),
						maxLength: 240,
						placeholder: "Rua, freguesia ou coordenadas"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Estado",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: fieldClass,
						value: status,
						onChange: (e) => setStatus(e.target.value),
						children: GARDEN_STATUSES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: item,
							children: STATUS_LABEL[item]
						}, item))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Notas",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextArea, {
						value: notes,
						onChange: (e) => setNotes(e.target.value),
						placeholder: "Portão lateral, cão no jardim, rega automática…"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						className: "flex-1",
						onClick: onClose,
						children: "Cancelar"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						className: "flex-1",
						disabled: busy,
						children: busy ? "A guardar…" : "Guardar"
					})]
				})
			]
		})
	});
}
function TaskSheet({ open, task, initialDate, initialGardenId, members, gardens, onClose }) {
	const { saveTask } = useWorkspace();
	const user = useCurrentUser();
	const [title, setTitle] = (0, import_react.useState)("");
	const [gardenId, setGardenId] = (0, import_react.useState)("");
	const [date, setDate] = (0, import_react.useState)("");
	const [notes, setNotes] = (0, import_react.useState)("");
	const [assignees, setAssignees] = (0, import_react.useState)([]);
	const [busy, setBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		setTitle(task?.title ?? "");
		setGardenId(task?.gardenId ?? initialGardenId ?? "");
		setDate(task?.scheduledDate ?? initialDate ?? "");
		setNotes(task?.notes ?? "");
		setAssignees(task?.assigneeIds?.length ? task.assigneeIds : user?.id ? [user.id] : []);
	}, [
		open,
		task,
		initialDate,
		initialGardenId,
		user?.id
	]);
	function toggle(id) {
		setAssignees((current) => current.includes(id) ? current.filter((item) => item !== id) : [...current, id]);
	}
	function submit(andAnother) {
		setBusy(true);
		saveTask({
			id: task?.id,
			title,
			gardenId: gardenId || null,
			scheduledDate: date,
			notes,
			assigneeIds: assignees
		}).then((ok) => {
			setBusy(false);
			if (!ok) return;
			toast.success(task ? "Tarefa atualizada" : "Tarefa marcada");
			if (andAnother && !task) {
				setTitle("");
				setNotes("");
				return;
			}
			onClose();
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
		open,
		title: task ? "Editar tarefa" : "Nova tarefa",
		onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "space-y-4",
			onSubmit: (event) => {
				event.preventDefault();
				submit(false);
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "O que há a fazer",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: fieldClass,
						value: title,
						onChange: (e) => setTitle(e.target.value),
						required: true,
						maxLength: 160,
						placeholder: "Corte, bordaduras e sopro"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Dia",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: fieldClass,
							type: "date",
							value: date,
							onChange: (e) => setDate(e.target.value),
							required: true
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Jardim",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: fieldClass,
							value: gardenId,
							onChange: (e) => setGardenId(e.target.value),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "Sem jardim associado"
							}), gardens.map((garden) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: garden.id,
								children: garden.name
							}, garden.id))]
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
						className: "mb-1.5 text-sm font-medium",
						children: "Quem vai"
					}),
					members.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Ainda só estás tu. A tarefa fica contigo."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-2",
						children: members.map((member) => {
							const on = assignees.includes(member.id);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-pressed": on,
								onClick: () => toggle(member.id),
								className: cx("h-11 rounded-full px-3 text-sm font-semibold", on ? "bg-leaf text-card" : "border border-line bg-card text-ink"),
								children: member.name
							}, member.id);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-xs text-muted",
						children: "Podes atribuir a uma ou várias pessoas. Se não escolheres ninguém, fica contigo."
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Notas",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextArea, {
						value: notes,
						onChange: (e) => setNotes(e.target.value),
						placeholder: "Levar o aparador de sebes."
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-2 sm:flex-row",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "secondary",
							onClick: onClose,
							children: "Cancelar"
						}),
						!task ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "soft",
							disabled: busy,
							onClick: () => submit(true),
							children: "Guardar e outra"
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							className: "sm:ml-auto",
							disabled: busy,
							children: busy ? "A guardar…" : "Guardar"
						})
					]
				})
			]
		})
	});
}
function LogSheet({ open, task, onClose }) {
	const { snap, saveLog } = useWorkspace();
	const [minutes, setMinutes] = (0, import_react.useState)("");
	const [serviceType, setServiceType] = (0, import_react.useState)("");
	const [materials, setMaterials] = (0, import_react.useState)("");
	const [notes, setNotes] = (0, import_react.useState)("");
	const [photos, setPhotos] = (0, import_react.useState)([]);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const user = useCurrentUser();
	const existing = snap?.logs.find((log) => log.taskId === task?.id && log.userId === user?.id);
	(0, import_react.useEffect)(() => {
		if (!open || !task) return;
		const mine = snap?.logs.find((log) => log.taskId === task.id && log.userId === user?.id);
		setMinutes(mine?.minutes != null ? String(mine.minutes) : "");
		setServiceType(mine?.serviceType ?? "");
		setMaterials(mine?.materials ?? "");
		setNotes(mine?.notes ?? "");
		setPhotos([]);
	}, [
		open,
		task,
		snap?.logs,
		user?.id
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
		open,
		title: "Registo do trabalho",
		onClose,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mb-4 text-sm text-muted",
			children: [
				"Opcional. Serve para ficar o rasto do que foi feito em ",
				task?.title ?? "esta tarefa",
				".",
				existing?.photoCount ? ` Já há ${existing.photoCount} foto(s).` : ""
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "space-y-4",
			onSubmit: (event) => {
				event.preventDefault();
				if (!task) return;
				setBusy(true);
				saveLog({
					taskId: task.id,
					minutes: minutes === "" ? null : Number(minutes),
					serviceType,
					materials,
					notes,
					photos
				}).then((ok) => {
					setBusy(false);
					if (ok) {
						toast.success("Registo guardado");
						onClose();
					}
				});
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Tempo (minutos)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: fieldClass,
							inputMode: "numeric",
							value: minutes,
							onChange: (e) => setMinutes(e.target.value),
							placeholder: "90"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Tipo de serviço",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: fieldClass,
							value: serviceType,
							onChange: (e) => setServiceType(e.target.value),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "Não indicar"
							}), SERVICE_TYPES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: item,
								children: SERVICE_LABEL[item]
							}, item))]
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Materiais",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: fieldClass,
						value: materials,
						onChange: (e) => setMaterials(e.target.value),
						placeholder: "Adubo, tutor, saco de relva"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Notas",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextArea, {
						value: notes,
						onChange: (e) => setNotes(e.target.value),
						placeholder: "O que ficou feito, o que falta, alguma avaria."
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
					label: "Fotos",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "block w-full text-sm text-muted file:mr-3 file:h-11 file:rounded-lg file:border-0 file:bg-leaf-soft file:px-3 file:font-semibold file:text-leaf",
						type: "file",
						accept: "image/*",
						multiple: true,
						onChange: (event) => {
							const files = [...event.target.files ?? []].slice(0, 4);
							event.target.value = "";
							Promise.all(files.map((file) => compressImage(file))).then((urls) => setPhotos((current) => [...current, ...urls].slice(0, 4))).catch((err) => {
								toast.error(err instanceof Error ? err.message : "Foto inválida");
							});
						}
					}), photos.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-2 flex gap-2",
						children: photos.map((src) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src,
							alt: "",
							className: "h-16 w-16 rounded-lg object-cover"
						}, src.slice(0, 48)))
					}) : null]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					className: "w-full",
					disabled: busy || !task,
					children: busy ? "A guardar…" : "Guardar registo"
				})
			]
		})]
	});
}
//#endregion
export { compressImage as i, LogSheet as n, TaskSheet as r, GardenSheet as t };
