import { o as __toESM } from "../_runtime.mjs";
import { S as Navigate, Z as require_react, w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as signIn, t as authClient } from "./client-1vAx-gM_.mjs";
import { f as Leaf } from "../_libs/lucide-react.mjs";
import { E as useCurrentUserState, f as cx, m as fieldClass, r as Button } from "./ui-DsFOv00P.mjs";
import { t as GROK_PROVIDERS } from "./server-Bo98eTxU.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/login-LpXX7YiK.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var BEARER_KEY = "grok-auth.bearer-token";
function authMessage(raw) {
	const message = (raw ?? "").toLowerCase();
	if (message.includes("invalid") || message.includes("password") || message.includes("credential")) return "Email ou palavra-passe incorretos.";
	if (message.includes("exist") || message.includes("already")) return "Já existe uma conta com este email.";
	if (message.includes("short")) return "A palavra-passe tem de ter pelo menos 8 caracteres.";
	if (message.includes("origin")) return "Não foi possível iniciar sessão neste endereço.";
	if (message.includes("pop")) return "O navegador bloqueou a janela. Permite pop-ups e tenta outra vez.";
	return "Não foi possível entrar. Tenta outra vez.";
}
async function adopt(token) {
	if (token) try {
		sessionStorage.setItem(BEARER_KEY, token);
	} catch {}
	await authClient.getSession();
	window.location.href = "/";
}
function LoginPage() {
	const { user, isPending } = useCurrentUserState();
	const [mode, setMode] = (0, import_react.useState)("entrar");
	const [name, setName] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	if (!isPending && user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "min-h-dvh md:grid md:grid-cols-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "bg-leaf px-6 py-10 text-card md:flex md:flex-col md:justify-between md:px-12 md:py-14",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grid h-12 w-12 place-items-center rounded-xl bg-card text-leaf",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Leaf, { className: "h-6 w-6" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-6 font-display text-4xl leading-tight md:text-5xl",
					children: "Jardins e outros"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 max-w-sm text-base text-leaf-soft",
					children: "O caderno de campo da equipa. Jardins, dias de trabalho e quem está disponível — tudo no mesmo sítio."
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "mt-8 hidden space-y-3 text-sm md:block",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Marca vários jardins para o mesmo dia." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Atribui o trabalho a uma ou mais pessoas." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Vê a manhã e a tarde de toda a equipa." })
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "flex items-center px-5 py-8 md:px-12",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto w-full max-w-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-2 rounded-lg bg-card p-1 ring-1 ring-line",
						children: ["entrar", "criar"].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => {
								setMode(item);
								setError(null);
							},
							className: cx("h-11 rounded-md text-sm font-semibold", mode === item ? "bg-leaf text-card" : "text-muted"),
							children: item === "entrar" ? "Entrar" : "Criar conta"
						}, item))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "mt-6 space-y-3",
						onSubmit: (event) => {
							event.preventDefault();
							setBusy(true);
							setError(null);
							(mode === "criar" ? authClient.signUp.email({
								email,
								password,
								name: name.trim(),
								callbackURL: "/"
							}) : authClient.signIn.email({
								email,
								password
							})).then(async (result) => {
								if (result.error) {
									setError(authMessage(result.error.message));
									setBusy(false);
									return;
								}
								await adopt(result.data?.token);
							}).catch((err) => {
								setError(authMessage(err instanceof Error ? err.message : null));
								setBusy(false);
							});
						},
						children: [
							mode === "criar" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block space-y-1.5 text-sm font-medium",
								children: ["Nome", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: fieldClass,
									value: name,
									onChange: (e) => setName(e.target.value),
									required: true,
									autoComplete: "name",
									placeholder: "O teu nome"
								})]
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block space-y-1.5 text-sm font-medium",
								children: ["Email", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: fieldClass,
									type: "email",
									value: email,
									onChange: (e) => setEmail(e.target.value),
									required: true,
									autoComplete: "email",
									placeholder: "nome@email.pt"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block space-y-1.5 text-sm font-medium",
								children: ["Palavra-passe", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: fieldClass,
									type: "password",
									value: password,
									onChange: (e) => setPassword(e.target.value),
									required: true,
									minLength: 8,
									autoComplete: mode === "criar" ? "new-password" : "current-password",
									placeholder: "Pelo menos 8 caracteres"
								})]
							}),
							error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-clay",
								children: error
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "submit",
								className: "w-full",
								disabled: busy,
								children: busy ? "A aguardar…" : mode === "criar" ? "Criar conta" : "Entrar"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "my-5 flex items-center gap-3 text-xs text-muted",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-px flex-1 bg-line" }),
							"ou",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-px flex-1 bg-line" })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-2",
						children: GROK_PROVIDERS.map((provider) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "secondary",
							className: "w-full",
							onClick: () => {
								setError(null);
								signIn(provider.providerId, { callbackURL: "/" }).catch((err) => {
									setError(authMessage(err instanceof Error ? err.message : null));
								});
							},
							children: ["Continuar com ", provider.label]
						}, provider.providerId))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 text-sm text-muted",
						children: "A primeira conta abre a equipa. As seguintes entram quando um colega as convida pelo email — todas com as mesmas permissões."
					})
				]
			})
		})]
	});
}
//#endregion
export { LoginPage as component };
