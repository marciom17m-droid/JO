import { o as __toESM } from "../_runtime.mjs";
import { Z as require_react, w as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Search, l as MapPin, s as Plus } from "../_libs/lucide-react.mjs";
import { b as mapsUrl, c as STATUS_LABEL, f as cx, i as Empty, o as Pill, r as Button, v as interventionCopy } from "./ui-DsFOv00P.mjs";
import { a as useWorkspace } from "./store-g2R_JrHC.mjs";
import { t as GardenSheet } from "./sheets-DcH8jWP5.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/jardins-C6QJdcB4.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var FILTERS = [
	{
		id: "todos",
		label: "Todos"
	},
	{
		id: "ativo",
		label: "Ativos"
	},
	{
		id: "pausado",
		label: "Pausados"
	},
	{
		id: "sazonal",
		label: "Sazonais"
	},
	{
		id: "concluido",
		label: "Concluídos"
	}
];
var SORTS = [
	{
		id: "antiga",
		label: "Mais tempo sem intervenção"
	},
	{
		id: "recente",
		label: "Intervenção mais recente"
	},
	{
		id: "nome-asc",
		label: "Nome (A–Z)"
	},
	{
		id: "nome-desc",
		label: "Nome (Z–A)"
	}
];
var SORT_KEY = "jardins.sort";
function readSort() {
	try {
		const raw = localStorage.getItem(SORT_KEY);
		if (SORTS.some((item) => item.id === raw)) return raw;
	} catch {}
	return "antiga";
}
function byName(a, b) {
	return a.name.localeCompare(b.name, "pt");
}
function compareGardens(a, b, sort) {
	if (sort === "nome-asc") return byName(a, b);
	if (sort === "nome-desc") return byName(b, a);
	const ad = a.lastDone ?? "";
	const bd = b.lastDone ?? "";
	if (ad !== bd) {
		if (!ad) return sort === "antiga" ? -1 : 1;
		if (!bd) return sort === "antiga" ? 1 : -1;
		return sort === "antiga" ? ad.localeCompare(bd) : bd.localeCompare(ad);
	}
	return byName(a, b);
}
function tone(status) {
	if (status === "ativo" || status === "sazonal") return "leaf";
	if (status === "pausado") return "clay";
	return "muted";
}
function GardensPage() {
	const { snap, loading } = useWorkspace();
	const [query, setQuery] = (0, import_react.useState)("");
	const [filter, setFilter] = (0, import_react.useState)("todos");
	const [sort, setSort] = (0, import_react.useState)(readSort);
	const [open, setOpen] = (0, import_react.useState)(false);
	const [editing, setEditing] = (0, import_react.useState)(null);
	const gardens = snap?.gardens ?? [];
	const visible = (0, import_react.useMemo)(() => {
		const q = query.trim().toLowerCase();
		return gardens.filter((garden) => {
			if (filter !== "todos" && garden.status !== filter) return false;
			if (!q) return true;
			return `${garden.name} ${garden.location}`.toLowerCase().includes(q);
		}).sort((a, b) => compareGardens(a, b, sort));
	}, [
		gardens,
		query,
		filter,
		sort
	]);
	const untouched = gardens.filter((garden) => !garden.lastDone).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-4xl",
					children: "Jardins"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [gardens.length === 1 ? "1 jardim" : `${gardens.length} jardins`, untouched ? ` · ${untouched} sem intervenção` : ""]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: () => {
						setEditing(null);
						setOpen(true);
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), "Jardim"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-2 sm:grid-cols-[minmax(0,1fr)_16rem]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute top-3 left-3 h-5 w-5 text-muted" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "h-11 w-full rounded-lg border border-line bg-card pr-3 pl-10 text-ink outline-none",
						value: query,
						onChange: (event) => setQuery(event.target.value),
						placeholder: "Procurar por nome ou sítio",
						"aria-label": "Procurar jardins"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "sr-only",
						children: "Ordenar"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: "h-11 w-full rounded-lg border border-line bg-card px-3 text-sm font-semibold text-ink",
						value: sort,
						onChange: (event) => {
							const next = event.target.value;
							setSort(next);
							try {
								localStorage.setItem(SORT_KEY, next);
							} catch {}
						},
						"aria-label": "Ordenar jardins",
						children: SORTS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: item.id,
							children: item.label
						}, item.id))
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-2 overflow-x-auto pb-1",
				children: FILTERS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setFilter(item.id),
					className: cx("h-10 shrink-0 rounded-full px-3 text-sm font-semibold", filter === item.id ? "bg-leaf text-card" : "bg-card text-muted ring-1 ring-line"),
					children: item.label
				}, item.id))
			}),
			loading && !snap ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "A carregar jardins…"
			}) : null,
			!loading && gardens.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
				title: "Ainda não há jardins",
				body: "Começa pelo nome e pela morada. O link para o Google Maps fica automático.",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => {
						setEditing(null);
						setOpen(true);
					},
					children: "Criar jardim"
				})
			}) : null,
			!loading && gardens.length > 0 && visible.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
				title: "Nada com esse filtro",
				body: "Experimenta outro estado ou limpa a pesquisa."
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "grid gap-3 md:grid-cols-2",
				children: visible.map((garden) => {
					const visit = interventionCopy(garden.lastDone);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: cx("rounded-xl border border-line bg-card p-4", visit.stale && "border-l-4 border-l-clay"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/jardins/$gardenId",
									params: { gardenId: garden.id },
									className: "min-w-0",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "font-display text-2xl",
										children: garden.name
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pill, {
									tone: tone(garden.status),
									children: STATUS_LABEL[garden.status]
								})]
							}),
							garden.location ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: mapsUrl(garden.location),
								target: "_blank",
								rel: "noreferrer",
								className: "mt-2 inline-flex items-start gap-1.5 text-sm font-medium text-leaf",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "mt-0.5 h-4 w-4 shrink-0" }), garden.location]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted",
								children: "Sem localização"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: cx("mt-3 text-sm font-semibold", visit.stale ? "text-clay" : "text-leaf"),
								children: [visit.lead, visit.when ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-medium text-muted",
									children: [" · ", visit.when]
								}) : null]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/jardins/$gardenId",
									params: { gardenId: garden.id },
									className: "inline-flex h-11 items-center rounded-lg bg-leaf-soft px-4 text-sm font-semibold text-leaf",
									children: "Abrir"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									onClick: () => {
										setEditing(garden);
										setOpen(true);
									},
									children: "Editar"
								})]
							})
						]
					}, garden.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GardenSheet, {
				open,
				garden: editing,
				onClose: () => setOpen(false)
			})
		]
	});
}
//#endregion
export { GardensPage as component };
