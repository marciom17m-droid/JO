import { o as __toESM } from "../_runtime.mjs";
import { Z as require_react, w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as Pencil, h as Check, i as Trash2, o as RotateCcw, v as CalendarClock } from "../_libs/lucide-react.mjs";
import { c as STATUS_LABEL, f as cx, m as fieldClass, o as Pill, p as dayLabel, r as Button, t as Avatars } from "./ui-DsFOv00P.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/task-card-DcsBSUsK.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function TaskCard({ task, gardenName, members, showDate, onDone, onPostpone, onEdit, onLog, onDelete }) {
	const [when, setWhen] = (0, import_react.useState)(task.scheduledDate);
	const [openDate, setOpenDate] = (0, import_react.useState)(false);
	const [confirm, setConfirm] = (0, import_react.useState)(false);
	const done = task.status === "feita";
	const moved = Boolean(task.postponedFrom) && !done;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "rounded-xl border border-line bg-card p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [
						gardenName ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold tracking-wide text-leaf uppercase",
							children: gardenName
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: cx("font-display text-xl text-ink", done && "text-muted line-through decoration-line"),
							children: task.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm text-muted",
							children: [
								showDate ? dayLabel(task.scheduledDate) : null,
								showDate && task.notes ? " · " : null,
								task.notes || (!showDate ? "" : "")
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex shrink-0 flex-col items-end gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pill, {
						tone: done ? "leaf" : moved ? "clay" : "muted",
						children: done ? STATUS_LABEL.feita : moved ? "Adiada" : "Por fazer"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatars, {
						members,
						ids: task.assigneeIds
					})]
				})]
			}),
			task.notes && !showDate ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: task.notes
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: done ? "secondary" : "primary",
						onClick: onDone,
						className: "h-10",
						children: [done ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "h-4 w-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4" }), done ? "Reabrir" : "Feita"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "secondary",
						className: "h-10",
						onClick: () => setOpenDate((v) => !v),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarClock, { className: "h-4 w-4" }), "Adiar"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						className: "h-10",
						onClick: onLog,
						children: "Registo"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						className: "h-10 px-3",
						onClick: onEdit,
						"aria-label": "Editar",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "h-4 w-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						className: "h-10 px-3 text-clay",
						onClick: () => setConfirm(true),
						"aria-label": "Eliminar",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
					})
				]
			}),
			openDate ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-3 flex gap-2",
				onSubmit: (event) => {
					event.preventDefault();
					onPostpone(when);
					setOpenDate(false);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: fieldClass,
					type: "date",
					value: when,
					onChange: (e) => setWhen(e.target.value),
					required: true
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					children: "Mover"
				})]
			}) : null,
			confirm ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex items-center justify-between gap-3 rounded-lg bg-clay-soft px-3 py-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-clay",
					children: "Eliminar esta tarefa?"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						className: "h-9",
						onClick: () => setConfirm(false),
						children: "Não"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "danger",
						className: "h-9",
						onClick: onDelete,
						children: "Eliminar"
					})]
				})]
			}) : null
		]
	});
}
//#endregion
export { TaskCard as t };
