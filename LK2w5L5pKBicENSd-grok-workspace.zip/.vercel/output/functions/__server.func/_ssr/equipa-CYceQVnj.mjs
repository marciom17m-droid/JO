import { o as __toESM } from "../_runtime.mjs";
import { Z as require_react, w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { m as ChevronLeft, p as ChevronRight } from "../_libs/lucide-react.mjs";
import { C as shortWeekday, D as weekdayStart, S as parseDay, T as useCurrentUser, d as addDay, f as cx, h as formatMinutes, m as fieldClass, p as dayLabel, r as Button, s as SERVICE_LABEL, w as todayIso, y as longDate } from "./ui-DsFOv00P.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as useWorkspace } from "./store-g2R_JrHC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/equipa-CYceQVnj.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function slotText(morning, afternoon) {
	if (morning && afternoon) return "Dia";
	if (morning) return "Manhã";
	if (afternoon) return "Tarde";
	return "—";
}
function TeamPage() {
	const user = useCurrentUser();
	const { snap, setMine, invite } = useWorkspace();
	const [cursor, setCursor] = (0, import_react.useState)(todayIso());
	const [tab, setTab] = (0, import_react.useState)("disp");
	const [span, setSpan] = (0, import_react.useState)("mes");
	const start = weekdayStart(cursor);
	const days = Array.from({ length: 7 }, (_, index) => addDay(start, index));
	const members = snap?.members ?? [];
	const me = user?.id ?? "";
	const range = (0, import_react.useMemo)(() => {
		const today = todayIso();
		if (span === "mes") {
			const now = /* @__PURE__ */ new Date();
			return {
				from: `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-01`,
				to: today
			};
		}
		return {
			from: addDay(today, -365),
			to: today
		};
	}, [span]);
	const rows = members.map((member) => {
		const done = (snap?.tasks ?? []).filter((task) => {
			if (task.status !== "feita") return false;
			if (task.scheduledDate < range.from || task.scheduledDate > range.to) return false;
			const logged = snap?.logs.some((log) => log.taskId === task.id && log.userId === member.id);
			return task.assigneeIds.includes(member.id) || task.completedBy === member.id || logged;
		});
		return {
			member,
			done,
			daysWorked: new Set(done.map((task) => task.scheduledDate)).size,
			minutes: (snap?.logs ?? []).filter((log) => log.userId === member.id && done.some((task) => task.id === log.taskId)).reduce((sum, log) => sum + (log.minutes ?? 0), 0)
		};
	});
	const maxDays = Math.max(1, ...rows.map((row) => row.daysWorked));
	const history = rows.flatMap((row) => row.done.map((task) => ({
		task,
		member: row.member
	}))).sort((a, b) => b.task.scheduledDate.localeCompare(a.task.scheduledDate) || a.task.title.localeCompare(b.task.title));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl",
				children: "Equipa"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [members.length === 1 ? "1 pessoa" : `${members.length} pessoas`, " · todas com as mesmas permissões"]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 rounded-lg bg-card p-1 ring-1 ring-line",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setTab("disp"),
					className: cx("h-11 rounded-md text-sm font-semibold", tab === "disp" ? "bg-leaf text-card" : "text-muted"),
					children: "Disponibilidade"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setTab("hist"),
					className: cx("h-11 rounded-md text-sm font-semibold", tab === "hist" ? "bg-leaf text-card" : "text-muted"),
					children: "Histórico"
				})]
			}),
			tab === "disp" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "rounded-xl border border-line bg-card p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-2xl",
								children: "A tua semana"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted",
								children: "Toca em Manhã, Tarde ou nas duas para o dia inteiro. Podes mudar quando quiseres."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 flex items-center justify-between",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "grid h-11 w-11 place-items-center rounded-lg hover:bg-paper",
										"aria-label": "Semana anterior",
										onClick: () => setCursor(addDay(start, -7)),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "h-5 w-5" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-sm font-medium",
										children: [
											longDate(start),
											" — ",
											dayLabel(days[6])
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "grid h-11 w-11 place-items-center rounded-lg hover:bg-paper",
										"aria-label": "Semana seguinte",
										onClick: () => setCursor(addDay(start, 7)),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-5 w-5" })
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-3 space-y-2",
								children: days.map((day) => {
									const slot = snap?.availability.find((item) => item.userId === me && item.day === day);
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex items-center justify-between gap-2 rounded-lg bg-paper px-3 py-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "min-w-16",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "block text-xs text-muted",
												children: shortWeekday(day)
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-display text-lg tabular-nums",
												children: parseDay(day).getDate()
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "flex gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
												on: Boolean(slot?.morning),
												label: "Manhã",
												onClick: () => void setMine(day, !slot?.morning, Boolean(slot?.afternoon))
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
												on: Boolean(slot?.afternoon),
												label: "Tarde",
												onClick: () => void setMine(day, Boolean(slot?.morning), !slot?.afternoon)
											})]
										})]
									}, day);
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl",
						children: "Toda a equipa"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 overflow-x-auto rounded-xl border border-line bg-card",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full min-w-[36rem] border-collapse text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "text-left text-xs text-muted",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-3 font-medium",
									children: "Pessoa"
								}), days.map((day) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("th", {
									className: "px-2 py-3 text-center font-medium",
									children: [shortWeekday(day), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block tabular-nums",
										children: parseDay(day).getDate()
									})]
								}, day))]
							}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: members.map((member) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-t border-line",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-3 text-left font-semibold",
									children: member.name
								}), days.map((day) => {
									const slot = snap?.availability.find((item) => item.userId === member.id && item.day === day);
									const label = slotText(Boolean(slot?.morning), Boolean(slot?.afternoon));
									return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-1 py-2 text-center",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: cx("inline-flex h-8 min-w-14 items-center justify-center rounded-full px-2 text-xs font-semibold", label !== "—" ? "bg-leaf-soft text-leaf" : "text-muted"),
											children: label
										})
									}, day);
								})]
							}, member.id)) })]
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InviteBox, {
						members,
						invites: snap?.invites ?? [],
						onInvite: invite
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setSpan("mes"),
							className: cx("h-10 rounded-full px-3 text-sm font-semibold", span === "mes" ? "bg-leaf text-card" : "bg-card ring-1 ring-line"),
							children: "Este mês"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setSpan("ano"),
							className: cx("h-10 rounded-full px-3 text-sm font-semibold", span === "ano" ? "bg-leaf text-card" : "bg-card ring-1 ring-line"),
							children: "Últimos 12 meses"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-3",
						children: rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "rounded-xl border border-line bg-card p-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-baseline justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-display text-xl",
									children: row.member.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm tabular-nums text-muted",
									children: [
										row.daysWorked,
										" ",
										row.daysWorked === 1 ? "dia" : "dias",
										" · ",
										row.done.length,
										" ",
										row.done.length === 1 ? "tarefa" : "tarefas",
										row.minutes ? ` · ${formatMinutes(row.minutes)}` : ""
									]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-3 h-2 overflow-hidden rounded-full bg-paper",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-full rounded-full bg-leaf",
									style: { width: `${row.daysWorked / maxDays * 100}%` }
								})
							})]
						}, row.member.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-2xl",
							children: "O que foi feito"
						}), history.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "Ainda não há tarefas concluídas neste período."
						}) : history.map(({ task, member }) => {
							const garden = snap?.gardens.find((item) => item.id === task.gardenId);
							const log = snap?.logs.find((item) => item.taskId === task.id && item.userId === member.id);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
								className: "rounded-xl border border-line bg-card px-4 py-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs font-semibold text-leaf",
										children: [
											dayLabel(task.scheduledDate),
											" · ",
											member.name
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-display text-lg",
										children: task.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-sm text-muted",
										children: [
											garden?.name ?? "Sem jardim",
											log?.serviceType ? ` · ${SERVICE_LABEL[log.serviceType] ?? log.serviceType}` : "",
											log?.minutes ? ` · ${formatMinutes(log.minutes)}` : ""
										]
									}),
									log?.notes ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-sm",
										children: log.notes
									}) : null,
									log?.materials ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-sm text-muted",
										children: ["Materiais: ", log.materials]
									}) : null
								]
							}, `${task.id}-${member.id}`);
						})]
					})
				]
			})
		]
	});
}
function Toggle({ on, label, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-pressed": on,
		onClick,
		className: cx("h-11 min-w-20 rounded-lg px-3 text-sm font-semibold", on ? "bg-leaf text-card" : "bg-card text-ink ring-1 ring-line"),
		children: label
	});
}
function InviteBox({ members, invites, onInvite }) {
	const [email, setEmail] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const pending = invites.filter((item) => !members.some((member) => member.email.trim().toLowerCase() === item));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-xl border border-dashed border-line bg-card p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl",
				children: "Entrar mais alguém"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: "Escreve o email. Quando essa pessoa criar conta — com email ou Google — entra com as mesmas permissões que tu."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-3 flex flex-col gap-2 sm:flex-row",
				onSubmit: (event) => {
					event.preventDefault();
					setBusy(true);
					onInvite(email.trim()).then((ok) => {
						setBusy(false);
						if (ok) {
							setEmail("");
							toast.success("Convite guardado. Já pode criar a conta com este email.");
						}
					});
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: fieldClass,
					type: "email",
					required: true,
					value: email,
					onChange: (event) => setEmail(event.target.value),
					placeholder: "nome@email.pt",
					"aria-label": "Email a convidar"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					disabled: busy,
					children: busy ? "A guardar…" : "Convidar"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "mt-4 space-y-1 text-sm",
				children: [members.map((member) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: member.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "truncate text-muted",
						children: member.email
					})]
				}, member.id)), pending.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex justify-between gap-3 text-muted",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Convite por aceitar" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "truncate",
						children: item
					})]
				}, item))]
			})
		]
	});
}
//#endregion
export { TeamPage as component };
