import { o as __toESM } from "../_runtime.mjs";
import { Z as require_react, w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as getServerFnById, i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { d as addDay, w as todayIso } from "./ui-DsFOv00P.mjs";
import { t as authMiddleware } from "./middleware-C7xGnu6T.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/store-g2R_JrHC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
/** Primeira conta abre a equipa. As seguintes só entram com convite pelo email. */
var getWorkspace = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("db4e5e043c8de89e98ca950e912373423eba5e676cffeb98a17c5fc078c96638"));
var saveGarden = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("e15c11b97706e54daa5c9e69c48b56b2a06ede9b7f5054d234e63b5d58ccf0a2"));
var deleteGarden = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("4d37827abd8becead0e6dd6eed5b72ee5982ac0ebda56cb6dd64f1e68e90a1d9"));
var listGardenPhotos = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("2f17c6699a9f9597d1aeb3fc8094397a2bcf7e4362c98a29a34ae14fbbf398ae"));
var addGardenPhoto = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("ffc828588d6f408aba653c7482e6a89fee5704a2014e671c2cbb8359727d7fab"));
var deleteGardenPhoto = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("471ed28cfcb460fc1d9bb808f61a9aeb03ca47c8c99798e4d1327324aa2ea7d4"));
var saveTask = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("9d976788db5f50fc1274f96604c0de4a2027d80bddcbe71f0acc2340ac7cbc49"));
var deleteTask = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("25a6d2aa39b8ca77430145e3b1056e9212b740e277612cb2a09c938b10fbf3cd"));
var setTaskDone = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("1577ea254f00f64894b6ed767aad250a6221bc99347034ef63ab32ee2ab74687"));
var postponeTask = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("c371e5c6da7e3c55925d531975ebfdb16f83cdb579f66529ee845aba46d97b0a"));
var saveWorkLog = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("06c6d922e78e7948d9f7addcb36323dfa54b1fefd5822e0fe8751f65da022a42"));
createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("2b7312d9f5723c8184d70dd6f3bf5d67676161fcdfeabfa53eb6fae8255b330d"));
createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("4c1ac738c7830d7ad61151c358d313dfd15aff38d0228c95a466d261ca5a7599"));
var setAvailability = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("70dee9644bbc62b599450619b148364e807cf4dad9f98811d6e8baea0862f5e5"));
var invitePerson = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("0588d16cc9de360d2f72fced5653c867e98f45a4eea4b19977b1006fc4493933"));
var CACHE_PREFIX = "jardins-outros.snapshot.v2.";
function cacheKey(userId) {
	return `${CACHE_PREFIX}${userId}`;
}
var Ctx = (0, import_react.createContext)(null);
function readCache(userId) {
	try {
		const raw = localStorage.getItem(cacheKey(userId));
		if (!raw) return null;
		return JSON.parse(raw);
	} catch {
		return null;
	}
}
function writeCache(userId, snap) {
	try {
		localStorage.setItem(cacheKey(userId), JSON.stringify(snap));
	} catch {}
}
async function settle(result) {
	if (!result.ok) {
		toast.error(result.error);
		return false;
	}
	return true;
}
function WorkspaceProvider({ userId, children }) {
	const [snap, setSnap] = (0, import_react.useState)(null);
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [offline, setOffline] = (0, import_react.useState)(false);
	const [stale, setStale] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const refresh = (0, import_react.useCallback)(async () => {
		const from = addDay(todayIso(), -400);
		const to = addDay(todayIso(), 220);
		try {
			const next = await getWorkspace({ data: {
				from,
				to
			} });
			setSnap(next);
			if (!next.blocked) writeCache(userId, next);
			setError(null);
			setStale(false);
		} catch (err) {
			const message = err instanceof Error ? err.message : "";
			if (message.includes("NOT_INVITED")) {
				setSnap({
					members: [],
					gardens: [],
					tasks: [],
					availability: [],
					logs: [],
					invites: [],
					from,
					to,
					blocked: true
				});
				setError(null);
				setStale(false);
				setLoading(false);
				return;
			}
			const cached = readCache(userId);
			if (cached) {
				setSnap(cached);
				setStale(true);
				setError(null);
			} else if (message.toLowerCase().includes("unauthorized")) setError("A sessão expirou. Entra outra vez.");
			else setError("Não foi possível carregar a equipa. Tenta de novo.");
		} finally {
			setLoading(false);
		}
	}, [userId]);
	(0, import_react.useEffect)(() => {
		const cached = readCache(userId);
		if (cached) setSnap(cached);
		refresh();
	}, [refresh, userId]);
	(0, import_react.useEffect)(() => {
		const sync = () => setOffline(!navigator.onLine);
		sync();
		window.addEventListener("online", sync);
		window.addEventListener("offline", sync);
		return () => {
			window.removeEventListener("online", sync);
			window.removeEventListener("offline", sync);
		};
	}, []);
	const guard = (0, import_react.useCallback)(async (work) => {
		if (!navigator.onLine) {
			toast.error("Sem ligação. Podes ver o que ficou guardado, mas não alterar.");
			return false;
		}
		try {
			const ok = await settle(await work());
			if (ok) await refresh();
			return ok;
		} catch {
			toast.error("Não foi possível guardar. Tenta outra vez.");
			return false;
		}
	}, [refresh]);
	const value = (0, import_react.useMemo)(() => ({
		snap,
		loading,
		offline,
		stale,
		error,
		refresh,
		saveGarden: (draft) => guard(() => saveGarden({ data: draft })),
		removeGarden: (id) => guard(() => deleteGarden({ data: { id } })),
		saveTask: (draft) => guard(() => saveTask({ data: draft })),
		removeTask: (id) => guard(() => deleteTask({ data: { id } })),
		markDone: (id, done) => guard(() => setTaskDone({ data: {
			id,
			done
		} })),
		postpone: (id, date) => guard(() => postponeTask({ data: {
			id,
			date
		} })),
		saveLog: (draft) => guard(() => saveWorkLog({ data: draft })),
		invite: (email) => guard(() => invitePerson({ data: { email } })),
		setMine: async (day, morning, afternoon) => {
			if (!navigator.onLine) {
				toast.error("Sem ligação. A disponibilidade atualiza quando voltares a estar online.");
				return;
			}
			setSnap((prev) => {
				if (!prev) return prev;
				const rest = prev.availability.filter((slot) => !(slot.userId === userId && slot.day === day));
				const availability = morning || afternoon ? [...rest, {
					userId,
					day,
					morning,
					afternoon
				}] : rest;
				return {
					...prev,
					availability
				};
			});
			try {
				const result = await setAvailability({ data: {
					day,
					morning,
					afternoon
				} });
				if (!result.ok) {
					toast.error(result.error);
					await refresh();
				}
			} catch {
				toast.error("Não foi possível atualizar a disponibilidade.");
				await refresh();
			}
		}
	}), [
		snap,
		loading,
		offline,
		stale,
		error,
		refresh,
		guard,
		userId
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ctx.Provider, {
		value,
		children
	});
}
function useWorkspace() {
	const ctx = (0, import_react.useContext)(Ctx);
	if (!ctx) throw new Error("Workspace em falta");
	return ctx;
}
//#endregion
export { useWorkspace as a, listGardenPhotos as i, addGardenPhoto as n, deleteGardenPhoto as r, WorkspaceProvider as t };
