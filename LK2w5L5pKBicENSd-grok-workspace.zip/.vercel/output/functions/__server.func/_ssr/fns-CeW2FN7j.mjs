import { i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { t as authMiddleware } from "./middleware-C7xGnu6T.mjs";
import { n as SERVICE_TYPES, t as GARDEN_STATUSES } from "./types-LTjSWxWC.mjs";
import { r as getSql } from "./db-BKeOTcFw.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/fns-CeW2FN7j.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var DAY = /^\d{4}-\d{2}-\d{2}$/;
var JPEG = /^data:image\/jpeg;base64,[a-z0-9+/=\s]+$/i;
var MAX_PHOTO = 55e4;
function fail(error) {
	return {
		ok: false,
		error
	};
}
function text(value, max) {
	return String(value ?? "").replace(/\s+/g, " ").trim().slice(0, max);
}
function notes(value) {
	return String(value ?? "").trim().slice(0, 4e3);
}
function day(value) {
	const raw = String(value ?? "");
	return DAY.test(raw) ? raw : null;
}
function iso(value) {
	if (value == null) return null;
	if (value instanceof Date) return value.toISOString();
	const raw = String(value);
	return raw.length ? raw : null;
}
function dateOnly(value) {
	return String(value ?? "").slice(0, 10);
}
function jpeg(value) {
	const raw = String(value ?? "");
	if (!JPEG.test(raw) || raw.length > MAX_PHOTO) return null;
	return raw;
}
async function memberSet(sql) {
	const rows = await sql`select id from "user"`;
	return new Set(rows.map((row) => row.id));
}
/** Primeira conta abre a equipa. As seguintes só entram com convite pelo email. */
async function membership(sql, userId) {
	const me = await sql`select email from "user" where id = ${userId}`;
	if (!me.length) return "blocked";
	const email = me[0].email.trim().toLowerCase();
	if ((await sql`select id from "user" order by "createdAt" asc limit 1`)[0]?.id === userId) return "ok";
	return (await sql`select email from invites where email = ${email}`).length ? "ok" : "blocked";
}
async function authorizedSql(userId) {
	const sql = await getSql();
	if (await membership(sql, userId) === "blocked") throw new Error("NOT_INVITED");
	return sql;
}
function emptyWorkspace(from, to) {
	return {
		members: [],
		gardens: [],
		tasks: [],
		availability: [],
		logs: [],
		invites: [],
		from,
		to,
		blocked: true
	};
}
var getWorkspace_createServerFn_handler = createServerRpc({
	id: "db4e5e043c8de89e98ca950e912373423eba5e676cffeb98a17c5fc078c96638",
	name: "getWorkspace",
	filename: "src/lib/garden/fns.ts"
}, (opts) => getWorkspace.__executeServer(opts));
var getWorkspace = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(getWorkspace_createServerFn_handler, async ({ context, data }) => {
	const from = day(data?.from) ?? "2000-01-01";
	const to = day(data?.to) ?? "2100-01-01";
	let sql;
	try {
		sql = await authorizedSql(context.userId);
	} catch (err) {
		if (err instanceof Error && err.message === "NOT_INVITED") return emptyWorkspace(from, to);
		throw err;
	}
	const members = await sql`select id, name, email, image from "user" order by name asc`;
	const gardenRows = await sql`select id, name, location, notes, status, created_by, updated_at
       from gardens order by name asc`;
	const taskRows = await sql`select id, garden_id, title, scheduled_date, status, notes, postponed_from,
              created_by, completed_by, completed_at
       from tasks
       where scheduled_date between ${from}::date and ${to}::date
       order by scheduled_date asc, title asc`;
	const links = await sql`
      select task_id, user_id from task_assignees
    `;
	const assignees = /* @__PURE__ */ new Map();
	for (const link of links) {
		const list = assignees.get(link.task_id) ?? [];
		list.push(link.user_id);
		assignees.set(link.task_id, list);
	}
	const availability = await sql`select user_id, day, morning, afternoon
       from availability
       where day between ${from}::date and ${to}::date`;
	const logs = await sql`select wl.id, wl.task_id, wl.user_id, wl.minutes, wl.service_type, wl.materials, wl.notes,
              (select count(*) from work_photos wp where wp.work_log_id = wl.id) as photo_count
       from work_logs wl
       where wl.task_id in (
         select id from tasks where scheduled_date between ${from}::date and ${to}::date
       )`;
	const visits = await sql`
      select garden_id,
             max(coalesce(completed_at::date, scheduled_date)) as last_done
      from tasks
      where status = 'feita' and garden_id is not null
      group by garden_id
    `;
	const lastByGarden = new Map(visits.map((row) => [row.garden_id, dateOnly(row.last_done)]));
	const inviteRows = await sql`select email from invites order by email asc`;
	const gardens = gardenRows.map((row) => ({
		id: row.id,
		name: row.name,
		location: row.location,
		notes: row.notes,
		status: GARDEN_STATUSES.includes(row.status) ? row.status : "ativo",
		createdBy: row.created_by,
		updatedAt: iso(row.updated_at) ?? "",
		lastDone: lastByGarden.get(row.id) || null
	}));
	const tasks = taskRows.map((row) => ({
		id: row.id,
		gardenId: row.garden_id,
		title: row.title,
		scheduledDate: dateOnly(row.scheduled_date),
		status: row.status === "feita" ? "feita" : "agendada",
		notes: row.notes,
		postponedFrom: row.postponed_from ? dateOnly(row.postponed_from) : null,
		createdBy: row.created_by,
		completedBy: row.completed_by,
		completedAt: iso(row.completed_at),
		assigneeIds: assignees.get(row.id) ?? []
	}));
	const slots = availability.map((row) => ({
		userId: row.user_id,
		day: dateOnly(row.day),
		morning: Boolean(row.morning),
		afternoon: Boolean(row.afternoon)
	}));
	const work = logs.map((row) => ({
		id: row.id,
		taskId: row.task_id,
		userId: row.user_id,
		minutes: row.minutes == null ? null : Number(row.minutes),
		serviceType: row.service_type,
		materials: row.materials,
		notes: row.notes,
		photoCount: Number(row.photo_count) || 0
	}));
	return {
		members: members.map((row) => ({
			id: row.id,
			name: row.name,
			email: row.email,
			image: row.image
		})),
		gardens,
		tasks,
		availability: slots,
		logs: work,
		invites: inviteRows.map((row) => row.email),
		from,
		to
	};
});
var saveGarden_createServerFn_handler = createServerRpc({
	id: "e15c11b97706e54daa5c9e69c48b56b2a06ede9b7f5054d234e63b5d58ccf0a2",
	name: "saveGarden",
	filename: "src/lib/garden/fns.ts"
}, (opts) => saveGarden.__executeServer(opts));
var saveGarden = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(saveGarden_createServerFn_handler, async ({ context, data }) => {
	const name = text(data?.name, 120);
	if (name.length < 2) return fail("O nome do jardim precisa de pelo menos 2 caracteres.");
	const location = text(data?.location, 240);
	const body = notes(data?.notes);
	const status = GARDEN_STATUSES.includes(String(data?.status)) ? String(data.status) : "ativo";
	const sql = await authorizedSql(context.userId);
	const id = text(data?.id, 80);
	if (id) {
		if (!(await sql`select id from gardens where id = ${id}`).length) return fail("Esse jardim já não existe.");
		await sql`update gardens
                set name = ${name}, location = ${location}, notes = ${body},
                    status = ${status}, updated_at = now()
                where id = ${id}`;
		return { ok: true };
	}
	await sql`insert into gardens (id, name, location, notes, status, created_by)
              values (${crypto.randomUUID()}, ${name}, ${location}, ${body}, ${status}, ${context.userId})`;
	return { ok: true };
});
var deleteGarden_createServerFn_handler = createServerRpc({
	id: "4d37827abd8becead0e6dd6eed5b72ee5982ac0ebda56cb6dd64f1e68e90a1d9",
	name: "deleteGarden",
	filename: "src/lib/garden/fns.ts"
}, (opts) => deleteGarden.__executeServer(opts));
var deleteGarden = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(deleteGarden_createServerFn_handler, async ({ context, data }) => {
	const id = text(data?.id, 80);
	if (!id) return fail("Jardim inválido.");
	await (await authorizedSql(context.userId))`delete from gardens where id = ${id}`;
	return { ok: true };
});
var listGardenPhotos_createServerFn_handler = createServerRpc({
	id: "2f17c6699a9f9597d1aeb3fc8094397a2bcf7e4362c98a29a34ae14fbbf398ae",
	name: "listGardenPhotos",
	filename: "src/lib/garden/fns.ts"
}, (opts) => listGardenPhotos.__executeServer(opts));
var listGardenPhotos = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(listGardenPhotos_createServerFn_handler, async ({ context, data }) => {
	const gardenId = text(data?.gardenId, 80);
	return (await (await authorizedSql(context.userId))`
      select id, data_url, created_at from garden_photos
      where garden_id = ${gardenId}
      order by created_at asc
    `).map((row) => ({
		id: row.id,
		dataUrl: row.data_url,
		createdAt: iso(row.created_at) ?? ""
	}));
});
var addGardenPhoto_createServerFn_handler = createServerRpc({
	id: "ffc828588d6f408aba653c7482e6a89fee5704a2014e671c2cbb8359727d7fab",
	name: "addGardenPhoto",
	filename: "src/lib/garden/fns.ts"
}, (opts) => addGardenPhoto.__executeServer(opts));
var addGardenPhoto = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(addGardenPhoto_createServerFn_handler, async ({ context, data }) => {
	const gardenId = text(data?.gardenId, 80);
	const dataUrl = jpeg(data?.dataUrl);
	if (!gardenId || !dataUrl) return fail("Foto inválida.");
	const sql = await authorizedSql(context.userId);
	if (!(await sql`select id from gardens where id = ${gardenId}`).length) return fail("Esse jardim já não existe.");
	const count = await sql`select count(*) as n from garden_photos where garden_id = ${gardenId}`;
	if (Number(count[0]?.n ?? 0) >= 12) return fail("Este jardim já tem 12 fotos. Apaga uma para adicionar outra.");
	await sql`insert into garden_photos (id, garden_id, data_url, created_by)
              values (${crypto.randomUUID()}, ${gardenId}, ${dataUrl}, ${context.userId})`;
	return { ok: true };
});
var deleteGardenPhoto_createServerFn_handler = createServerRpc({
	id: "471ed28cfcb460fc1d9bb808f61a9aeb03ca47c8c99798e4d1327324aa2ea7d4",
	name: "deleteGardenPhoto",
	filename: "src/lib/garden/fns.ts"
}, (opts) => deleteGardenPhoto.__executeServer(opts));
var deleteGardenPhoto = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(deleteGardenPhoto_createServerFn_handler, async ({ context, data }) => {
	const id = text(data?.id, 80);
	if (!id) return fail("Foto inválida.");
	await (await authorizedSql(context.userId))`delete from garden_photos where id = ${id}`;
	return { ok: true };
});
var saveTask_createServerFn_handler = createServerRpc({
	id: "9d976788db5f50fc1274f96604c0de4a2027d80bddcbe71f0acc2340ac7cbc49",
	name: "saveTask",
	filename: "src/lib/garden/fns.ts"
}, (opts) => saveTask.__executeServer(opts));
var saveTask = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(saveTask_createServerFn_handler, async ({ context, data }) => {
	const title = text(data?.title, 160);
	if (title.length < 2) return fail("A tarefa precisa de um título.");
	const scheduled = day(data?.scheduledDate);
	if (!scheduled) return fail("Escolhe o dia.");
	const body = notes(data?.notes);
	const sql = await authorizedSql(context.userId);
	const people = await memberSet(sql);
	const wanted = Array.isArray(data?.assigneeIds) ? data.assigneeIds : [];
	const assignees = [...new Set(wanted.map((id) => String(id)).filter((id) => people.has(id)))];
	if (!assignees.length) {
		if (!people.has(context.userId)) return fail("Ainda não há pessoas para atribuir.");
		assignees.push(context.userId);
	}
	let gardenId = data?.gardenId ? text(data.gardenId, 80) : null;
	if (gardenId) {
		if (!(await sql`select id from gardens where id = ${gardenId}`).length) gardenId = null;
	}
	const id = text(data?.id, 80);
	if (id) {
		if (!(await sql`select id from tasks where id = ${id}`).length) return fail("Essa tarefa já não existe.");
		await sql`update tasks
                set title = ${title}, garden_id = ${gardenId}, scheduled_date = ${scheduled}::date,
                    notes = ${body}, updated_at = now()
                where id = ${id}`;
		await sql`delete from task_assignees where task_id = ${id}`;
		for (const userId of assignees) await sql`insert into task_assignees (task_id, user_id) values (${id}, ${userId})`;
		return { ok: true };
	}
	const next = crypto.randomUUID();
	await sql`insert into tasks (id, garden_id, title, scheduled_date, notes, created_by)
              values (${next}, ${gardenId}, ${title}, ${scheduled}::date, ${body}, ${context.userId})`;
	for (const userId of assignees) await sql`insert into task_assignees (task_id, user_id) values (${next}, ${userId})`;
	return { ok: true };
});
var deleteTask_createServerFn_handler = createServerRpc({
	id: "25a6d2aa39b8ca77430145e3b1056e9212b740e277612cb2a09c938b10fbf3cd",
	name: "deleteTask",
	filename: "src/lib/garden/fns.ts"
}, (opts) => deleteTask.__executeServer(opts));
var deleteTask = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(deleteTask_createServerFn_handler, async ({ context, data }) => {
	const id = text(data?.id, 80);
	if (!id) return fail("Tarefa inválida.");
	await (await authorizedSql(context.userId))`delete from tasks where id = ${id}`;
	return { ok: true };
});
var setTaskDone_createServerFn_handler = createServerRpc({
	id: "1577ea254f00f64894b6ed767aad250a6221bc99347034ef63ab32ee2ab74687",
	name: "setTaskDone",
	filename: "src/lib/garden/fns.ts"
}, (opts) => setTaskDone.__executeServer(opts));
var setTaskDone = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(setTaskDone_createServerFn_handler, async ({ context, data }) => {
	const id = text(data?.id, 80);
	if (!id) return fail("Tarefa inválida.");
	const sql = await authorizedSql(context.userId);
	if (data?.done) await sql`update tasks
                set status = 'feita', completed_by = ${context.userId}, completed_at = now(), updated_at = now()
                where id = ${id}`;
	else await sql`update tasks
                set status = 'agendada', completed_by = null, completed_at = null, updated_at = now()
                where id = ${id}`;
	return { ok: true };
});
var postponeTask_createServerFn_handler = createServerRpc({
	id: "c371e5c6da7e3c55925d531975ebfdb16f83cdb579f66529ee845aba46d97b0a",
	name: "postponeTask",
	filename: "src/lib/garden/fns.ts"
}, (opts) => postponeTask.__executeServer(opts));
var postponeTask = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(postponeTask_createServerFn_handler, async ({ context, data }) => {
	const id = text(data?.id, 80);
	const next = day(data?.date);
	if (!id || !next) return fail("Escolhe o novo dia.");
	const sql = await authorizedSql(context.userId);
	const rows = await sql`select scheduled_date from tasks where id = ${id}`;
	if (!rows.length) return fail("Essa tarefa já não existe.");
	const current = dateOnly(rows[0].scheduled_date);
	if (current === next) return { ok: true };
	await sql`update tasks
              set scheduled_date = ${next}::date,
                  postponed_from = coalesce(postponed_from, ${current}::date),
                  status = 'agendada',
                  completed_by = null,
                  completed_at = null,
                  updated_at = now()
              where id = ${id}`;
	return { ok: true };
});
var saveWorkLog_createServerFn_handler = createServerRpc({
	id: "06c6d922e78e7948d9f7addcb36323dfa54b1fefd5822e0fe8751f65da022a42",
	name: "saveWorkLog",
	filename: "src/lib/garden/fns.ts"
}, (opts) => saveWorkLog.__executeServer(opts));
var saveWorkLog = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(saveWorkLog_createServerFn_handler, async ({ context, data }) => {
	const taskId = text(data?.taskId, 80);
	if (!taskId) return fail("Tarefa inválida.");
	const service = SERVICE_TYPES.includes(String(data?.serviceType)) ? String(data.serviceType) : "";
	const materials = text(data?.materials, 400);
	const body = notes(data?.notes);
	let minutes = null;
	if (data?.minutes != null && data.minutes !== "") {
		const n = Number(data.minutes);
		if (!Number.isFinite(n) || n < 0 || n > 1440) return fail("O tempo tem de estar entre 0 e 1440 minutos.");
		minutes = Math.round(n);
	}
	const photos = (Array.isArray(data?.photos) ? data.photos : []).map((item) => jpeg(item)).filter((item) => Boolean(item)).slice(0, 4);
	const sql = await authorizedSql(context.userId);
	if (!(await sql`select id from tasks where id = ${taskId}`).length) return fail("Essa tarefa já não existe.");
	let logId = (await sql`
      select id from work_logs where task_id = ${taskId} and user_id = ${context.userId}
    `)[0]?.id;
	if (logId) await sql`update work_logs
                set minutes = ${minutes}, service_type = ${service}, materials = ${materials}, notes = ${body}
                where id = ${logId}`;
	else {
		if (minutes == null && !service && !materials && !body && photos.length === 0) return { ok: true };
		logId = crypto.randomUUID();
		await sql`insert into work_logs (id, task_id, user_id, minutes, service_type, materials, notes)
                values (${logId}, ${taskId}, ${context.userId}, ${minutes}, ${service}, ${materials}, ${body})`;
	}
	const count = await sql`select count(*) as n from work_photos where work_log_id = ${logId}`;
	const room = Math.max(0, 6 - Number(count[0]?.n ?? 0));
	for (const photo of photos.slice(0, room)) await sql`insert into work_photos (id, work_log_id, data_url)
                values (${crypto.randomUUID()}, ${logId}, ${photo})`;
	return { ok: true };
});
var listWorkPhotos_createServerFn_handler = createServerRpc({
	id: "2b7312d9f5723c8184d70dd6f3bf5d67676161fcdfeabfa53eb6fae8255b330d",
	name: "listWorkPhotos",
	filename: "src/lib/garden/fns.ts"
}, (opts) => listWorkPhotos.__executeServer(opts));
var listWorkPhotos = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(listWorkPhotos_createServerFn_handler, async ({ context, data }) => {
	const taskId = text(data?.taskId, 80);
	return (await (await authorizedSql(context.userId))`select wp.id, wp.work_log_id, wp.data_url, wp.created_at
       from work_photos wp
       join work_logs wl on wl.id = wp.work_log_id
       where wl.task_id = ${taskId}
       order by wp.created_at asc`).map((row) => ({
		id: row.id,
		workLogId: row.work_log_id,
		dataUrl: row.data_url,
		createdAt: iso(row.created_at) ?? ""
	}));
});
var deleteWorkPhoto_createServerFn_handler = createServerRpc({
	id: "4c1ac738c7830d7ad61151c358d313dfd15aff38d0228c95a466d261ca5a7599",
	name: "deleteWorkPhoto",
	filename: "src/lib/garden/fns.ts"
}, (opts) => deleteWorkPhoto.__executeServer(opts));
var deleteWorkPhoto = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(deleteWorkPhoto_createServerFn_handler, async ({ context, data }) => {
	const id = text(data?.id, 80);
	if (!id) return fail("Foto inválida.");
	await (await authorizedSql(context.userId))`delete from work_photos where id = ${id}`;
	return { ok: true };
});
var setAvailability_createServerFn_handler = createServerRpc({
	id: "70dee9644bbc62b599450619b148364e807cf4dad9f98811d6e8baea0862f5e5",
	name: "setAvailability",
	filename: "src/lib/garden/fns.ts"
}, (opts) => setAvailability.__executeServer(opts));
var setAvailability = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(setAvailability_createServerFn_handler, async ({ context, data }) => {
	const when = day(data?.day);
	if (!when) return fail("Dia inválido.");
	const morning = Boolean(data?.morning);
	const afternoon = Boolean(data?.afternoon);
	const sql = await authorizedSql(context.userId);
	if (!morning && !afternoon) {
		await sql`delete from availability where user_id = ${context.userId} and day = ${when}::date`;
		return { ok: true };
	}
	await sql`insert into availability (user_id, day, morning, afternoon)
              values (${context.userId}, ${when}::date, ${morning}, ${afternoon})
              on conflict (user_id, day)
              do update set morning = ${morning}, afternoon = ${afternoon}`;
	return { ok: true };
});
var invitePerson_createServerFn_handler = createServerRpc({
	id: "0588d16cc9de360d2f72fced5653c867e98f45a4eea4b19977b1006fc4493933",
	name: "invitePerson",
	filename: "src/lib/garden/fns.ts"
}, (opts) => invitePerson.__executeServer(opts));
var invitePerson = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(invitePerson_createServerFn_handler, async ({ context, data }) => {
	const email = text(data?.email, 160).toLowerCase();
	if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return fail("Indica um email válido.");
	await (await authorizedSql(context.userId))`insert into invites (email, invited_by) values (${email}, ${context.userId})
              on conflict (email) do nothing`;
	return { ok: true };
});
//#endregion
export { addGardenPhoto_createServerFn_handler, deleteGardenPhoto_createServerFn_handler, deleteGarden_createServerFn_handler, deleteTask_createServerFn_handler, deleteWorkPhoto_createServerFn_handler, getWorkspace_createServerFn_handler, invitePerson_createServerFn_handler, listGardenPhotos_createServerFn_handler, listWorkPhotos_createServerFn_handler, postponeTask_createServerFn_handler, saveGarden_createServerFn_handler, saveTask_createServerFn_handler, saveWorkLog_createServerFn_handler, setAvailability_createServerFn_handler, setTaskDone_createServerFn_handler };
