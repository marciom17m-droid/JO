import { o as __toESM } from "../_runtime.mjs";
import { Z as require_react, w as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { b as ArrowLeft, g as Camera, i as Trash2, l as MapPin } from "../_libs/lucide-react.mjs";
import { b as mapsUrl, c as STATUS_LABEL, i as Empty, o as Pill, r as Button, v as interventionCopy, w as todayIso } from "./ui-DsFOv00P.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as useWorkspace, i as listGardenPhotos, n as addGardenPhoto, r as deleteGardenPhoto } from "./store-g2R_JrHC.mjs";
import { i as compressImage, n as LogSheet, r as TaskSheet, t as GardenSheet } from "./sheets-DcH8jWP5.mjs";
import { t as TaskCard } from "./task-card-DcsBSUsK.mjs";
import { n as Route$1 } from "./router-S-qHndTd.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/jardins._gardenId-ByCy8cb5.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function GardenDetail() {
	const { gardenId } = Route$1.useParams();
	const { snap, loading, markDone, postpone, removeTask, removeGarden } = useWorkspace();
	const garden = snap?.gardens.find((item) => item.id === gardenId);
	const tasks = (snap?.tasks ?? []).filter((task) => task.gardenId === gardenId);
	const members = snap?.members ?? [];
	const [photos, setPhotos] = (0, import_react.useState)([]);
	const [edit, setEdit] = (0, import_react.useState)(false);
	const [taskOpen, setTaskOpen] = (0, import_react.useState)(false);
	const [editing, setEditing] = (0, import_react.useState)(null);
	const [logging, setLogging] = (0, import_react.useState)(null);
	const [confirm, setConfirm] = (0, import_react.useState)(false);
	const [viewer, setViewer] = (0, import_react.useState)(null);
	function reloadPhotos() {
		listGardenPhotos({ data: { gardenId } }).then(setPhotos).catch(() => setPhotos([]));
	}
	(0, import_react.useEffect)(() => {
		reloadPhotos();
	}, [gardenId]);
	if (!loading && snap && !garden) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
		title: "Jardim não encontrado",
		body: "Pode ter sido eliminado por alguém da equipa.",
		action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/jardins",
			className: "inline-flex h-11 items-center rounded-lg bg-leaf px-4 text-sm font-semibold text-card",
			children: "Voltar aos jardins"
		})
	});
	if (!garden) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted",
		children: "A abrir o jardim…"
	});
	const visit = interventionCopy(garden.lastDone);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/jardins",
				className: "inline-flex h-11 items-center gap-1 text-sm font-semibold text-leaf",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-4 w-4" }), "Jardins"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pill, {
						tone: garden.status === "pausado" ? "clay" : garden.status === "concluido" ? "muted" : "leaf",
						children: STATUS_LABEL[garden.status]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 font-display text-4xl",
						children: garden.name
					}),
					garden.location ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: mapsUrl(garden.location),
						target: "_blank",
						rel: "noreferrer",
						className: "mt-2 inline-flex items-start gap-1.5 text-sm font-semibold text-leaf",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "mt-0.5 h-4 w-4" }), "Abrir no Google Maps"]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: "Sem localização. Edita o jardim para a acrescentar."
					}),
					garden.location ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: garden.location
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: visit.stale ? "mt-2 text-sm font-semibold text-clay" : "mt-2 text-sm font-semibold text-leaf",
						children: [visit.lead, visit.when ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-medium text-muted",
							children: [" · ", visit.when]
						}) : null]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						onClick: () => setEdit(true),
						children: "Editar"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						className: "text-clay",
						onClick: () => setConfirm(true),
						"aria-label": "Eliminar jardim",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
					})]
				})]
			}),
			confirm ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-3 rounded-xl bg-clay-soft px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-clay",
					children: "Eliminar este jardim? As tarefas ficam, mas deixam de estar ligadas a ele."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						onClick: () => setConfirm(false),
						children: "Cancelar"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "danger",
						onClick: () => {
							removeGarden(garden.id).then((ok) => {
								if (ok) window.location.href = "/jardins";
							});
						},
						children: "Eliminar"
					})]
				})]
			}) : null,
			garden.notes ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-xl border border-line bg-card p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-semibold text-muted",
					children: "Notas"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 whitespace-pre-wrap text-sm",
					children: garden.notes
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-2 flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl",
					children: "Fotos"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "inline-flex h-11 cursor-pointer items-center gap-2 rounded-lg bg-leaf-soft px-3 text-sm font-semibold text-leaf",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "h-4 w-4" }),
						"Adicionar",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "file",
							accept: "image/*",
							className: "sr-only",
							onChange: (event) => {
								const file = event.target.files?.[0];
								event.target.value = "";
								if (!file) return;
								compressImage(file).then((dataUrl) => addGardenPhoto({ data: {
									gardenId,
									dataUrl
								} })).then((result) => {
									if (!result.ok) {
										toast.error(result.error);
										return;
									}
									toast.success("Foto adicionada");
									reloadPhotos();
								}).catch((err) => toast.error(err instanceof Error ? err.message : "Foto inválida"));
							}
						})
					]
				})]
			}), photos.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Ainda sem fotos. Uma imagem do portão ou do relvado chega para a equipa se orientar."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex gap-2 overflow-x-auto pb-1",
				children: photos.map((photo) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "relative shrink-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setViewer(photo.dataUrl),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: photo.dataUrl,
							alt: "",
							className: "h-32 w-40 rounded-lg object-cover"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "Apagar foto",
						className: "absolute top-1 right-1 grid h-8 w-8 place-items-center rounded-full bg-card/90 text-clay",
						onClick: () => {
							deleteGardenPhoto({ data: { id: photo.id } }).then((result) => {
								if (!result.ok) toast.error(result.error);
								else reloadPhotos();
							});
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
					})]
				}, photo.id))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl",
						children: "Trabalho"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => {
							setEditing(null);
							setTaskOpen(true);
						},
						children: "Nova tarefa"
					})]
				}), tasks.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
					title: "Sem tarefas neste jardim",
					body: "Marca a próxima visita e escolhe quem vai."
				}) : tasks.slice().sort((a, b) => b.scheduledDate.localeCompare(a.scheduledDate)).map((task) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TaskCard, {
					task,
					members,
					showDate: true,
					onDone: () => void markDone(task.id, task.status !== "feita"),
					onPostpone: (date) => void postpone(task.id, date),
					onEdit: () => {
						setEditing(task);
						setTaskOpen(true);
					},
					onLog: () => setLogging(task),
					onDelete: () => void removeTask(task.id)
				}, task.id))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GardenSheet, {
				open: edit,
				garden,
				onClose: () => setEdit(false)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TaskSheet, {
				open: taskOpen,
				task: editing,
				initialGardenId: garden.id,
				initialDate: todayIso(),
				members,
				gardens: snap?.gardens ?? [],
				onClose: () => setTaskOpen(false)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogSheet, {
				open: Boolean(logging),
				task: logging,
				onClose: () => setLogging(null)
			}),
			viewer ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "fixed inset-0 z-50 grid place-items-center bg-ink/80 p-4",
				onClick: () => setViewer(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: viewer,
					alt: "",
					className: "max-h-[85dvh] max-w-full rounded-lg"
				})
			}) : null
		]
	});
}
//#endregion
export { GardenDetail as component };
