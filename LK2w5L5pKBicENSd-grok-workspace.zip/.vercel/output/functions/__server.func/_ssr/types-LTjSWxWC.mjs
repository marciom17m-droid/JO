//#region node_modules/.nitro/vite/services/ssr/assets/types-LTjSWxWC.js
var GARDEN_STATUSES = [
	"ativo",
	"pausado",
	"sazonal",
	"concluido"
];
var SERVICE_TYPES = [
	"corte",
	"poda",
	"rega",
	"plantacao",
	"limpeza",
	"adubacao",
	"bordaduras",
	"outro"
];
//#endregion
export { SERVICE_TYPES as n, GARDEN_STATUSES as t };
