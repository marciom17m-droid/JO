import { o as __toESM } from "./_runtime.mjs";
import { Z as require_react, w as require_jsx_runtime, x as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { s as Plus, y as Bell } from "./_libs/lucide-react.mjs";
import { T as useCurrentUser, d as addDay, g as greeting, i as Empty, r as Button, w as todayIso } from "./_ssr/ui-DsFOv00P.mjs";
import { n as toast } from "./_libs/sonner.mjs";
import { a as useWorkspace } from "./_ssr/store-g2R_JrHC.mjs";
import { n as LogSheet, r as TaskSheet, t as GardenSheet } from "./_ssr/sheets-DcH8jWP5.mjs";
import { t as TaskCard } from "./_ssr/task-card-DcsBSUsK.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_app-DZ74Ozx6.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var NOTIFY_KEY = "jardins.notify";
var NOTIFIED_KEY = "jardins.notified";
function periodLabel(morning, afternoon) {
	if (morning && afternoon) return "dia inteiro";
	if (morning) return "manhã";
	if (afternoon) return "tarde";
	return "";
}
function TodayPage() {
	const user = useCurrentUser();
	const { snap, loading, markDone, postpone, removeTask } = useWorkspace();
	const [taskOpen, setTaskOpen] = (0, import_react.useState)(false);
	const [editing, setEditing] = (0, import_react.useState)(null);
	const [logging, setLogging] = (0, import_react.useState)(null);
	const [gardenOpen, setGardenOpen] = (0, import_react.useState)(false);
	const [notifyOn, setNotifyOn] = (0, import_react.useState)(false);
	const today = todayIso();
	const tomorrow = addDay(today, 1);
	const tasks = snap?.tasks.filter((task) => task.scheduledDate === today) ?? [];
	const next = snap?.tasks.filter((task) => task.scheduledDate === tomorrow && task.status !== "feita") ?? [];
	const openTasks = tasks.filter((task) => task.status !== "feita");
	const available = snap?.availability.filter((slot) => slot.day === today && (slot.morning || slot.afternoon)) ?? [];
	(0, import_react.useEffect)(() => {
		setNotifyOn(localStorage.getItem(NOTIFY_KEY) === "1" && Notification.permission === "granted");
	}, []);
	(0, import_react.useEffect)(() => {
		if (!snap || localStorage.getItem(NOTIFY_KEY) !== "1") return;
		if (typeof Notification === "undefined" || Notification.permission !== "granted") return;
		if (localStorage.getItem(NOTIFIED_KEY) === today) return;
		if (!openTasks.length) return;
		localStorage.setItem(NOTIFIED_KEY, today);
		const body = openTasks.length === 1 ? openTasks[0].title : `${openTasks.length} tarefas por fazer hoje`;
		try {
			new Notification("Jardins e outros", { body });
		} catch {}
	}, [
		snap,
		today,
		openTasks.length,
		openTasks[0]?.title
	]);
	const gardens = snap?.gardens ?? [];
	const members = snap?.members ?? [];
	const gardenName = (id) => gardens.find((garden) => garden.id === id)?.name;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium text-muted",
					children: new Intl.DateTimeFormat("pt-PT", {
						weekday: "long",
						day: "numeric",
						month: "long"
					}).format(/* @__PURE__ */ new Date())
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-4xl text-ink",
					children: greeting(user?.displayName)
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: () => {
						setEditing(null);
						setTaskOpen(true);
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), "Tarefa"]
				})]
			}),
			!gardens.length && !loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-xl bg-leaf px-5 py-5 text-card",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl",
						children: "Primeiros passos"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
						className: "mt-3 space-y-2 text-sm text-leaf-soft",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "1. Cria os jardins onde a equipa trabalha." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "2. Marca as tarefas do dia — podes criar várias de seguida." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "3. Indica em Equipa quando estás livre, de manhã ou de tarde." })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						className: "mt-4",
						onClick: () => setGardenOpen(true),
						children: "Criar o primeiro jardim"
					})
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-4 lg:grid-cols-[minmax(0,1fr)_18rem]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-2xl",
							children: "Hoje"
						}),
						loading && !snap ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "A carregar o dia…"
						}) : tasks.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
							title: "Dia limpo",
							body: "Não há tarefas marcadas para hoje. Se o trabalho é amanhã, marca já — podes pôr vários jardins no mesmo dia.",
							action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								onClick: () => {
									setEditing(null);
									setTaskOpen(true);
								},
								children: "Marcar tarefa"
							})
						}) : tasks.map((task) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TaskCard, {
							task,
							gardenName: gardenName(task.gardenId),
							members,
							onDone: () => {
								const nextDone = task.status !== "feita";
								markDone(task.id, nextDone).then((ok) => {
									if (ok && nextDone) toast.success("Marcada como feita", { action: {
										label: "Registar",
										onClick: () => setLogging(task)
									} });
								});
							},
							onPostpone: (date) => {
								postpone(task.id, date).then((ok) => {
									if (ok) toast.success("Tarefa adiada");
								});
							},
							onEdit: () => {
								setEditing(task);
								setTaskOpen(true);
							},
							onLog: () => setLogging(task),
							onDelete: () => {
								removeTask(task.id).then((ok) => {
									if (ok) toast.success("Tarefa eliminada");
								});
							}
						}, task.id)),
						next.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "pt-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-2xl",
								children: "Amanhã"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-2 space-y-2",
								children: next.map((task) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-center justify-between gap-3 rounded-lg border border-line bg-card px-3 py-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block text-sm font-semibold",
										children: task.title
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs text-muted",
										children: gardenName(task.gardenId) ?? "Sem jardim"
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/agenda",
										className: "text-sm font-semibold text-leaf",
										children: "Ver"
									})]
								}, task.id))
							})]
						}) : null
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-2xl",
							children: "Quem está"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-xl border border-line bg-card p-4",
							children: [available.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: "Ninguém marcou disponibilidade para hoje."
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "space-y-2",
								children: available.map((slot) => {
									const person = members.find((member) => member.id === slot.userId);
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex items-center justify-between gap-3 text-sm",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-medium",
											children: person?.name ?? "Colega"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-muted",
											children: periodLabel(slot.morning, slot.afternoon)
										})]
									}, slot.userId);
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/equipa",
								className: "mt-3 inline-flex h-11 items-center text-sm font-semibold text-leaf",
								children: "Ver a semana da equipa"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "flex w-full items-start gap-3 rounded-xl border border-line bg-card p-4 text-left",
							onClick: () => {
								if (typeof Notification === "undefined") {
									toast.error("Este browser não mostra avisos.");
									return;
								}
								Notification.requestPermission().then((permission) => {
									if (permission !== "granted") {
										toast.error("Avisos bloqueados nas definições do telemóvel.");
										return;
									}
									localStorage.setItem(NOTIFY_KEY, "1");
									setNotifyOn(true);
									toast.success("Vais receber um aviso ao abrir a app, se houver trabalho hoje.");
								});
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { className: "mt-0.5 h-5 w-5 text-leaf" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-sm font-semibold",
								children: notifyOn ? "Avisos do dia ativos" : "Ativar aviso do dia"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm text-muted",
								children: "Quando abres a app e ainda há tarefas por fazer."
							})] })]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TaskSheet, {
				open: taskOpen,
				task: editing,
				initialDate: today,
				members,
				gardens,
				onClose: () => setTaskOpen(false)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogSheet, {
				open: Boolean(logging),
				task: logging,
				onClose: () => setLogging(null)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GardenSheet, {
				open: gardenOpen,
				onClose: () => setGardenOpen(false)
			})
		]
	});
}
//#endregion
export { TodayPage as component };
