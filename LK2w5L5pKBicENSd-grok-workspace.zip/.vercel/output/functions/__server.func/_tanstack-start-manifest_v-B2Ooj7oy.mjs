//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-B2Ooj7oy.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/_app",
			"/login",
			"/api/auth/$"
		],
		preloads: [
			"/assets/index-DHUbqwYK.js",
			"/assets/react-DB-4Zxce.js",
			"/assets/preload-helper-CJXhTz2Y.js",
			"/assets/link-CIFrBv3d.js",
			"/assets/useMatch-BzAce1wB.js",
			"/assets/createLucideIcon-Cnp8YCEh.js",
			"/assets/useRouter-DTQ3YH1D.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DHUbqwYK.js"
		} }]
	},
	"/_app": {
		filePath: "/workspace/src/routes/_app.tsx",
		children: [
			"/_app/agenda",
			"/_app/equipa",
			"/_app/jardins",
			"/_app/"
		],
		preloads: [
			"/assets/_app-KCVwUjam.js",
			"/assets/store-D6a9XUlD.js",
			"/assets/ui-DCTf75PA.js",
			"/assets/client-cLw6edTc.js"
		]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-DsGHtgNq.js",
			"/assets/ui-DCTf75PA.js",
			"/assets/client-cLw6edTc.js"
		]
	},
	"/_app/agenda": {
		filePath: "/workspace/src/routes/_app/agenda.tsx",
		children: void 0,
		preloads: [
			"/assets/agenda-DmdvYgMW.js",
			"/assets/task-card-CCQ_JsRD.js",
			"/assets/chevron-right-D0aMHnrV.js",
			"/assets/plus-DsbXluc2.js",
			"/assets/sheets-BRpM3-rZ.js"
		]
	},
	"/_app/equipa": {
		filePath: "/workspace/src/routes/_app/equipa.tsx",
		children: void 0,
		preloads: ["/assets/equipa-BZP6AOwN.js", "/assets/chevron-right-D0aMHnrV.js"]
	},
	"/_app/jardins": {
		filePath: "/workspace/src/routes/_app/jardins.tsx",
		children: ["/_app/jardins/$gardenId"],
		preloads: [
			"/assets/jardins-B_trdWC-.js",
			"/assets/map-pin-ib8PBhkE.js",
			"/assets/plus-DsbXluc2.js",
			"/assets/sheets-BRpM3-rZ.js"
		]
	},
	"/_app/": {
		filePath: "/workspace/src/routes/_app/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_app-DBjViVsX.js",
			"/assets/task-card-CCQ_JsRD.js",
			"/assets/plus-DsbXluc2.js",
			"/assets/sheets-BRpM3-rZ.js"
		]
	},
	"/_app/jardins/$gardenId": {
		filePath: "/workspace/src/routes/_app/jardins.$gardenId.tsx",
		children: void 0,
		preloads: ["/assets/jardins._gardenId-DtfampOw.js", "/assets/task-card-CCQ_JsRD.js"]
	}
} });
//#endregion
export { tsrStartManifest };
