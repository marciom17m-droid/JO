import { addDays, differenceInCalendarDays, format, isToday, isTomorrow, isYesterday } from "date-fns";
import { pt } from "date-fns/locale";

export function ymd(date: Date): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

export function parseDay(iso: string): Date {
  const [y, m, d] = iso.split("-").map(Number);
  return new Date(y, (m ?? 1) - 1, d ?? 1);
}

export function addDay(iso: string, days: number): string {
  return ymd(addDays(parseDay(iso), days));
}

export function todayIso(): string {
  return ymd(new Date());
}

export function weekdayStart(iso: string): string {
  const date = parseDay(iso);
  const day = date.getDay();
  const delta = day === 0 ? -6 : 1 - day;
  return ymd(addDays(date, delta));
}

export function dayLabel(iso: string): string {
  const date = parseDay(iso);
  if (isToday(date)) return "Hoje";
  if (isTomorrow(date)) return "Amanhã";
  if (isYesterday(date)) return "Ontem";
  const label = format(date, "EEE, d MMM", { locale: pt });
  return label.replace(".", "");
}

export function longDate(iso: string): string {
  const label = format(parseDay(iso), "EEEE, d 'de' MMMM", { locale: pt });
  return label.charAt(0).toUpperCase() + label.slice(1);
}

export function monthTitle(iso: string): string {
  const label = format(parseDay(iso), "MMMM yyyy", { locale: pt });
  return label.charAt(0).toUpperCase() + label.slice(1);
}

export function shortWeekday(iso: string): string {
  const label = format(parseDay(iso), "EEE", { locale: pt }).replace(".", "");
  return label.charAt(0).toUpperCase() + label.slice(1);
}

export function greeting(name: string | null | undefined): string {
  const hour = new Date().getHours();
  const hello = hour < 12 ? "Bom dia" : hour < 19 ? "Boa tarde" : "Boa noite";
  const first = (name ?? "").trim().split(/\s+/)[0];
  return first ? `${hello}, ${first}` : hello;
}

export function initials(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return "?";
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}

export function formatMinutes(total: number): string {
  if (total <= 0) return "0 min";
  const h = Math.floor(total / 60);
  const m = total % 60;
  if (h === 0) return `${m} min`;
  if (m === 0) return `${h} h`;
  return `${h} h ${m} min`;
}

export function interventionCopy(iso: string | null | undefined): {
  lead: string;
  when: string;
  stale: boolean;
} {
  if (!iso) return { lead: "Ainda sem intervenção", when: "", stale: true };
  const days = differenceInCalendarDays(parseDay(todayIso()), parseDay(iso));
  let rel = "hoje";
  if (days === 1) rel = "ontem";
  else if (days > 1 && days < 14) rel = `há ${days} dias`;
  else if (days >= 14 && days < 60) {
    const weeks = Math.floor(days / 7);
    rel = weeks === 1 ? "há 1 semana" : `há ${weeks} semanas`;
  } else if (days >= 60 && days < 365) {
    const months = Math.max(1, Math.floor(days / 30));
    rel = months === 1 ? "há 1 mês" : `há ${months} meses`;
  } else if (days >= 365) {
    const years = Math.floor(days / 365);
    rel = years === 1 ? "há 1 ano" : `há ${years} anos`;
  } else if (days < 0) rel = "hoje";
  const when = format(parseDay(iso), "d MMM yyyy", { locale: pt }).replace(/\./g, "");
  return { lead: `Última vez ${rel}`, when, stale: days >= 21 };
}

export function mapsUrl(location: string): string {
  return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(location)}`;
}

export const STATUS_LABEL: Record<string, string> = {
  ativo: "Ativo",
  pausado: "Pausado",
  sazonal: "Sazonal",
  concluido: "Concluído",
  agendada: "Agendada",
  feita: "Feita",
};

export const SERVICE_LABEL: Record<string, string> = {
  corte: "Corte de relva",
  poda: "Poda",
  rega: "Rega",
  plantacao: "Plantação",
  limpeza: "Limpeza",
  adubacao: "Adubação",
  bordaduras: "Bordaduras",
  outro: "Outro",
};
