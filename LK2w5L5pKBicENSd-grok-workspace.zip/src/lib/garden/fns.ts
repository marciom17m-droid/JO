import { createServerFn } from "@tanstack/react-start";
import { getSql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import type { Sql } from "@/lib/db";
import type {
  Availability,
  Garden,
  GardenStatus,
  Member,
  Photo,
  Result,
  Task,
  WorkLog,
  WorkPhoto,
  Workspace,
} from "./types";
import { GARDEN_STATUSES, SERVICE_TYPES } from "./types";

const DAY = /^\d{4}-\d{2}-\d{2}$/;
const JPEG = /^data:image\/jpeg;base64,[a-z0-9+/=\s]+$/i;
const MAX_PHOTO = 550_000;

function fail(error: string): Result {
  return { ok: false, error };
}

function text(value: unknown, max: number): string {
  return String(value ?? "").replace(/\s+/g, " ").trim().slice(0, max);
}

function notes(value: unknown): string {
  return String(value ?? "").trim().slice(0, 4000);
}

function day(value: unknown): string | null {
  const raw = String(value ?? "");
  return DAY.test(raw) ? raw : null;
}

function iso(value: unknown): string | null {
  if (value == null) return null;
  if (value instanceof Date) return value.toISOString();
  const raw = String(value);
  return raw.length ? raw : null;
}

function dateOnly(value: unknown): string {
  const raw = String(value ?? "");
  return raw.slice(0, 10);
}

function jpeg(value: unknown): string | null {
  const raw = String(value ?? "");
  if (!JPEG.test(raw) || raw.length > MAX_PHOTO) return null;
  return raw;
}

async function memberSet(sql: Sql): Promise<Set<string>> {
  const rows = await sql<{ id: string }>`select id from "user"`;
  return new Set(rows.map((row) => row.id));
}

/** Primeira conta abre a equipa. As seguintes só entram com convite pelo email. */
async function membership(sql: Sql, userId: string): Promise<"ok" | "blocked"> {
  const me = await sql<{ email: string }>`select email from "user" where id = ${userId}`;
  if (!me.length) return "blocked";
  const email = me[0].email.trim().toLowerCase();
  const first = await sql<{ id: string }>`select id from "user" order by "createdAt" asc limit 1`;
  if (first[0]?.id === userId) return "ok";
  const invited = await sql<{ email: string }>`select email from invites where email = ${email}`;
  return invited.length ? "ok" : "blocked";
}

async function authorizedSql(userId: string): Promise<Sql> {
  const sql = await getSql();
  if ((await membership(sql, userId)) === "blocked") {
    throw new Error("NOT_INVITED");
  }
  return sql;
}

function emptyWorkspace(from: string, to: string): Workspace {
  return {
    members: [],
    gardens: [],
    tasks: [],
    availability: [],
    logs: [],
    invites: [],
    from,
    to,
    blocked: true,
  };
}

export const getWorkspace = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { from?: string; to?: string }) => input)
  .handler(async ({ context, data }): Promise<Workspace> => {
    const from = day(data?.from) ?? "2000-01-01";
    const to = day(data?.to) ?? "2100-01-01";
    let sql: Sql;
    try {
      sql = await authorizedSql(context.userId);
    } catch (err) {
      if (err instanceof Error && err.message === "NOT_INVITED") return emptyWorkspace(from, to);
      throw err;
    }

    const members = await sql<{
      id: string;
      name: string;
      email: string;
      image: string | null;
    }>`select id, name, email, image from "user" order by name asc`;

    const gardenRows = await sql<{
      id: string;
      name: string;
      location: string;
      notes: string;
      status: string;
      created_by: string;
      updated_at: unknown;
    }>`select id, name, location, notes, status, created_by, updated_at
       from gardens order by name asc`;

    const taskRows = await sql<{
      id: string;
      garden_id: string | null;
      title: string;
      scheduled_date: unknown;
      status: string;
      notes: string;
      postponed_from: unknown;
      created_by: string;
      completed_by: string | null;
      completed_at: unknown;
    }>`select id, garden_id, title, scheduled_date, status, notes, postponed_from,
              created_by, completed_by, completed_at
       from tasks
       where scheduled_date between ${from}::date and ${to}::date
       order by scheduled_date asc, title asc`;

    const links = await sql<{ task_id: string; user_id: string }>`
      select task_id, user_id from task_assignees
    `;
    const assignees = new Map<string, string[]>();
    for (const link of links) {
      const list = assignees.get(link.task_id) ?? [];
      list.push(link.user_id);
      assignees.set(link.task_id, list);
    }

    const availability = await sql<{
      user_id: string;
      day: unknown;
      morning: boolean;
      afternoon: boolean;
    }>`select user_id, day, morning, afternoon
       from availability
       where day between ${from}::date and ${to}::date`;

    const logs = await sql<{
      id: string;
      task_id: string;
      user_id: string;
      minutes: number | null;
      service_type: string;
      materials: string;
      notes: string;
      photo_count: number;
    }>`select wl.id, wl.task_id, wl.user_id, wl.minutes, wl.service_type, wl.materials, wl.notes,
              (select count(*) from work_photos wp where wp.work_log_id = wl.id) as photo_count
       from work_logs wl
       where wl.task_id in (
         select id from tasks where scheduled_date between ${from}::date and ${to}::date
       )`;

    const visits = await sql<{ garden_id: string; last_done: unknown }>`
      select garden_id,
             max(coalesce(completed_at::date, scheduled_date)) as last_done
      from tasks
      where status = 'feita' and garden_id is not null
      group by garden_id
    `;
    const lastByGarden = new Map(visits.map((row) => [row.garden_id, dateOnly(row.last_done)]));

    const inviteRows = await sql<{ email: string }>`select email from invites order by email asc`;

    const gardens: Garden[] = gardenRows.map((row) => ({
      id: row.id,
      name: row.name,
      location: row.location,
      notes: row.notes,
      status: (GARDEN_STATUSES as readonly string[]).includes(row.status)
        ? (row.status as GardenStatus)
        : "ativo",
      createdBy: row.created_by,
      updatedAt: iso(row.updated_at) ?? "",
      lastDone: lastByGarden.get(row.id) || null,
    }));

    const tasks: Task[] = taskRows.map((row) => ({
      id: row.id,
      gardenId: row.garden_id,
      title: row.title,
      scheduledDate: dateOnly(row.scheduled_date),
      status: row.status === "feita" ? "feita" : "agendada",
      notes: row.notes,
      postponedFrom: row.postponed_from ? dateOnly(row.postponed_from) : null,
      createdBy: row.created_by,
      completedBy: row.completed_by,
      completedAt: iso(row.completed_at),
      assigneeIds: assignees.get(row.id) ?? [],
    }));

    const slots: Availability[] = availability.map((row) => ({
      userId: row.user_id,
      day: dateOnly(row.day),
      morning: Boolean(row.morning),
      afternoon: Boolean(row.afternoon),
    }));

    const work: WorkLog[] = logs.map((row) => ({
      id: row.id,
      taskId: row.task_id,
      userId: row.user_id,
      minutes: row.minutes == null ? null : Number(row.minutes),
      serviceType: row.service_type,
      materials: row.materials,
      notes: row.notes,
      photoCount: Number(row.photo_count) || 0,
    }));

    const people: Member[] = members.map((row) => ({
      id: row.id,
      name: row.name,
      email: row.email,
      image: row.image,
    }));

    return {
      members: people,
      gardens,
      tasks,
      availability: slots,
      logs: work,
      invites: inviteRows.map((row) => row.email),
      from,
      to,
    };
  });

type GardenInput = {
  id?: string;
  name?: string;
  location?: string;
  notes?: string;
  status?: string;
};

export const saveGarden = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: GardenInput) => input)
  .handler(async ({ context, data }): Promise<Result> => {
    const name = text(data?.name, 120);
    if (name.length < 2) return fail("O nome do jardim precisa de pelo menos 2 caracteres.");
    const location = text(data?.location, 240);
    const body = notes(data?.notes);
    const status = (GARDEN_STATUSES as readonly string[]).includes(String(data?.status))
      ? String(data.status)
      : "ativo";
    const sql = await authorizedSql(context.userId);
    const id = text(data?.id, 80);
    if (id) {
      const existing = await sql<{ id: string }>`select id from gardens where id = ${id}`;
      if (!existing.length) return fail("Esse jardim já não existe.");
      await sql`update gardens
                set name = ${name}, location = ${location}, notes = ${body},
                    status = ${status}, updated_at = now()
                where id = ${id}`;
      return { ok: true };
    }
    const next = crypto.randomUUID();
    await sql`insert into gardens (id, name, location, notes, status, created_by)
              values (${next}, ${name}, ${location}, ${body}, ${status}, ${context.userId})`;
    return { ok: true };
  });

export const deleteGarden = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { id?: string }) => input)
  .handler(async ({ context, data }): Promise<Result> => {
    const id = text(data?.id, 80);
    if (!id) return fail("Jardim inválido.");
    const sql = await authorizedSql(context.userId);
    await sql`delete from gardens where id = ${id}`;
    return { ok: true };
  });

export const listGardenPhotos = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { gardenId?: string }) => input)
  .handler(async ({ context, data }): Promise<Photo[]> => {
    const gardenId = text(data?.gardenId, 80);
    const sql = await authorizedSql(context.userId);
    const rows = await sql<{ id: string; data_url: string; created_at: unknown }>`
      select id, data_url, created_at from garden_photos
      where garden_id = ${gardenId}
      order by created_at asc
    `;
    return rows.map((row) => ({
      id: row.id,
      dataUrl: row.data_url,
      createdAt: iso(row.created_at) ?? "",
    }));
  });

export const addGardenPhoto = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { gardenId?: string; dataUrl?: string }) => input)
  .handler(async ({ context, data }): Promise<Result> => {
    const gardenId = text(data?.gardenId, 80);
    const dataUrl = jpeg(data?.dataUrl);
    if (!gardenId || !dataUrl) return fail("Foto inválida.");
    const sql = await authorizedSql(context.userId);
    const garden = await sql<{ id: string }>`select id from gardens where id = ${gardenId}`;
    if (!garden.length) return fail("Esse jardim já não existe.");
    const count = await sql<{ n: number }>`select count(*) as n from garden_photos where garden_id = ${gardenId}`;
    if (Number(count[0]?.n ?? 0) >= 12) return fail("Este jardim já tem 12 fotos. Apaga uma para adicionar outra.");
    await sql`insert into garden_photos (id, garden_id, data_url, created_by)
              values (${crypto.randomUUID()}, ${gardenId}, ${dataUrl}, ${context.userId})`;
    return { ok: true };
  });

export const deleteGardenPhoto = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { id?: string }) => input)
  .handler(async ({ context, data }): Promise<Result> => {
    const id = text(data?.id, 80);
    if (!id) return fail("Foto inválida.");
    const sql = await authorizedSql(context.userId);
    await sql`delete from garden_photos where id = ${id}`;
    return { ok: true };
  });

type TaskInput = {
  id?: string;
  title?: string;
  gardenId?: string | null;
  scheduledDate?: string;
  notes?: string;
  assigneeIds?: string[];
};

export const saveTask = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: TaskInput) => input)
  .handler(async ({ context, data }): Promise<Result> => {
    const title = text(data?.title, 160);
    if (title.length < 2) return fail("A tarefa precisa de um título.");
    const scheduled = day(data?.scheduledDate);
    if (!scheduled) return fail("Escolhe o dia.");
    const body = notes(data?.notes);
    const sql = await authorizedSql(context.userId);
    const people = await memberSet(sql);
    const wanted = Array.isArray(data?.assigneeIds) ? data.assigneeIds : [];
    const assignees = [...new Set(wanted.map((id) => String(id)).filter((id) => people.has(id)))];
    if (!assignees.length) {
      if (!people.has(context.userId)) return fail("Ainda não há pessoas para atribuir.");
      assignees.push(context.userId);
    }
    let gardenId: string | null = data?.gardenId ? text(data.gardenId, 80) : null;
    if (gardenId) {
      const garden = await sql<{ id: string }>`select id from gardens where id = ${gardenId}`;
      if (!garden.length) gardenId = null;
    }
    const id = text(data?.id, 80);
    if (id) {
      const existing = await sql<{ id: string }>`select id from tasks where id = ${id}`;
      if (!existing.length) return fail("Essa tarefa já não existe.");
      await sql`update tasks
                set title = ${title}, garden_id = ${gardenId}, scheduled_date = ${scheduled}::date,
                    notes = ${body}, updated_at = now()
                where id = ${id}`;
      await sql`delete from task_assignees where task_id = ${id}`;
      for (const userId of assignees) {
        await sql`insert into task_assignees (task_id, user_id) values (${id}, ${userId})`;
      }
      return { ok: true };
    }
    const next = crypto.randomUUID();
    await sql`insert into tasks (id, garden_id, title, scheduled_date, notes, created_by)
              values (${next}, ${gardenId}, ${title}, ${scheduled}::date, ${body}, ${context.userId})`;
    for (const userId of assignees) {
      await sql`insert into task_assignees (task_id, user_id) values (${next}, ${userId})`;
    }
    return { ok: true };
  });

export const deleteTask = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { id?: string }) => input)
  .handler(async ({ context, data }): Promise<Result> => {
    const id = text(data?.id, 80);
    if (!id) return fail("Tarefa inválida.");
    const sql = await authorizedSql(context.userId);
    await sql`delete from tasks where id = ${id}`;
    return { ok: true };
  });

export const setTaskDone = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { id?: string; done?: boolean }) => input)
  .handler(async ({ context, data }): Promise<Result> => {
    const id = text(data?.id, 80);
    if (!id) return fail("Tarefa inválida.");
    const sql = await authorizedSql(context.userId);
    if (data?.done) {
      await sql`update tasks
                set status = 'feita', completed_by = ${context.userId}, completed_at = now(), updated_at = now()
                where id = ${id}`;
    } else {
      await sql`update tasks
                set status = 'agendada', completed_by = null, completed_at = null, updated_at = now()
                where id = ${id}`;
    }
    return { ok: true };
  });

export const postponeTask = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { id?: string; date?: string }) => input)
  .handler(async ({ context, data }): Promise<Result> => {
    const id = text(data?.id, 80);
    const next = day(data?.date);
    if (!id || !next) return fail("Escolhe o novo dia.");
    const sql = await authorizedSql(context.userId);
    const rows = await sql<{ scheduled_date: unknown }>`select scheduled_date from tasks where id = ${id}`;
    if (!rows.length) return fail("Essa tarefa já não existe.");
    const current = dateOnly(rows[0].scheduled_date);
    if (current === next) return { ok: true };
    await sql`update tasks
              set scheduled_date = ${next}::date,
                  postponed_from = coalesce(postponed_from, ${current}::date),
                  status = 'agendada',
                  completed_by = null,
                  completed_at = null,
                  updated_at = now()
              where id = ${id}`;
    return { ok: true };
  });

type LogInput = {
  taskId?: string;
  minutes?: number | null;
  serviceType?: string;
  materials?: string;
  notes?: string;
  photos?: string[];
};

export const saveWorkLog = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: LogInput) => input)
  .handler(async ({ context, data }): Promise<Result> => {
    const taskId = text(data?.taskId, 80);
    if (!taskId) return fail("Tarefa inválida.");
    const service = (SERVICE_TYPES as readonly string[]).includes(String(data?.serviceType))
      ? String(data.serviceType)
      : "";
    const materials = text(data?.materials, 400);
    const body = notes(data?.notes);
    let minutes: number | null = null;
    if (data?.minutes != null && data.minutes !== ("" as unknown)) {
      const n = Number(data.minutes);
      if (!Number.isFinite(n) || n < 0 || n > 24 * 60) return fail("O tempo tem de estar entre 0 e 1440 minutos.");
      minutes = Math.round(n);
    }
    const photos = (Array.isArray(data?.photos) ? data.photos : [])
      .map((item) => jpeg(item))
      .filter((item): item is string => Boolean(item))
      .slice(0, 4);
    const sql = await authorizedSql(context.userId);
    const task = await sql<{ id: string }>`select id from tasks where id = ${taskId}`;
    if (!task.length) return fail("Essa tarefa já não existe.");
    const existing = await sql<{ id: string }>`
      select id from work_logs where task_id = ${taskId} and user_id = ${context.userId}
    `;
    let logId = existing[0]?.id;
    if (logId) {
      await sql`update work_logs
                set minutes = ${minutes}, service_type = ${service}, materials = ${materials}, notes = ${body}
                where id = ${logId}`;
    } else {
      if (minutes == null && !service && !materials && !body && photos.length === 0) {
        return { ok: true };
      }
      logId = crypto.randomUUID();
      await sql`insert into work_logs (id, task_id, user_id, minutes, service_type, materials, notes)
                values (${logId}, ${taskId}, ${context.userId}, ${minutes}, ${service}, ${materials}, ${body})`;
    }
    const count = await sql<{ n: number }>`select count(*) as n from work_photos where work_log_id = ${logId}`;
    const room = Math.max(0, 6 - Number(count[0]?.n ?? 0));
    for (const photo of photos.slice(0, room)) {
      await sql`insert into work_photos (id, work_log_id, data_url)
                values (${crypto.randomUUID()}, ${logId}, ${photo})`;
    }
    return { ok: true };
  });

export const listWorkPhotos = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { taskId?: string }) => input)
  .handler(async ({ context, data }): Promise<WorkPhoto[]> => {
    const taskId = text(data?.taskId, 80);
    const sql = await authorizedSql(context.userId);
    const rows = await sql<{
      id: string;
      work_log_id: string;
      data_url: string;
      created_at: unknown;
    }>`select wp.id, wp.work_log_id, wp.data_url, wp.created_at
       from work_photos wp
       join work_logs wl on wl.id = wp.work_log_id
       where wl.task_id = ${taskId}
       order by wp.created_at asc`;
    return rows.map((row) => ({
      id: row.id,
      workLogId: row.work_log_id,
      dataUrl: row.data_url,
      createdAt: iso(row.created_at) ?? "",
    }));
  });

export const deleteWorkPhoto = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { id?: string }) => input)
  .handler(async ({ context, data }): Promise<Result> => {
    const id = text(data?.id, 80);
    if (!id) return fail("Foto inválida.");
    const sql = await authorizedSql(context.userId);
    await sql`delete from work_photos where id = ${id}`;
    return { ok: true };
  });

export const setAvailability = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { day?: string; morning?: boolean; afternoon?: boolean }) => input)
  .handler(async ({ context, data }): Promise<Result> => {
    const when = day(data?.day);
    if (!when) return fail("Dia inválido.");
    const morning = Boolean(data?.morning);
    const afternoon = Boolean(data?.afternoon);
    const sql = await authorizedSql(context.userId);
    if (!morning && !afternoon) {
      await sql`delete from availability where user_id = ${context.userId} and day = ${when}::date`;
      return { ok: true };
    }
    await sql`insert into availability (user_id, day, morning, afternoon)
              values (${context.userId}, ${when}::date, ${morning}, ${afternoon})
              on conflict (user_id, day)
              do update set morning = ${morning}, afternoon = ${afternoon}`;
    return { ok: true };
  });

export const invitePerson = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { email?: string }) => input)
  .handler(async ({ context, data }): Promise<Result> => {
    const email = text(data?.email, 160).toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return fail("Indica um email válido.");
    const sql = await authorizedSql(context.userId);
    await sql`insert into invites (email, invited_by) values (${email}, ${context.userId})
              on conflict (email) do nothing`;
    return { ok: true };
  });
