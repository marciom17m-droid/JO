export const GARDEN_STATUSES = ["ativo", "pausado", "sazonal", "concluido"] as const;
export type GardenStatus = (typeof GARDEN_STATUSES)[number];

export const SERVICE_TYPES = [
  "corte",
  "poda",
  "rega",
  "plantacao",
  "limpeza",
  "adubacao",
  "bordaduras",
  "outro",
] as const;
export type ServiceType = (typeof SERVICE_TYPES)[number];

export type Member = {
  id: string;
  name: string;
  email: string;
  image: string | null;
};

export type Garden = {
  id: string;
  name: string;
  location: string;
  notes: string;
  status: GardenStatus;
  createdBy: string;
  updatedAt: string;
  /** Dia da última tarefa dada como feita, ou null se nunca houve intervenção. */
  lastDone: string | null;
};

export type TaskStatus = "agendada" | "feita";

export type Task = {
  id: string;
  gardenId: string | null;
  title: string;
  scheduledDate: string;
  status: TaskStatus;
  notes: string;
  postponedFrom: string | null;
  createdBy: string;
  completedBy: string | null;
  completedAt: string | null;
  assigneeIds: string[];
};

export type Availability = {
  userId: string;
  day: string;
  morning: boolean;
  afternoon: boolean;
};

export type WorkLog = {
  id: string;
  taskId: string;
  userId: string;
  minutes: number | null;
  serviceType: string;
  materials: string;
  notes: string;
  photoCount: number;
};

export type Workspace = {
  members: Member[];
  gardens: Garden[];
  tasks: Task[];
  availability: Availability[];
  logs: WorkLog[];
  invites: string[];
  from: string;
  to: string;
  blocked?: boolean;
};

export type Photo = {
  id: string;
  dataUrl: string;
  createdAt: string;
};

export type WorkPhoto = Photo & { workLogId: string };

export type Result = { ok: true } | { ok: false; error: string };
