import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { toast } from "sonner";
import {
  deleteGarden,
  deleteTask,
  getWorkspace,
  invitePerson,
  postponeTask,
  saveGarden,
  saveTask,
  saveWorkLog,
  setAvailability,
  setTaskDone,
} from "./fns";
import { addDay, todayIso } from "./format";
import type { Availability, Result, Workspace } from "./types";

const CACHE_PREFIX = "jardins-outros.snapshot.v2.";

function cacheKey(userId: string) {
  return `${CACHE_PREFIX}${userId}`;
}

type GardenDraft = {
  id?: string;
  name: string;
  location: string;
  notes: string;
  status: string;
};

type TaskDraft = {
  id?: string;
  title: string;
  gardenId: string | null;
  scheduledDate: string;
  notes: string;
  assigneeIds: string[];
};

type LogDraft = {
  taskId: string;
  minutes: number | null;
  serviceType: string;
  materials: string;
  notes: string;
  photos: string[];
};

type Store = {
  snap: Workspace | null;
  loading: boolean;
  offline: boolean;
  stale: boolean;
  error: string | null;
  refresh: () => Promise<void>;
  saveGarden: (draft: GardenDraft) => Promise<boolean>;
  removeGarden: (id: string) => Promise<boolean>;
  saveTask: (draft: TaskDraft) => Promise<boolean>;
  removeTask: (id: string) => Promise<boolean>;
  markDone: (id: string, done: boolean) => Promise<boolean>;
  postpone: (id: string, date: string) => Promise<boolean>;
  saveLog: (draft: LogDraft) => Promise<boolean>;
  setMine: (day: string, morning: boolean, afternoon: boolean) => Promise<void>;
  invite: (email: string) => Promise<boolean>;
};

const Ctx = createContext<Store | null>(null);

function readCache(userId: string): Workspace | null {
  try {
    const raw = localStorage.getItem(cacheKey(userId));
    if (!raw) return null;
    return JSON.parse(raw) as Workspace;
  } catch {
    return null;
  }
}

function writeCache(userId: string, snap: Workspace) {
  try {
    localStorage.setItem(cacheKey(userId), JSON.stringify(snap));
  } catch {
    /* quota — a vista offline fica de fora */
  }
}

async function settle(result: Result): Promise<boolean> {
  if (!result.ok) {
    toast.error(result.error);
    return false;
  }
  return true;
}

export function WorkspaceProvider({
  userId,
  children,
}: {
  userId: string;
  children: ReactNode;
}) {
  const [snap, setSnap] = useState<Workspace | null>(null);
  const [loading, setLoading] = useState(true);
  const [offline, setOffline] = useState(false);
  const [stale, setStale] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    const from = addDay(todayIso(), -400);
    const to = addDay(todayIso(), 220);
    try {
      const next = await getWorkspace({ data: { from, to } });
      setSnap(next);
      if (!next.blocked) writeCache(userId, next);
      setError(null);
      setStale(false);
    } catch (err) {
      const message = err instanceof Error ? err.message : "";
      if (message.includes("NOT_INVITED")) {
        setSnap({
          members: [],
          gardens: [],
          tasks: [],
          availability: [],
          logs: [],
          invites: [],
          from,
          to,
          blocked: true,
        });
        setError(null);
        setStale(false);
        setLoading(false);
        return;
      }
      const cached = readCache(userId);
      if (cached) {
        setSnap(cached);
        setStale(true);
        setError(null);
      } else if (message.toLowerCase().includes("unauthorized")) {
        setError("A sessão expirou. Entra outra vez.");
      } else {
        setError("Não foi possível carregar a equipa. Tenta de novo.");
      }
    } finally {
      setLoading(false);
    }
  }, [userId]);

  useEffect(() => {
    const cached = readCache(userId);
    if (cached) setSnap(cached);
    void refresh();
  }, [refresh, userId]);

  useEffect(() => {
    const sync = () => setOffline(!navigator.onLine);
    sync();
    window.addEventListener("online", sync);
    window.addEventListener("offline", sync);
    return () => {
      window.removeEventListener("online", sync);
      window.removeEventListener("offline", sync);
    };
  }, []);

  const guard = useCallback(async (work: () => Promise<Result>) => {
    if (!navigator.onLine) {
      toast.error("Sem ligação. Podes ver o que ficou guardado, mas não alterar.");
      return false;
    }
    try {
      const ok = await settle(await work());
      if (ok) await refresh();
      return ok;
    } catch {
      toast.error("Não foi possível guardar. Tenta outra vez.");
      return false;
    }
  }, [refresh]);

  const value = useMemo<Store>(
    () => ({
      snap,
      loading,
      offline,
      stale,
      error,
      refresh,
      saveGarden: (draft) => guard(() => saveGarden({ data: draft })),
      removeGarden: (id) => guard(() => deleteGarden({ data: { id } })),
      saveTask: (draft) => guard(() => saveTask({ data: draft })),
      removeTask: (id) => guard(() => deleteTask({ data: { id } })),
      markDone: (id, done) => guard(() => setTaskDone({ data: { id, done } })),
      postpone: (id, date) => guard(() => postponeTask({ data: { id, date } })),
      saveLog: (draft) => guard(() => saveWorkLog({ data: draft })),
      invite: (email) => guard(() => invitePerson({ data: { email } })),
      setMine: async (day, morning, afternoon) => {
        if (!navigator.onLine) {
          toast.error("Sem ligação. A disponibilidade atualiza quando voltares a estar online.");
          return;
        }
        setSnap((prev) => {
          if (!prev) return prev;
          const rest = prev.availability.filter((slot) => !(slot.userId === userId && slot.day === day));
          const availability: Availability[] =
            morning || afternoon ? [...rest, { userId, day, morning, afternoon }] : rest;
          return { ...prev, availability };
        });
        try {
          const result = await setAvailability({ data: { day, morning, afternoon } });
          if (!result.ok) {
            toast.error(result.error);
            await refresh();
          }
        } catch {
          toast.error("Não foi possível atualizar a disponibilidade.");
          await refresh();
        }
      },
    }),
    [snap, loading, offline, stale, error, refresh, guard, userId],
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useWorkspace(): Store {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("Workspace em falta");
  return ctx;
}
