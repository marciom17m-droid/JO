import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { addDays, eachDayOfInterval, endOfMonth, endOfWeek, startOfMonth, startOfWeek } from "date-fns";
import { ChevronLeft, ChevronRight, Plus } from "lucide-react";
import { toast } from "sonner";
import { LogSheet, TaskSheet } from "@/components/sheets";
import { TaskCard } from "@/components/task-card";
import { Button, cx, Empty } from "@/components/ui";
import { addDay, longDate, monthTitle, parseDay, shortWeekday, todayIso, weekdayStart, ymd } from "@/lib/garden/format";
import { useWorkspace } from "@/lib/garden/store";
import type { Task } from "@/lib/garden/types";

export const Route = createFileRoute("/_app/agenda")({
  head: () => ({ meta: [{ title: "Agenda · Jardins e outros" }] }),
  component: AgendaPage,
});

function AgendaPage() {
  const { snap, markDone, postpone, removeTask } = useWorkspace();
  const [cursor, setCursor] = useState(todayIso());
  const [selected, setSelected] = useState(todayIso());
  const [mode, setMode] = useState<"semana" | "mes">("semana");
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Task | null>(null);
  const [logging, setLogging] = useState<Task | null>(null);

  const tasks = snap?.tasks ?? [];
  const members = snap?.members ?? [];
  const gardens = snap?.gardens ?? [];
  const availability = snap?.availability ?? [];

  const weekDays = useMemo(() => {
    const start = weekdayStart(mode === "semana" ? selected : cursor);
    return Array.from({ length: 7 }, (_, index) => addDay(start, index));
  }, [mode, selected, cursor]);

  const monthDays = useMemo(() => {
    const anchor = parseDay(cursor);
    const start = startOfWeek(startOfMonth(anchor), { weekStartsOn: 1 });
    const end = endOfWeek(endOfMonth(anchor), { weekStartsOn: 1 });
    return eachDayOfInterval({ start, end }).map(ymd);
  }, [cursor]);

  const dayTasks = tasks.filter((task) => task.scheduledDate === selected);
  const gardenName = (id: string | null) => gardens.find((garden) => garden.id === id)?.name;

  function shift(dir: number) {
    if (mode === "semana") {
      const next = addDay(selected, dir * 7);
      setSelected(next);
      setCursor(next);
      return;
    }
    const next = ymd(addDays(startOfMonth(parseDay(cursor)), dir > 0 ? 32 : -1));
    const landed = ymd(startOfMonth(parseDay(next)));
    setCursor(landed);
    setSelected(landed);
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-4xl">Agenda</h1>
          <p className="text-sm text-muted">Tarefas marcadas, feitas e quem está livre.</p>
        </div>
        <div className="flex gap-2">
          <div className="grid grid-cols-2 rounded-lg bg-card p-1 ring-1 ring-line">
            {(["semana", "mes"] as const).map((item) => (
              <button
                key={item}
                type="button"
                onClick={() => setMode(item)}
                className={cx("h-10 rounded-md px-3 text-sm font-semibold", mode === item ? "bg-leaf text-card" : "text-muted")}
              >
                {item === "semana" ? "Semana" : "Mês"}
              </button>
            ))}
          </div>
          <Button
            onClick={() => {
              setEditing(null);
              setOpen(true);
            }}
          >
            <Plus className="h-4 w-4" />
            Tarefa
          </Button>
        </div>
      </div>

      <div className="flex items-center justify-between">
        <button type="button" className="grid h-11 w-11 place-items-center rounded-lg hover:bg-card" onClick={() => shift(-1)} aria-label="Anterior">
          <ChevronLeft className="h-5 w-5" />
        </button>
        <p className="font-display text-2xl capitalize">{mode === "mes" ? monthTitle(cursor) : longDate(selected)}</p>
        <button type="button" className="grid h-11 w-11 place-items-center rounded-lg hover:bg-card" onClick={() => shift(1)} aria-label="Seguinte">
          <ChevronRight className="h-5 w-5" />
        </button>
      </div>

      <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_22rem]">
        <div>
          {mode === "semana" ? (
            <div className="grid grid-cols-7 gap-1">
              {weekDays.map((day) => {
                const count = tasks.filter((task) => task.scheduledDate === day);
                const people = availability.filter((slot) => slot.day === day && (slot.morning || slot.afternoon));
                const on = day === selected;
                return (
                  <button
                    key={day}
                    type="button"
                    onClick={() => setSelected(day)}
                    className={cx(
                      "flex min-h-20 flex-col items-center rounded-lg px-1 py-2",
                      on ? "bg-leaf text-card" : "bg-card text-ink ring-1 ring-line",
                    )}
                  >
                    <span className={cx("text-xs", on ? "text-leaf-soft" : "text-muted")}>{shortWeekday(day)}</span>
                    <span className="font-display text-lg tabular-nums">{parseDay(day).getDate()}</span>
                    <span className="mt-1 flex h-2 gap-0.5">
                      {count.some((task) => task.status !== "feita") ? <i className={cx("h-1.5 w-1.5 rounded-full", on ? "bg-card" : "bg-leaf")} /> : null}
                      {count.some((task) => task.status === "feita") ? <i className={cx("h-1.5 w-1.5 rounded-full", on ? "bg-leaf-soft" : "bg-clay")} /> : null}
                    </span>
                    <span className={cx("text-xs", on ? "text-leaf-soft" : "text-muted")}>{people.length || ""}</span>
                  </button>
                );
              })}
            </div>
          ) : (
            <div>
              <div className="mb-1 grid grid-cols-7 text-center text-xs font-semibold text-muted">
                {weekDays.map((day) => (
                  <span key={day}>{shortWeekday(day)}</span>
                ))}
              </div>
              <div className="grid grid-cols-7 gap-1">
                {monthDays.map((day) => {
                  const inMonth = parseDay(day).getMonth() === parseDay(cursor).getMonth();
                  const count = tasks.filter((task) => task.scheduledDate === day);
                  const on = day === selected;
                  return (
                    <button
                      key={day}
                      type="button"
                      onClick={() => setSelected(day)}
                      className={cx(
                        "flex min-h-14 flex-col items-center justify-center rounded-lg text-sm tabular-nums",
                        on ? "bg-leaf text-card" : "bg-card ring-1 ring-line",
                        !inMonth && !on && "opacity-40",
                      )}
                    >
                      {parseDay(day).getDate()}
                      <span className="mt-1 flex h-1.5 gap-0.5">
                        {count.some((task) => task.status !== "feita") ? <i className={cx("h-1.5 w-1.5 rounded-full", on ? "bg-card" : "bg-leaf")} /> : null}
                        {count.some((task) => task.status === "feita") ? <i className={cx("h-1.5 w-1.5 rounded-full", on ? "bg-leaf-soft" : "bg-clay")} /> : null}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}
          <p className="mt-3 flex flex-wrap gap-3 text-xs text-muted">
            <span className="inline-flex items-center gap-1"><i className="h-2 w-2 rounded-full bg-leaf" /> Por fazer</span>
            <span className="inline-flex items-center gap-1"><i className="h-2 w-2 rounded-full bg-clay" /> Feita</span>
          </p>
        </div>

        <section className="space-y-3">
          <div>
            <h2 className="font-display text-2xl">{longDate(selected)}</h2>
            <AvailabilityLine day={selected} />
          </div>
          {dayTasks.length === 0 ? (
            <Empty
              title="Nada marcado"
              body="Este dia ainda não tem tarefas. Podes marcar vários jardins de uma vez."
              action={
                <Button
                  onClick={() => {
                    setEditing(null);
                    setOpen(true);
                  }}
                >
                  Marcar neste dia
                </Button>
              }
            />
          ) : (
            dayTasks.map((task) => (
              <TaskCard
                key={task.id}
                task={task}
                gardenName={gardenName(task.gardenId)}
                members={members}
                onDone={() => void markDone(task.id, task.status !== "feita")}
                onPostpone={(date) => {
                  void postpone(task.id, date).then((ok) => ok && toast.success("Tarefa adiada"));
                }}
                onEdit={() => {
                  setEditing(task);
                  setOpen(true);
                }}
                onLog={() => setLogging(task)}
                onDelete={() => void removeTask(task.id)}
              />
            ))
          )}
        </section>
      </div>

      <TaskSheet
        open={open}
        task={editing}
        initialDate={selected}
        members={members}
        gardens={gardens}
        onClose={() => setOpen(false)}
      />
      <LogSheet open={Boolean(logging)} task={logging} onClose={() => setLogging(null)} />
    </div>
  );
}

function AvailabilityLine({ day }: { day: string }) {
  const { snap } = useWorkspace();
  const slots = (snap?.availability ?? []).filter((slot) => slot.day === day && (slot.morning || slot.afternoon));
  if (!slots.length) return <p className="text-sm text-muted">Sem disponibilidade marcada.</p>;
  return (
    <p className="text-sm text-muted">
      Livres:{" "}
      {slots
        .map((slot) => {
          const name = snap?.members.find((member) => member.id === slot.userId)?.name ?? "Colega";
          const when = slot.morning && slot.afternoon ? "dia" : slot.morning ? "manhã" : "tarde";
          return `${name.split(" ")[0]} (${when})`;
        })
        .join(", ")}
    </p>
  );
}
