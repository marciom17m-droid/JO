import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { toast } from "sonner";
import { addDay, dayLabel, formatMinutes, longDate, SERVICE_LABEL, shortWeekday, todayIso, weekdayStart, parseDay } from "@/lib/garden/format";
import { useWorkspace } from "@/lib/garden/store";
import { useCurrentUser } from "@/lib/auth/use-current-user";
import { Button, cx, fieldClass } from "@/components/ui";

export const Route = createFileRoute("/_app/equipa")({
  head: () => ({ meta: [{ title: "Equipa · Jardins e outros" }] }),
  component: TeamPage,
});

function slotText(morning: boolean, afternoon: boolean) {
  if (morning && afternoon) return "Dia";
  if (morning) return "Manhã";
  if (afternoon) return "Tarde";
  return "—";
}

function TeamPage() {
  const user = useCurrentUser();
  const { snap, setMine, invite } = useWorkspace();
  const [cursor, setCursor] = useState(todayIso());
  const [tab, setTab] = useState<"disp" | "hist">("disp");
  const [span, setSpan] = useState<"mes" | "ano">("mes");
  const start = weekdayStart(cursor);
  const days = Array.from({ length: 7 }, (_, index) => addDay(start, index));
  const members = snap?.members ?? [];
  const me = user?.id ?? "";

  const range = useMemo(() => {
    const today = todayIso();
    if (span === "mes") {
      const now = new Date();
      const from = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-01`;
      return { from, to: today };
    }
    return { from: addDay(today, -365), to: today };
  }, [span]);

  const rows = members.map((member) => {
    const done = (snap?.tasks ?? []).filter((task) => {
      if (task.status !== "feita") return false;
      if (task.scheduledDate < range.from || task.scheduledDate > range.to) return false;
      const logged = snap?.logs.some((log) => log.taskId === task.id && log.userId === member.id);
      return task.assigneeIds.includes(member.id) || task.completedBy === member.id || logged;
    });
    const daysWorked = new Set(done.map((task) => task.scheduledDate)).size;
    const minutes = (snap?.logs ?? [])
      .filter((log) => log.userId === member.id && done.some((task) => task.id === log.taskId))
      .reduce((sum, log) => sum + (log.minutes ?? 0), 0);
    return { member, done, daysWorked, minutes };
  });
  const maxDays = Math.max(1, ...rows.map((row) => row.daysWorked));
  const history = rows
    .flatMap((row) => row.done.map((task) => ({ task, member: row.member })))
    .sort((a, b) => b.task.scheduledDate.localeCompare(a.task.scheduledDate) || a.task.title.localeCompare(b.task.title));

  return (
    <div className="space-y-5">
      <div>
        <h1 className="font-display text-4xl">Equipa</h1>
        <p className="text-sm text-muted">
          {members.length === 1 ? "1 pessoa" : `${members.length} pessoas`} · todas com as mesmas permissões
        </p>
      </div>

      <div className="grid grid-cols-2 rounded-lg bg-card p-1 ring-1 ring-line">
        <button type="button" onClick={() => setTab("disp")} className={cx("h-11 rounded-md text-sm font-semibold", tab === "disp" ? "bg-leaf text-card" : "text-muted")}>
          Disponibilidade
        </button>
        <button type="button" onClick={() => setTab("hist")} className={cx("h-11 rounded-md text-sm font-semibold", tab === "hist" ? "bg-leaf text-card" : "text-muted")}>
          Histórico
        </button>
      </div>

      {tab === "disp" ? (
        <div className="space-y-5">
          <section className="rounded-xl border border-line bg-card p-4">
            <h2 className="font-display text-2xl">A tua semana</h2>
            <p className="mt-1 text-sm text-muted">Toca em Manhã, Tarde ou nas duas para o dia inteiro. Podes mudar quando quiseres.</p>
            <div className="mt-4 flex items-center justify-between">
              <button type="button" className="grid h-11 w-11 place-items-center rounded-lg hover:bg-paper" aria-label="Semana anterior" onClick={() => setCursor(addDay(start, -7))}>
                <ChevronLeft className="h-5 w-5" />
              </button>
              <p className="text-sm font-medium">{longDate(start)} — {dayLabel(days[6])}</p>
              <button type="button" className="grid h-11 w-11 place-items-center rounded-lg hover:bg-paper" aria-label="Semana seguinte" onClick={() => setCursor(addDay(start, 7))}>
                <ChevronRight className="h-5 w-5" />
              </button>
            </div>
            <ul className="mt-3 space-y-2">
              {days.map((day) => {
                const slot = snap?.availability.find((item) => item.userId === me && item.day === day);
                return (
                  <li key={day} className="flex items-center justify-between gap-2 rounded-lg bg-paper px-3 py-2">
                    <span className="min-w-16">
                      <span className="block text-xs text-muted">{shortWeekday(day)}</span>
                      <span className="font-display text-lg tabular-nums">{parseDay(day).getDate()}</span>
                    </span>
                    <span className="flex gap-2">
                      <Toggle on={Boolean(slot?.morning)} label="Manhã" onClick={() => void setMine(day, !slot?.morning, Boolean(slot?.afternoon))} />
                      <Toggle on={Boolean(slot?.afternoon)} label="Tarde" onClick={() => void setMine(day, Boolean(slot?.morning), !slot?.afternoon)} />
                    </span>
                  </li>
                );
              })}
            </ul>
          </section>

          <section>
            <h2 className="font-display text-2xl">Toda a equipa</h2>
            <div className="mt-3 overflow-x-auto rounded-xl border border-line bg-card">
              <table className="w-full min-w-[36rem] border-collapse text-sm">
                <thead>
                  <tr className="text-left text-xs text-muted">
                    <th className="px-3 py-3 font-medium">Pessoa</th>
                    {days.map((day) => (
                      <th key={day} className="px-2 py-3 text-center font-medium">
                        {shortWeekday(day)}
                        <span className="block tabular-nums">{parseDay(day).getDate()}</span>
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {members.map((member) => (
                    <tr key={member.id} className="border-t border-line">
                      <th className="px-3 py-3 text-left font-semibold">{member.name}</th>
                      {days.map((day) => {
                        const slot = snap?.availability.find((item) => item.userId === member.id && item.day === day);
                        const label = slotText(Boolean(slot?.morning), Boolean(slot?.afternoon));
                        const free = label !== "—";
                        return (
                          <td key={day} className="px-1 py-2 text-center">
                            <span className={cx("inline-flex h-8 min-w-14 items-center justify-center rounded-full px-2 text-xs font-semibold", free ? "bg-leaf-soft text-leaf" : "text-muted")}>
                              {label}
                            </span>
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>

          <InviteBox members={members} invites={snap?.invites ?? []} onInvite={invite} />
        </div>
      ) : (
        <div className="space-y-5">
          <div className="flex gap-2">
            <button type="button" onClick={() => setSpan("mes")} className={cx("h-10 rounded-full px-3 text-sm font-semibold", span === "mes" ? "bg-leaf text-card" : "bg-card ring-1 ring-line")}>
              Este mês
            </button>
            <button type="button" onClick={() => setSpan("ano")} className={cx("h-10 rounded-full px-3 text-sm font-semibold", span === "ano" ? "bg-leaf text-card" : "bg-card ring-1 ring-line")}>
              Últimos 12 meses
            </button>
          </div>
          <ul className="space-y-3">
            {rows.map((row) => (
              <li key={row.member.id} className="rounded-xl border border-line bg-card p-4">
                <div className="flex items-baseline justify-between gap-3">
                  <h3 className="font-display text-xl">{row.member.name}</h3>
                  <p className="text-sm tabular-nums text-muted">
                    {row.daysWorked} {row.daysWorked === 1 ? "dia" : "dias"} · {row.done.length} {row.done.length === 1 ? "tarefa" : "tarefas"}
                    {row.minutes ? ` · ${formatMinutes(row.minutes)}` : ""}
                  </p>
                </div>
                <div className="mt-3 h-2 overflow-hidden rounded-full bg-paper">
                  <div className="h-full rounded-full bg-leaf" style={{ width: `${(row.daysWorked / maxDays) * 100}%` }} />
                </div>
              </li>
            ))}
          </ul>
          <section className="space-y-2">
            <h2 className="font-display text-2xl">O que foi feito</h2>
            {history.length === 0 ? (
              <p className="text-sm text-muted">Ainda não há tarefas concluídas neste período.</p>
            ) : (
              history.map(({ task, member }) => {
                const garden = snap?.gardens.find((item) => item.id === task.gardenId);
                const log = snap?.logs.find((item) => item.taskId === task.id && item.userId === member.id);
                return (
                  <article key={`${task.id}-${member.id}`} className="rounded-xl border border-line bg-card px-4 py-3">
                    <p className="text-xs font-semibold text-leaf">{dayLabel(task.scheduledDate)} · {member.name}</p>
                    <h3 className="font-display text-lg">{task.title}</h3>
                    <p className="text-sm text-muted">
                      {garden?.name ?? "Sem jardim"}
                      {log?.serviceType ? ` · ${SERVICE_LABEL[log.serviceType] ?? log.serviceType}` : ""}
                      {log?.minutes ? ` · ${formatMinutes(log.minutes)}` : ""}
                    </p>
                    {log?.notes ? <p className="mt-1 text-sm">{log.notes}</p> : null}
                    {log?.materials ? <p className="text-sm text-muted">Materiais: {log.materials}</p> : null}
                  </article>
                );
              })
            )}
          </section>
        </div>
      )}
    </div>
  );
}

function Toggle({ on, label, onClick }: { on: boolean; label: string; onClick: () => void }) {
  return (
    <button
      type="button"
      aria-pressed={on}
      onClick={onClick}
      className={cx("h-11 min-w-20 rounded-lg px-3 text-sm font-semibold", on ? "bg-leaf text-card" : "bg-card text-ink ring-1 ring-line")}
    >
      {label}
    </button>
  );
}

function InviteBox({
  members,
  invites,
  onInvite,
}: {
  members: { id: string; name: string; email: string }[];
  invites: string[];
  onInvite: (email: string) => Promise<boolean>;
}) {
  const [email, setEmail] = useState("");
  const [busy, setBusy] = useState(false);
  const pending = invites.filter(
    (item) => !members.some((member) => member.email.trim().toLowerCase() === item),
  );

  return (
    <section className="rounded-xl border border-dashed border-line bg-card p-4">
      <h2 className="font-display text-2xl">Entrar mais alguém</h2>
      <p className="mt-2 text-sm text-muted">
        Escreve o email. Quando essa pessoa criar conta — com email ou Google — entra com as mesmas permissões que tu.
      </p>
      <form
        className="mt-3 flex flex-col gap-2 sm:flex-row"
        onSubmit={(event) => {
          event.preventDefault();
          setBusy(true);
          void onInvite(email.trim()).then((ok) => {
            setBusy(false);
            if (ok) {
              setEmail("");
              toast.success("Convite guardado. Já pode criar a conta com este email.");
            }
          });
        }}
      >
        <input
          className={fieldClass}
          type="email"
          required
          value={email}
          onChange={(event) => setEmail(event.target.value)}
          placeholder="nome@email.pt"
          aria-label="Email a convidar"
        />
        <Button type="submit" disabled={busy}>
          {busy ? "A guardar…" : "Convidar"}
        </Button>
      </form>
      <ul className="mt-4 space-y-1 text-sm">
        {members.map((member) => (
          <li key={member.id} className="flex justify-between gap-3">
            <span className="font-medium">{member.name}</span>
            <span className="truncate text-muted">{member.email}</span>
          </li>
        ))}
        {pending.map((item) => (
          <li key={item} className="flex justify-between gap-3 text-muted">
            <span>Convite por aceitar</span>
            <span className="truncate">{item}</span>
          </li>
        ))}
      </ul>
    </section>
  );
}
