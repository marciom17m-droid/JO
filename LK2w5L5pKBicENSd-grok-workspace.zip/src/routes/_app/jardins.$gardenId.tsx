import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ArrowLeft, Camera, MapPin, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { GardenSheet, LogSheet, TaskSheet } from "@/components/sheets";
import { TaskCard } from "@/components/task-card";
import { Button, Empty, Pill } from "@/components/ui";
import { interventionCopy, mapsUrl, STATUS_LABEL, todayIso } from "@/lib/garden/format";
import { compressImage } from "@/lib/garden/images";
import { addGardenPhoto, deleteGardenPhoto, listGardenPhotos } from "@/lib/garden/fns";
import { useWorkspace } from "@/lib/garden/store";
import type { Photo, Task } from "@/lib/garden/types";

export const Route = createFileRoute("/_app/jardins/$gardenId")({
  component: GardenDetail,
});

function GardenDetail() {
  const { gardenId } = Route.useParams();
  const { snap, loading, markDone, postpone, removeTask, removeGarden } = useWorkspace();
  const garden = snap?.gardens.find((item) => item.id === gardenId);
  const tasks = (snap?.tasks ?? []).filter((task) => task.gardenId === gardenId);
  const members = snap?.members ?? [];
  const [photos, setPhotos] = useState<Photo[]>([]);
  const [edit, setEdit] = useState(false);
  const [taskOpen, setTaskOpen] = useState(false);
  const [editing, setEditing] = useState<Task | null>(null);
  const [logging, setLogging] = useState<Task | null>(null);
  const [confirm, setConfirm] = useState(false);
  const [viewer, setViewer] = useState<string | null>(null);

  function reloadPhotos() {
    void listGardenPhotos({ data: { gardenId } })
      .then(setPhotos)
      .catch(() => setPhotos([]));
  }

  useEffect(() => {
    reloadPhotos();
    // gardenId is the only identity that should refetch
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [gardenId]);

  if (!loading && snap && !garden) {
    return (
      <Empty
        title="Jardim não encontrado"
        body="Pode ter sido eliminado por alguém da equipa."
        action={
          <Link to="/jardins" className="inline-flex h-11 items-center rounded-lg bg-leaf px-4 text-sm font-semibold text-card">
            Voltar aos jardins
          </Link>
        }
      />
    );
  }

  if (!garden) return <p className="text-sm text-muted">A abrir o jardim…</p>;

  const visit = interventionCopy(garden.lastDone);

  return (
    <div className="space-y-5">
      <Link to="/jardins" className="inline-flex h-11 items-center gap-1 text-sm font-semibold text-leaf">
        <ArrowLeft className="h-4 w-4" />
        Jardins
      </Link>
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <Pill tone={garden.status === "pausado" ? "clay" : garden.status === "concluido" ? "muted" : "leaf"}>
            {STATUS_LABEL[garden.status]}
          </Pill>
          <h1 className="mt-2 font-display text-4xl">{garden.name}</h1>
          {garden.location ? (
            <a href={mapsUrl(garden.location)} target="_blank" rel="noreferrer" className="mt-2 inline-flex items-start gap-1.5 text-sm font-semibold text-leaf">
              <MapPin className="mt-0.5 h-4 w-4" />
              Abrir no Google Maps
            </a>
          ) : (
            <p className="mt-2 text-sm text-muted">Sem localização. Edita o jardim para a acrescentar.</p>
          )}
          {garden.location ? <p className="text-sm text-muted">{garden.location}</p> : null}
          <p className={visit.stale ? "mt-2 text-sm font-semibold text-clay" : "mt-2 text-sm font-semibold text-leaf"}>
            {visit.lead}
            {visit.when ? <span className="font-medium text-muted"> · {visit.when}</span> : null}
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="secondary" onClick={() => setEdit(true)}>
            Editar
          </Button>
          <Button variant="ghost" className="text-clay" onClick={() => setConfirm(true)} aria-label="Eliminar jardim">
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {confirm ? (
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl bg-clay-soft px-4 py-3">
          <p className="text-sm text-clay">Eliminar este jardim? As tarefas ficam, mas deixam de estar ligadas a ele.</p>
          <span className="flex gap-2">
            <Button variant="ghost" onClick={() => setConfirm(false)}>
              Cancelar
            </Button>
            <Button
              variant="danger"
              onClick={() => {
                void removeGarden(garden.id).then((ok) => {
                  if (ok) window.location.href = "/jardins";
                });
              }}
            >
              Eliminar
            </Button>
          </span>
        </div>
      ) : null}

      {garden.notes ? (
        <section className="rounded-xl border border-line bg-card p-4">
          <h2 className="text-sm font-semibold text-muted">Notas</h2>
          <p className="mt-1 whitespace-pre-wrap text-sm">{garden.notes}</p>
        </section>
      ) : null}

      <section>
        <div className="mb-2 flex items-center justify-between">
          <h2 className="font-display text-2xl">Fotos</h2>
          <label className="inline-flex h-11 cursor-pointer items-center gap-2 rounded-lg bg-leaf-soft px-3 text-sm font-semibold text-leaf">
            <Camera className="h-4 w-4" />
            Adicionar
            <input
              type="file"
              accept="image/*"
              className="sr-only"
              onChange={(event) => {
                const file = event.target.files?.[0];
                event.target.value = "";
                if (!file) return;
                void compressImage(file)
                  .then((dataUrl) => addGardenPhoto({ data: { gardenId, dataUrl } }))
                  .then((result) => {
                    if (!result.ok) {
                      toast.error(result.error);
                      return;
                    }
                    toast.success("Foto adicionada");
                    reloadPhotos();
                  })
                  .catch((err: unknown) => toast.error(err instanceof Error ? err.message : "Foto inválida"));
              }}
            />
          </label>
        </div>
        {photos.length === 0 ? (
          <p className="text-sm text-muted">Ainda sem fotos. Uma imagem do portão ou do relvado chega para a equipa se orientar.</p>
        ) : (
          <ul className="flex gap-2 overflow-x-auto pb-1">
            {photos.map((photo) => (
              <li key={photo.id} className="relative shrink-0">
                <button type="button" onClick={() => setViewer(photo.dataUrl)}>
                  <img src={photo.dataUrl} alt="" className="h-32 w-40 rounded-lg object-cover" />
                </button>
                <button
                  type="button"
                  aria-label="Apagar foto"
                  className="absolute top-1 right-1 grid h-8 w-8 place-items-center rounded-full bg-card/90 text-clay"
                  onClick={() => {
                    void deleteGardenPhoto({ data: { id: photo.id } }).then((result) => {
                      if (!result.ok) toast.error(result.error);
                      else reloadPhotos();
                    });
                  }}
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </li>
            ))}
          </ul>
        )}
      </section>

      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="font-display text-2xl">Trabalho</h2>
          <Button
            onClick={() => {
              setEditing(null);
              setTaskOpen(true);
            }}
          >
            Nova tarefa
          </Button>
        </div>
        {tasks.length === 0 ? (
          <Empty title="Sem tarefas neste jardim" body="Marca a próxima visita e escolhe quem vai." />
        ) : (
          tasks
            .slice()
            .sort((a, b) => b.scheduledDate.localeCompare(a.scheduledDate))
            .map((task) => (
              <TaskCard
                key={task.id}
                task={task}
                members={members}
                showDate
                onDone={() => void markDone(task.id, task.status !== "feita")}
                onPostpone={(date) => void postpone(task.id, date)}
                onEdit={() => {
                  setEditing(task);
                  setTaskOpen(true);
                }}
                onLog={() => setLogging(task)}
                onDelete={() => void removeTask(task.id)}
              />
            ))
        )}
      </section>

      <GardenSheet open={edit} garden={garden} onClose={() => setEdit(false)} />
      <TaskSheet
        open={taskOpen}
        task={editing}
        initialGardenId={garden.id}
        initialDate={todayIso()}
        members={members}
        gardens={snap?.gardens ?? []}
        onClose={() => setTaskOpen(false)}
      />
      <LogSheet open={Boolean(logging)} task={logging} onClose={() => setLogging(null)} />
      {viewer ? (
        <button type="button" className="fixed inset-0 z-50 grid place-items-center bg-ink/80 p-4" onClick={() => setViewer(null)}>
          <img src={viewer} alt="" className="max-h-[85dvh] max-w-full rounded-lg" />
        </button>
      ) : null}
    </div>
  );
}
