import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { MapPin, Plus, Search } from "lucide-react";
import { GardenSheet } from "@/components/sheets";
import { Button, cx, Empty, Pill } from "@/components/ui";
import { interventionCopy, mapsUrl, STATUS_LABEL } from "@/lib/garden/format";
import { useWorkspace } from "@/lib/garden/store";
import type { Garden, GardenStatus } from "@/lib/garden/types";

export const Route = createFileRoute("/_app/jardins")({
  head: () => ({ meta: [{ title: "Jardins · Jardins e outros" }] }),
  component: GardensPage,
});

const FILTERS: Array<{ id: "todos" | GardenStatus; label: string }> = [
  { id: "todos", label: "Todos" },
  { id: "ativo", label: "Ativos" },
  { id: "pausado", label: "Pausados" },
  { id: "sazonal", label: "Sazonais" },
  { id: "concluido", label: "Concluídos" },
];

const SORTS = [
  { id: "antiga", label: "Mais tempo sem intervenção" },
  { id: "recente", label: "Intervenção mais recente" },
  { id: "nome-asc", label: "Nome (A–Z)" },
  { id: "nome-desc", label: "Nome (Z–A)" },
] as const;

type SortId = (typeof SORTS)[number]["id"];
const SORT_KEY = "jardins.sort";

function readSort(): SortId {
  try {
    const raw = localStorage.getItem(SORT_KEY);
    if (SORTS.some((item) => item.id === raw)) return raw as SortId;
  } catch {
    /* storage bloqueado */
  }
  return "antiga";
}

function byName(a: Garden, b: Garden) {
  return a.name.localeCompare(b.name, "pt");
}

function compareGardens(a: Garden, b: Garden, sort: SortId) {
  if (sort === "nome-asc") return byName(a, b);
  if (sort === "nome-desc") return byName(b, a);
  const ad = a.lastDone ?? "";
  const bd = b.lastDone ?? "";
  if (ad !== bd) {
    if (!ad) return sort === "antiga" ? -1 : 1;
    if (!bd) return sort === "antiga" ? 1 : -1;
    return sort === "antiga" ? ad.localeCompare(bd) : bd.localeCompare(ad);
  }
  return byName(a, b);
}

function tone(status: GardenStatus): "leaf" | "clay" | "muted" {
  if (status === "ativo" || status === "sazonal") return "leaf";
  if (status === "pausado") return "clay";
  return "muted";
}

function GardensPage() {
  const { snap, loading } = useWorkspace();
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<(typeof FILTERS)[number]["id"]>("todos");
  const [sort, setSort] = useState<SortId>(readSort);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Garden | null>(null);
  const gardens = snap?.gardens ?? [];

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    return gardens
      .filter((garden) => {
        if (filter !== "todos" && garden.status !== filter) return false;
        if (!q) return true;
        return `${garden.name} ${garden.location}`.toLowerCase().includes(q);
      })
      .sort((a, b) => compareGardens(a, b, sort));
  }, [gardens, query, filter, sort]);

  const untouched = gardens.filter((garden) => !garden.lastDone).length;

  return (
    <div className="space-y-5">
      <div className="flex items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-4xl">Jardins</h1>
          <p className="text-sm text-muted">
            {gardens.length === 1 ? "1 jardim" : `${gardens.length} jardins`}
            {untouched ? ` · ${untouched} sem intervenção` : ""}
          </p>
        </div>
        <Button
          onClick={() => {
            setEditing(null);
            setOpen(true);
          }}
        >
          <Plus className="h-4 w-4" />
          Jardim
        </Button>
      </div>

      <div className="grid gap-2 sm:grid-cols-[minmax(0,1fr)_16rem]">
        <div className="relative">
          <Search className="pointer-events-none absolute top-3 left-3 h-5 w-5 text-muted" />
          <input
            className="h-11 w-full rounded-lg border border-line bg-card pr-3 pl-10 text-ink outline-none"
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Procurar por nome ou sítio"
            aria-label="Procurar jardins"
          />
        </div>
        <label className="block">
          <span className="sr-only">Ordenar</span>
          <select
            className="h-11 w-full rounded-lg border border-line bg-card px-3 text-sm font-semibold text-ink"
            value={sort}
            onChange={(event) => {
              const next = event.target.value as SortId;
              setSort(next);
              try {
                localStorage.setItem(SORT_KEY, next);
              } catch {
                /* ignora */
              }
            }}
            aria-label="Ordenar jardins"
          >
            {SORTS.map((item) => (
              <option key={item.id} value={item.id}>
                {item.label}
              </option>
            ))}
          </select>
        </label>
      </div>

      <div className="flex gap-2 overflow-x-auto pb-1">
        {FILTERS.map((item) => (
          <button
            key={item.id}
            type="button"
            onClick={() => setFilter(item.id)}
            className={cx(
              "h-10 shrink-0 rounded-full px-3 text-sm font-semibold",
              filter === item.id ? "bg-leaf text-card" : "bg-card text-muted ring-1 ring-line",
            )}
          >
            {item.label}
          </button>
        ))}
      </div>

      {loading && !snap ? <p className="text-sm text-muted">A carregar jardins…</p> : null}

      {!loading && gardens.length === 0 ? (
        <Empty
          title="Ainda não há jardins"
          body="Começa pelo nome e pela morada. O link para o Google Maps fica automático."
          action={
            <Button
              onClick={() => {
                setEditing(null);
                setOpen(true);
              }}
            >
              Criar jardim
            </Button>
          }
        />
      ) : null}

      {!loading && gardens.length > 0 && visible.length === 0 ? (
        <Empty title="Nada com esse filtro" body="Experimenta outro estado ou limpa a pesquisa." />
      ) : null}

      <ul className="grid gap-3 md:grid-cols-2">
        {visible.map((garden) => {
          const visit = interventionCopy(garden.lastDone);
          return (
            <li
              key={garden.id}
              className={cx(
                "rounded-xl border border-line bg-card p-4",
                visit.stale && "border-l-4 border-l-clay",
              )}
            >
              <div className="flex items-start justify-between gap-3">
                <Link to="/jardins/$gardenId" params={{ gardenId: garden.id }} className="min-w-0">
                  <h2 className="font-display text-2xl">{garden.name}</h2>
                </Link>
                <Pill tone={tone(garden.status)}>{STATUS_LABEL[garden.status]}</Pill>
              </div>
              {garden.location ? (
                <a
                  href={mapsUrl(garden.location)}
                  target="_blank"
                  rel="noreferrer"
                  className="mt-2 inline-flex items-start gap-1.5 text-sm font-medium text-leaf"
                >
                  <MapPin className="mt-0.5 h-4 w-4 shrink-0" />
                  {garden.location}
                </a>
              ) : (
                <p className="mt-2 text-sm text-muted">Sem localização</p>
              )}
              <p className={cx("mt-3 text-sm font-semibold", visit.stale ? "text-clay" : "text-leaf")}>
                {visit.lead}
                {visit.when ? <span className="font-medium text-muted"> · {visit.when}</span> : null}
              </p>
              <div className="mt-3 flex gap-2">
                <Link
                  to="/jardins/$gardenId"
                  params={{ gardenId: garden.id }}
                  className="inline-flex h-11 items-center rounded-lg bg-leaf-soft px-4 text-sm font-semibold text-leaf"
                >
                  Abrir
                </Link>
                <Button
                  variant="ghost"
                  onClick={() => {
                    setEditing(garden);
                    setOpen(true);
                  }}
                >
                  Editar
                </Button>
              </div>
            </li>
          );
        })}
      </ul>

      <GardenSheet open={open} garden={editing} onClose={() => setOpen(false)} />
    </div>
  );
}
