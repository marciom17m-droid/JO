import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Bell, Plus } from "lucide-react";
import { toast } from "sonner";
import { GardenSheet, LogSheet, TaskSheet } from "@/components/sheets";
import { TaskCard } from "@/components/task-card";
import { Button, Empty } from "@/components/ui";
import { useCurrentUser } from "@/lib/auth/use-current-user";
import { addDay, greeting, todayIso } from "@/lib/garden/format";
import { useWorkspace } from "@/lib/garden/store";
import type { Task } from "@/lib/garden/types";

export const Route = createFileRoute("/_app/")({
  component: TodayPage,
});

const NOTIFY_KEY = "jardins.notify";
const NOTIFIED_KEY = "jardins.notified";

function periodLabel(morning: boolean, afternoon: boolean) {
  if (morning && afternoon) return "dia inteiro";
  if (morning) return "manhã";
  if (afternoon) return "tarde";
  return "";
}

function TodayPage() {
  const user = useCurrentUser();
  const { snap, loading, markDone, postpone, removeTask } = useWorkspace();
  const [taskOpen, setTaskOpen] = useState(false);
  const [editing, setEditing] = useState<Task | null>(null);
  const [logging, setLogging] = useState<Task | null>(null);
  const [gardenOpen, setGardenOpen] = useState(false);
  const [notifyOn, setNotifyOn] = useState(false);

  const today = todayIso();
  const tomorrow = addDay(today, 1);
  const tasks = snap?.tasks.filter((task) => task.scheduledDate === today) ?? [];
  const next = snap?.tasks.filter((task) => task.scheduledDate === tomorrow && task.status !== "feita") ?? [];
  const openTasks = tasks.filter((task) => task.status !== "feita");
  const available =
    snap?.availability.filter((slot) => slot.day === today && (slot.morning || slot.afternoon)) ?? [];

  useEffect(() => {
    setNotifyOn(localStorage.getItem(NOTIFY_KEY) === "1" && Notification.permission === "granted");
  }, []);

  useEffect(() => {
    if (!snap || localStorage.getItem(NOTIFY_KEY) !== "1") return;
    if (typeof Notification === "undefined" || Notification.permission !== "granted") return;
    if (localStorage.getItem(NOTIFIED_KEY) === today) return;
    if (!openTasks.length) return;
    localStorage.setItem(NOTIFIED_KEY, today);
    const body =
      openTasks.length === 1
        ? openTasks[0].title
        : `${openTasks.length} tarefas por fazer hoje`;
    try {
      new Notification("Jardins e outros", { body });
    } catch {
      /* notificações indisponíveis */
    }
  }, [snap, today, openTasks.length, openTasks[0]?.title]);

  const gardens = snap?.gardens ?? [];
  const members = snap?.members ?? [];
  const gardenName = (id: string | null) => gardens.find((garden) => garden.id === id)?.name;

  return (
    <div className="space-y-6">
      <div className="flex items-end justify-between gap-3">
        <div>
          <p className="text-sm font-medium text-muted">{new Intl.DateTimeFormat("pt-PT", { weekday: "long", day: "numeric", month: "long" }).format(new Date())}</p>
          <h1 className="font-display text-4xl text-ink">{greeting(user?.displayName)}</h1>
        </div>
        <Button onClick={() => { setEditing(null); setTaskOpen(true); }}>
          <Plus className="h-4 w-4" />
          Tarefa
        </Button>
      </div>

      {!gardens.length && !loading ? (
        <section className="rounded-xl bg-leaf px-5 py-5 text-card">
          <h2 className="font-display text-2xl">Primeiros passos</h2>
          <ol className="mt-3 space-y-2 text-sm text-leaf-soft">
            <li>1. Cria os jardins onde a equipa trabalha.</li>
            <li>2. Marca as tarefas do dia — podes criar várias de seguida.</li>
            <li>3. Indica em Equipa quando estás livre, de manhã ou de tarde.</li>
          </ol>
          <Button variant="secondary" className="mt-4" onClick={() => setGardenOpen(true)}>
            Criar o primeiro jardim
          </Button>
        </section>
      ) : null}

      <section className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_18rem]">
        <div className="space-y-3">
          <h2 className="font-display text-2xl">Hoje</h2>
          {loading && !snap ? (
            <p className="text-sm text-muted">A carregar o dia…</p>
          ) : tasks.length === 0 ? (
            <Empty
              title="Dia limpo"
              body="Não há tarefas marcadas para hoje. Se o trabalho é amanhã, marca já — podes pôr vários jardins no mesmo dia."
              action={
                <Button onClick={() => { setEditing(null); setTaskOpen(true); }}>
                  Marcar tarefa
                </Button>
              }
            />
          ) : (
            tasks.map((task) => (
              <TaskCard
                key={task.id}
                task={task}
                gardenName={gardenName(task.gardenId)}
                members={members}
                onDone={() => {
                  const nextDone = task.status !== "feita";
                  void markDone(task.id, nextDone).then((ok) => {
                    if (ok && nextDone) {
                      toast.success("Marcada como feita", {
                        action: { label: "Registar", onClick: () => setLogging(task) },
                      });
                    }
                  });
                }}
                onPostpone={(date) => {
                  void postpone(task.id, date).then((ok) => {
                    if (ok) toast.success("Tarefa adiada");
                  });
                }}
                onEdit={() => { setEditing(task); setTaskOpen(true); }}
                onLog={() => setLogging(task)}
                onDelete={() => {
                  void removeTask(task.id).then((ok) => {
                    if (ok) toast.success("Tarefa eliminada");
                  });
                }}
              />
            ))
          )}
          {next.length ? (
            <div className="pt-2">
              <h2 className="font-display text-2xl">Amanhã</h2>
              <ul className="mt-2 space-y-2">
                {next.map((task) => (
                  <li key={task.id} className="flex items-center justify-between gap-3 rounded-lg border border-line bg-card px-3 py-3">
                    <span>
                      <span className="block text-sm font-semibold">{task.title}</span>
                      <span className="text-xs text-muted">{gardenName(task.gardenId) ?? "Sem jardim"}</span>
                    </span>
                    <Link to="/agenda" className="text-sm font-semibold text-leaf">
                      Ver
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ) : null}
        </div>
        <aside className="space-y-3">
          <h2 className="font-display text-2xl">Quem está</h2>
          <div className="rounded-xl border border-line bg-card p-4">
            {available.length === 0 ? (
              <p className="text-sm text-muted">Ninguém marcou disponibilidade para hoje.</p>
            ) : (
              <ul className="space-y-2">
                {available.map((slot) => {
                  const person = members.find((member) => member.id === slot.userId);
                  return (
                    <li key={slot.userId} className="flex items-center justify-between gap-3 text-sm">
                      <span className="font-medium">{person?.name ?? "Colega"}</span>
                      <span className="text-muted">{periodLabel(slot.morning, slot.afternoon)}</span>
                    </li>
                  );
                })}
              </ul>
            )}
            <Link to="/equipa" className="mt-3 inline-flex h-11 items-center text-sm font-semibold text-leaf">
              Ver a semana da equipa
            </Link>
          </div>
          <button
            type="button"
            className="flex w-full items-start gap-3 rounded-xl border border-line bg-card p-4 text-left"
            onClick={() => {
              if (typeof Notification === "undefined") {
                toast.error("Este browser não mostra avisos.");
                return;
              }
              void Notification.requestPermission().then((permission) => {
                if (permission !== "granted") {
                  toast.error("Avisos bloqueados nas definições do telemóvel.");
                  return;
                }
                localStorage.setItem(NOTIFY_KEY, "1");
                setNotifyOn(true);
                toast.success("Vais receber um aviso ao abrir a app, se houver trabalho hoje.");
              });
            }}
          >
            <Bell className="mt-0.5 h-5 w-5 text-leaf" />
            <span>
              <span className="block text-sm font-semibold">{notifyOn ? "Avisos do dia ativos" : "Ativar aviso do dia"}</span>
              <span className="text-sm text-muted">Quando abres a app e ainda há tarefas por fazer.</span>
            </span>
          </button>
        </aside>
      </section>

      <TaskSheet
        open={taskOpen}
        task={editing}
        initialDate={today}
        members={members}
        gardens={gardens}
        onClose={() => setTaskOpen(false)}
      />
      <LogSheet open={Boolean(logging)} task={logging} onClose={() => setLogging(null)} />
      <GardenSheet open={gardenOpen} onClose={() => setGardenOpen(false)} />
    </div>
  );
}
