import { createFileRoute, Navigate } from "@tanstack/react-router";
import { useState } from "react";
import { Leaf } from "lucide-react";
import { authClient, GROK_PROVIDERS, signIn } from "@/lib/auth/client";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { Button, cx, fieldClass } from "@/components/ui";

export const Route = createFileRoute("/login")({
  head: () => ({ meta: [{ title: "Entrar · Jardins e outros" }] }),
  component: LoginPage,
});

const BEARER_KEY = "grok-auth.bearer-token";

function authMessage(raw?: string | null): string {
  const message = (raw ?? "").toLowerCase();
  if (message.includes("invalid") || message.includes("password") || message.includes("credential")) {
    return "Email ou palavra-passe incorretos.";
  }
  if (message.includes("exist") || message.includes("already")) {
    return "Já existe uma conta com este email.";
  }
  if (message.includes("short")) return "A palavra-passe tem de ter pelo menos 8 caracteres.";
  if (message.includes("origin")) return "Não foi possível iniciar sessão neste endereço.";
  if (message.includes("pop")) return "O navegador bloqueou a janela. Permite pop-ups e tenta outra vez.";
  return "Não foi possível entrar. Tenta outra vez.";
}

async function adopt(token?: string | null) {
  if (token) {
    try {
      sessionStorage.setItem(BEARER_KEY, token);
    } catch {
      /* storage blocked */
    }
  }
  await authClient.getSession();
  window.location.href = "/";
}

function LoginPage() {
  const { user, isPending } = useCurrentUserState();
  const [mode, setMode] = useState<"entrar" | "criar">("entrar");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  if (!isPending && user) return <Navigate to="/" />;

  return (
    <main className="min-h-dvh md:grid md:grid-cols-2">
      <section className="bg-leaf px-6 py-10 text-card md:flex md:flex-col md:justify-between md:px-12 md:py-14">
        <div>
          <span className="grid h-12 w-12 place-items-center rounded-xl bg-card text-leaf">
            <Leaf className="h-6 w-6" />
          </span>
          <h1 className="mt-6 font-display text-4xl leading-tight md:text-5xl">Jardins e outros</h1>
          <p className="mt-3 max-w-sm text-base text-leaf-soft">
            O caderno de campo da equipa. Jardins, dias de trabalho e quem está disponível — tudo no mesmo sítio.
          </p>
        </div>
        <ul className="mt-8 hidden space-y-3 text-sm md:block">
          <li>Marca vários jardins para o mesmo dia.</li>
          <li>Atribui o trabalho a uma ou mais pessoas.</li>
          <li>Vê a manhã e a tarde de toda a equipa.</li>
        </ul>
      </section>
      <section className="flex items-center px-5 py-8 md:px-12">
        <div className="mx-auto w-full max-w-sm">
          <div className="grid grid-cols-2 rounded-lg bg-card p-1 ring-1 ring-line">
            {(["entrar", "criar"] as const).map((item) => (
              <button
                key={item}
                type="button"
                onClick={() => {
                  setMode(item);
                  setError(null);
                }}
                className={cx(
                  "h-11 rounded-md text-sm font-semibold",
                  mode === item ? "bg-leaf text-card" : "text-muted",
                )}
              >
                {item === "entrar" ? "Entrar" : "Criar conta"}
              </button>
            ))}
          </div>
          <form
            className="mt-6 space-y-3"
            onSubmit={(event) => {
              event.preventDefault();
              setBusy(true);
              setError(null);
              const run =
                mode === "criar"
                  ? authClient.signUp.email({ email, password, name: name.trim(), callbackURL: "/" })
                  : authClient.signIn.email({ email, password });
              void run
                .then(async (result) => {
                  if (result.error) {
                    setError(authMessage(result.error.message));
                    setBusy(false);
                    return;
                  }
                  await adopt(result.data?.token);
                })
                .catch((err: unknown) => {
                  setError(authMessage(err instanceof Error ? err.message : null));
                  setBusy(false);
                });
            }}
          >
            {mode === "criar" ? (
              <label className="block space-y-1.5 text-sm font-medium">
                Nome
                <input className={fieldClass} value={name} onChange={(e) => setName(e.target.value)} required autoComplete="name" placeholder="O teu nome" />
              </label>
            ) : null}
            <label className="block space-y-1.5 text-sm font-medium">
              Email
              <input className={fieldClass} type="email" value={email} onChange={(e) => setEmail(e.target.value)} required autoComplete="email" placeholder="nome@email.pt" />
            </label>
            <label className="block space-y-1.5 text-sm font-medium">
              Palavra-passe
              <input className={fieldClass} type="password" value={password} onChange={(e) => setPassword(e.target.value)} required minLength={8} autoComplete={mode === "criar" ? "new-password" : "current-password"} placeholder="Pelo menos 8 caracteres" />
            </label>
            {error ? <p className="text-sm text-clay">{error}</p> : null}
            <Button type="submit" className="w-full" disabled={busy}>
              {busy ? "A aguardar…" : mode === "criar" ? "Criar conta" : "Entrar"}
            </Button>
          </form>
          <div className="my-5 flex items-center gap-3 text-xs text-muted">
            <span className="h-px flex-1 bg-line" />
            ou
            <span className="h-px flex-1 bg-line" />
          </div>
          <div className="space-y-2">
            {GROK_PROVIDERS.map((provider) => (
              <Button
                key={provider.providerId}
                variant="secondary"
                className="w-full"
                onClick={() => {
                  setError(null);
                  void signIn(provider.providerId, { callbackURL: "/" }).catch((err: unknown) => {
                    setError(authMessage(err instanceof Error ? err.message : null));
                  });
                }}
              >
                Continuar com {provider.label}
              </Button>
            ))}
          </div>
          <p className="mt-6 text-sm text-muted">
            A primeira conta abre a equipa. As seguintes entram quando um colega as convida pelo email — todas com as mesmas permissões.
          </p>
        </div>
      </section>
    </main>
  );
}
