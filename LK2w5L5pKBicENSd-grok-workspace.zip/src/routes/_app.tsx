import { createFileRoute, Outlet } from "@tanstack/react-router";
import { useEffect, useState, type ReactNode } from "react";
import { Leaf } from "lucide-react";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { authEnabled, signOut } from "@/lib/auth/client";
import { useCurrentUser, useCurrentUserState } from "@/lib/auth/use-current-user";
import { Boot, Button } from "@/components/ui";
import { Shell } from "@/components/shell";
import { WorkspaceProvider, useWorkspace } from "@/lib/garden/store";

export const Route = createFileRoute("/_app")({
  component: AppLayout,
});

function AppLayout() {
  const { user, isPending } = useCurrentUserState();
  const [ready, setReady] = useState(false);
  useEffect(() => setReady(true), []);

  if (!ready || isPending) return <Boot />;
  if (!user) return <RedirectToSignIn />;

  return (
    <WorkspaceProvider userId={user.id}>
      <TeamGate>
        <Shell>
          <Outlet />
        </Shell>
      </TeamGate>
    </WorkspaceProvider>
  );
}

function TeamGate({ children }: { children: ReactNode }) {
  const { snap, loading } = useWorkspace();
  if (loading && !snap) return <Boot />;
  if (snap?.blocked) return <WaitingRoom />;
  return children;
}

function WaitingRoom() {
  const user = useCurrentUser();
  const [busy, setBusy] = useState(false);
  const email = user?.primaryEmail ?? "o teu email";
  return (
    <main className="grid min-h-dvh place-items-center bg-paper px-6 py-12">
      <div className="w-full max-w-md rounded-xl border border-line bg-card p-6">
        <span className="grid h-12 w-12 place-items-center rounded-xl bg-leaf text-card">
          <Leaf className="h-6 w-6" />
        </span>
        <h1 className="mt-4 font-display text-3xl">Ainda não estás na equipa</h1>
        <p className="mt-2 text-sm text-muted">
          Pede a um colega para te convidar com <span className="font-semibold text-ink">{email}</span>.
          Quando o convite estiver feito, entra outra vez — ficas com as mesmas permissões que os outros.
        </p>
        {authEnabled ? (
          <Button
            className="mt-5"
            variant="secondary"
            disabled={busy}
            onClick={() => {
              setBusy(true);
              void signOut("/login").catch(() => setBusy(false));
            }}
          >
            {busy ? "A sair…" : "Sair"}
          </Button>
        ) : null}
      </div>
    </main>
  );
}
