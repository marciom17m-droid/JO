import type { ButtonHTMLAttributes, ReactNode, TextareaHTMLAttributes } from "react";
import { Leaf } from "lucide-react";
import type { Member } from "@/lib/garden/types";
import { initials } from "@/lib/garden/format";

export function cx(...parts: Array<string | false | null | undefined>) {
  return parts.filter(Boolean).join(" ");
}

export function Boot() {
  return (
    <main className="grid min-h-dvh place-items-center bg-leaf px-6 text-card">
      <div className="flex flex-col items-center gap-3 text-center">
        <span className="grid h-14 w-14 place-items-center rounded-xl bg-card text-leaf">
          <Leaf className="h-7 w-7" />
        </span>
        <h1 className="font-display text-3xl">Jardins e outros</h1>
        <p className="text-sm text-leaf-soft">A abrir o caderno da equipa…</p>
      </div>
    </main>
  );
}

type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "secondary" | "ghost" | "danger" | "soft";
};

export function Button({ variant = "primary", className, type = "button", ...props }: ButtonProps) {
  return (
    <button
      type={type}
      className={cx(
        "inline-flex h-11 items-center justify-center gap-2 rounded-lg px-4 text-sm font-semibold transition-colors disabled:cursor-not-allowed disabled:opacity-50",
        variant === "primary" && "bg-leaf text-card hover:bg-leaf-bright",
        variant === "secondary" && "border border-line bg-card text-ink hover:bg-paper",
        variant === "ghost" && "text-ink hover:bg-leaf-soft",
        variant === "danger" && "bg-clay text-card hover:bg-clay/90",
        variant === "soft" && "bg-leaf-soft text-leaf hover:bg-leaf-soft/70",
        className,
      )}
      {...props}
    />
  );
}

export function Field({
  label,
  children,
}: {
  label: string;
  children: ReactNode;
}) {
  return (
    <label className="block space-y-1.5">
      <span className="text-sm font-medium text-ink">{label}</span>
      {children}
    </label>
  );
}

export const fieldClass =
  "h-11 w-full rounded-lg border border-line bg-card px-3 text-ink outline-none placeholder:text-muted/70";

export function TextArea({ className, ...props }: TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return (
    <textarea
      className={cx(fieldClass, "h-24 py-2", className)}
      {...props}
    />
  );
}

export function Sheet({
  open,
  title,
  onClose,
  children,
}: {
  open: boolean;
  title: string;
  onClose: () => void;
  children: ReactNode;
}) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-40">
      <button
        type="button"
        aria-label="Fechar"
        className="absolute inset-0 bg-ink/40"
        onClick={onClose}
      />
      <div
        role="dialog"
        aria-modal="true"
        aria-label={title}
        className="absolute inset-x-0 bottom-0 max-h-[92dvh] overflow-y-auto rounded-t-xl bg-paper px-4 pt-4 pb-6 shadow-xl md:inset-auto md:top-1/2 md:left-1/2 md:w-full md:max-w-lg md:-translate-x-1/2 md:-translate-y-1/2 md:rounded-xl"
      >
        <div className="mb-4 flex items-center justify-between gap-3">
          <h2 className="font-display text-2xl text-ink">{title}</h2>
          <button
            type="button"
            onClick={onClose}
            className="grid h-11 w-11 place-items-center rounded-lg text-muted hover:bg-card"
            aria-label="Fechar"
          >
            ×
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

export function Pill({
  children,
  tone = "leaf",
}: {
  children: ReactNode;
  tone?: "leaf" | "clay" | "muted";
}) {
  return (
    <span
      className={cx(
        "inline-flex items-center rounded-full px-2.5 py-1 text-xs font-semibold",
        tone === "leaf" && "bg-leaf-soft text-leaf",
        tone === "clay" && "bg-clay-soft text-clay",
        tone === "muted" && "bg-paper text-muted ring-1 ring-line",
      )}
    >
      {children}
    </span>
  );
}

export function Avatars({ members, ids }: { members: Member[]; ids: string[] }) {
  const people = ids
    .map((id) => members.find((member) => member.id === id))
    .filter((member): member is Member => Boolean(member));
  if (!people.length) return <span className="text-xs text-muted">Sem pessoas</span>;
  return (
    <span className="flex items-center gap-1">
      {people.map((person) => (
        <span
          key={person.id}
          title={person.name}
          className="grid h-7 w-7 place-items-center rounded-full bg-leaf-soft text-xs font-semibold text-leaf"
        >
          {initials(person.name)}
        </span>
      ))}
    </span>
  );
}

export function Empty({
  title,
  body,
  action,
}: {
  title: string;
  body: string;
  action?: ReactNode;
}) {
  return (
    <div className="rounded-xl border border-dashed border-line bg-card px-5 py-8 text-center">
      <h3 className="font-display text-xl text-ink">{title}</h3>
      <p className="mx-auto mt-2 max-w-sm text-sm text-muted">{body}</p>
      {action ? <div className="mt-4 flex justify-center">{action}</div> : null}
    </div>
  );
}
