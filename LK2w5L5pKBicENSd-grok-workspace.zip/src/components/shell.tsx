import { Link, useRouterState } from "@tanstack/react-router";
import { CalendarDays, ListChecks, LogOut, TreePine, Users } from "lucide-react";
import type { ReactNode } from "react";
import { useState, useSyncExternalStore } from "react";
import { authEnabled, signOut } from "@/lib/auth/client";
import { hasGateSessionMarker } from "@/lib/auth/gate-session-marker";
import { useCurrentUser } from "@/lib/auth/use-current-user";
import { initials } from "@/lib/garden/format";
import { useWorkspace } from "@/lib/garden/store";
import { cx } from "./ui";

const NAV = [
  { to: "/", label: "Hoje", icon: ListChecks, exact: true },
  { to: "/agenda", label: "Agenda", icon: CalendarDays, exact: false },
  { to: "/jardins", label: "Jardins", icon: TreePine, exact: false },
  { to: "/equipa", label: "Equipa", icon: Users, exact: false },
] as const;

const subscribe = () => () => {};

function Identity() {
  const user = useCurrentUser();
  const [busy, setBusy] = useState(false);
  const gate = useSyncExternalStore(subscribe, hasGateSessionMarker, () => false);
  if (!user) return null;
  const label = user.displayName ?? user.primaryEmail ?? "Conta";
  return (
    <div className="flex items-center gap-2">
      {user.profileImageUrl ? (
        <img src={user.profileImageUrl} alt="" className="h-9 w-9 rounded-full object-cover" />
      ) : (
        <span className="grid h-9 w-9 place-items-center rounded-full bg-leaf-soft text-xs font-semibold text-leaf">
          {initials(label)}
        </span>
      )}
      <span className="hidden max-w-32 truncate text-sm font-medium md:inline">{label}</span>
      {authEnabled && !gate ? (
        <button
          type="button"
          disabled={busy}
          onClick={() => {
            setBusy(true);
            void signOut("/login").catch(() => setBusy(false));
          }}
          className="grid h-11 w-11 place-items-center rounded-lg text-muted hover:bg-paper hover:text-ink disabled:opacity-50"
          aria-label={busy ? "A sair" : "Sair"}
        >
          <LogOut className="h-4 w-4" />
        </button>
      ) : null}
    </div>
  );
}

function NavLink({
  to,
  label,
  icon: Icon,
  exact,
  stacked,
}: {
  to: string;
  label: string;
  icon: typeof ListChecks;
  exact: boolean;
  stacked?: boolean;
}) {
  const pathname = useRouterState({ select: (state) => state.location.pathname });
  const active = exact ? pathname === to : pathname === to || pathname.startsWith(`${to}/`);
  return (
    <Link
      to={to}
      className={cx(
        "flex items-center gap-2 rounded-lg text-sm font-semibold transition-colors",
        stacked ? "h-14 flex-1 flex-col justify-center gap-0.5 text-xs" : "h-11 px-3",
        active ? "bg-leaf-soft text-leaf" : "text-muted hover:bg-paper hover:text-ink",
      )}
    >
      <Icon className="h-5 w-5" />
      {label}
    </Link>
  );
}

export function Shell({ children }: { children: ReactNode }) {
  const { offline, stale, error } = useWorkspace();
  return (
    <div className="min-h-dvh md:grid md:grid-cols-[15rem_minmax(0,1fr)]">
      <aside className="hidden border-r border-line bg-card md:sticky md:top-0 md:flex md:h-dvh md:flex-col md:px-4 md:py-6">
        <div className="px-3">
          <p className="font-display text-2xl leading-none text-leaf">Jardins</p>
          <p className="mt-1 text-sm text-muted">e outros</p>
        </div>
        <nav className="mt-8 flex flex-col gap-1">
          {NAV.map((item) => (
            <NavLink key={item.to} {...item} />
          ))}
        </nav>
        <div className="mt-auto px-1">
          <Identity />
        </div>
      </aside>
      <div className="min-w-0">
        <header className="sticky top-0 z-20 flex items-center justify-between bg-paper/95 px-4 py-3 backdrop-blur md:hidden">
          <p className="font-display text-xl text-leaf">Jardins e outros</p>
          <Identity />
        </header>
        {error ? (
          <p className="bg-clay-soft px-4 py-2 text-center text-sm text-clay">{error}</p>
        ) : offline || stale ? (
          <p className="bg-clay-soft px-4 py-2 text-center text-sm text-clay">
            {offline
              ? "Sem ligação — a mostrar a última versão guardada neste telemóvel."
              : "A mostrar dados guardados. A ligação à equipa falhou."}
          </p>
        ) : null}
        <main className="mx-auto w-full max-w-5xl px-4 pt-2 app-pad md:px-8 md:pt-8 md:pb-12">
          {children}
        </main>
        <nav className="nav-safe fixed inset-x-0 bottom-0 z-30 flex border-t border-line bg-card md:hidden">
          {NAV.map((item) => (
            <NavLink key={item.to} {...item} stacked />
          ))}
        </nav>
      </div>
    </div>
  );
}
