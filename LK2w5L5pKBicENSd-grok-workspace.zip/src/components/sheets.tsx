import { useEffect, useState } from "react";
import { useCurrentUser } from "@/lib/auth/use-current-user";
import { toast } from "sonner";
import { SERVICE_LABEL } from "@/lib/garden/format";
import { compressImage } from "@/lib/garden/images";
import { useWorkspace } from "@/lib/garden/store";
import type { Garden, Member, Task } from "@/lib/garden/types";
import { GARDEN_STATUSES, SERVICE_TYPES } from "@/lib/garden/types";
import { STATUS_LABEL } from "@/lib/garden/format";
import { Button, Field, Sheet, TextArea, cx, fieldClass } from "./ui";

export function GardenSheet({
  open,
  garden,
  onClose,
}: {
  open: boolean;
  garden?: Garden | null;
  onClose: () => void;
}) {
  const { saveGarden } = useWorkspace();
  const [name, setName] = useState("");
  const [location, setLocation] = useState("");
  const [notes, setNotes] = useState("");
  const [status, setStatus] = useState("ativo");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!open) return;
    setName(garden?.name ?? "");
    setLocation(garden?.location ?? "");
    setNotes(garden?.notes ?? "");
    setStatus(garden?.status ?? "ativo");
  }, [open, garden]);

  return (
    <Sheet open={open} title={garden ? "Editar jardim" : "Novo jardim"} onClose={onClose}>
      <form
        className="space-y-4"
        onSubmit={(event) => {
          event.preventDefault();
          setBusy(true);
          void saveGarden({
            id: garden?.id,
            name,
            location,
            notes,
            status,
          }).then((ok) => {
            setBusy(false);
            if (ok) {
              toast.success(garden ? "Jardim atualizado" : "Jardim criado");
              onClose();
            }
          });
        }}
      >
        <Field label="Nome">
          <input className={fieldClass} value={name} onChange={(e) => setName(e.target.value)} required maxLength={120} placeholder="Quinta da Ribeira" />
        </Field>
        <Field label="Localização">
          <input className={fieldClass} value={location} onChange={(e) => setLocation(e.target.value)} maxLength={240} placeholder="Rua, freguesia ou coordenadas" />
        </Field>
        <Field label="Estado">
          <select className={fieldClass} value={status} onChange={(e) => setStatus(e.target.value)}>
            {GARDEN_STATUSES.map((item) => (
              <option key={item} value={item}>
                {STATUS_LABEL[item]}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Notas">
          <TextArea value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Portão lateral, cão no jardim, rega automática…" />
        </Field>
        <div className="flex gap-2">
          <Button variant="secondary" className="flex-1" onClick={onClose}>
            Cancelar
          </Button>
          <Button type="submit" className="flex-1" disabled={busy}>
            {busy ? "A guardar…" : "Guardar"}
          </Button>
        </div>
      </form>
    </Sheet>
  );
}

export function TaskSheet({
  open,
  task,
  initialDate,
  initialGardenId,
  members,
  gardens,
  onClose,
}: {
  open: boolean;
  task?: Task | null;
  initialDate?: string;
  initialGardenId?: string | null;
  members: Member[];
  gardens: Garden[];
  onClose: () => void;
}) {
  const { saveTask } = useWorkspace();
  const user = useCurrentUser();
  const [title, setTitle] = useState("");
  const [gardenId, setGardenId] = useState("");
  const [date, setDate] = useState("");
  const [notes, setNotes] = useState("");
  const [assignees, setAssignees] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!open) return;
    setTitle(task?.title ?? "");
    setGardenId(task?.gardenId ?? initialGardenId ?? "");
    setDate(task?.scheduledDate ?? initialDate ?? "");
    setNotes(task?.notes ?? "");
    setAssignees(task?.assigneeIds?.length ? task.assigneeIds : user?.id ? [user.id] : []);
  }, [open, task, initialDate, initialGardenId, user?.id]);

  function toggle(id: string) {
    setAssignees((current) =>
      current.includes(id) ? current.filter((item) => item !== id) : [...current, id],
    );
  }

  function submit(andAnother: boolean) {
    setBusy(true);
    void saveTask({
      id: task?.id,
      title,
      gardenId: gardenId || null,
      scheduledDate: date,
      notes,
      assigneeIds: assignees,
    }).then((ok) => {
      setBusy(false);
      if (!ok) return;
      toast.success(task ? "Tarefa atualizada" : "Tarefa marcada");
      if (andAnother && !task) {
        setTitle("");
        setNotes("");
        return;
      }
      onClose();
    });
  }

  return (
    <Sheet open={open} title={task ? "Editar tarefa" : "Nova tarefa"} onClose={onClose}>
      <form
        className="space-y-4"
        onSubmit={(event) => {
          event.preventDefault();
          submit(false);
        }}
      >
        <Field label="O que há a fazer">
          <input className={fieldClass} value={title} onChange={(e) => setTitle(e.target.value)} required maxLength={160} placeholder="Corte, bordaduras e sopro" />
        </Field>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Dia">
            <input className={fieldClass} type="date" value={date} onChange={(e) => setDate(e.target.value)} required />
          </Field>
          <Field label="Jardim">
            <select className={fieldClass} value={gardenId} onChange={(e) => setGardenId(e.target.value)}>
              <option value="">Sem jardim associado</option>
              {gardens.map((garden) => (
                <option key={garden.id} value={garden.id}>
                  {garden.name}
                </option>
              ))}
            </select>
          </Field>
        </div>
        <fieldset>
          <legend className="mb-1.5 text-sm font-medium">Quem vai</legend>
          {members.length === 0 ? (
            <p className="text-sm text-muted">Ainda só estás tu. A tarefa fica contigo.</p>
          ) : (
            <div className="flex flex-wrap gap-2">
              {members.map((member) => {
                const on = assignees.includes(member.id);
                return (
                  <button
                    key={member.id}
                    type="button"
                    aria-pressed={on}
                    onClick={() => toggle(member.id)}
                    className={cx(
                      "h-11 rounded-full px-3 text-sm font-semibold",
                      on ? "bg-leaf text-card" : "border border-line bg-card text-ink",
                    )}
                  >
                    {member.name}
                  </button>
                );
              })}
            </div>
          )}
          <p className="mt-2 text-xs text-muted">Podes atribuir a uma ou várias pessoas. Se não escolheres ninguém, fica contigo.</p>
        </fieldset>
        <Field label="Notas">
          <TextArea value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Levar o aparador de sebes." />
        </Field>
        <div className="flex flex-col gap-2 sm:flex-row">
          <Button variant="secondary" onClick={onClose}>
            Cancelar
          </Button>
          {!task ? (
            <Button variant="soft" disabled={busy} onClick={() => submit(true)}>
              Guardar e outra
            </Button>
          ) : null}
          <Button type="submit" className="sm:ml-auto" disabled={busy}>
            {busy ? "A guardar…" : "Guardar"}
          </Button>
        </div>
      </form>
    </Sheet>
  );
}

export function LogSheet({
  open,
  task,
  onClose,
}: {
  open: boolean;
  task: Task | null;
  onClose: () => void;
}) {
  const { snap, saveLog } = useWorkspace();
  const [minutes, setMinutes] = useState("");
  const [serviceType, setServiceType] = useState("");
  const [materials, setMaterials] = useState("");
  const [notes, setNotes] = useState("");
  const [photos, setPhotos] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);

  const user = useCurrentUser();
  const existing = snap?.logs.find((log) => log.taskId === task?.id && log.userId === user?.id);

  useEffect(() => {
    if (!open || !task) return;
    const mine = snap?.logs.find((log) => log.taskId === task.id && log.userId === user?.id);
    setMinutes(mine?.minutes != null ? String(mine.minutes) : "");
    setServiceType(mine?.serviceType ?? "");
    setMaterials(mine?.materials ?? "");
    setNotes(mine?.notes ?? "");
    setPhotos([]);
  }, [open, task, snap?.logs, user?.id]);

  return (
    <Sheet open={open} title="Registo do trabalho" onClose={onClose}>
      <p className="mb-4 text-sm text-muted">
        Opcional. Serve para ficar o rasto do que foi feito em {task?.title ?? "esta tarefa"}.
        {existing?.photoCount ? ` Já há ${existing.photoCount} foto(s).` : ""}
      </p>
      <form
        className="space-y-4"
        onSubmit={(event) => {
          event.preventDefault();
          if (!task) return;
          setBusy(true);
          void saveLog({
            taskId: task.id,
            minutes: minutes === "" ? null : Number(minutes),
            serviceType,
            materials,
            notes,
            photos,
          }).then((ok) => {
            setBusy(false);
            if (ok) {
              toast.success("Registo guardado");
              onClose();
            }
          });
        }}
      >
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Tempo (minutos)">
            <input className={fieldClass} inputMode="numeric" value={minutes} onChange={(e) => setMinutes(e.target.value)} placeholder="90" />
          </Field>
          <Field label="Tipo de serviço">
            <select className={fieldClass} value={serviceType} onChange={(e) => setServiceType(e.target.value)}>
              <option value="">Não indicar</option>
              {SERVICE_TYPES.map((item) => (
                <option key={item} value={item}>
                  {SERVICE_LABEL[item]}
                </option>
              ))}
            </select>
          </Field>
        </div>
        <Field label="Materiais">
          <input className={fieldClass} value={materials} onChange={(e) => setMaterials(e.target.value)} placeholder="Adubo, tutor, saco de relva" />
        </Field>
        <Field label="Notas">
          <TextArea value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="O que ficou feito, o que falta, alguma avaria." />
        </Field>
        <Field label="Fotos">
          <input
            className="block w-full text-sm text-muted file:mr-3 file:h-11 file:rounded-lg file:border-0 file:bg-leaf-soft file:px-3 file:font-semibold file:text-leaf"
            type="file"
            accept="image/*"
            multiple
            onChange={(event) => {
              const files = [...(event.target.files ?? [])].slice(0, 4);
              event.target.value = "";
              void Promise.all(files.map((file) => compressImage(file)))
                .then((urls) => setPhotos((current) => [...current, ...urls].slice(0, 4)))
                .catch((err: unknown) => {
                  toast.error(err instanceof Error ? err.message : "Foto inválida");
                });
            }}
          />
          {photos.length ? (
            <span className="mt-2 flex gap-2">
              {photos.map((src) => (
                <img key={src.slice(0, 48)} src={src} alt="" className="h-16 w-16 rounded-lg object-cover" />
              ))}
            </span>
          ) : null}
        </Field>
        <Button type="submit" className="w-full" disabled={busy || !task}>
          {busy ? "A guardar…" : "Guardar registo"}
        </Button>
      </form>
    </Sheet>
  );
}
