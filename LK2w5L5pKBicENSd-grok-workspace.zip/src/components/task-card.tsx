import { useState } from "react";
import { CalendarClock, Check, Pencil, RotateCcw, Trash2 } from "lucide-react";
import { dayLabel, STATUS_LABEL } from "@/lib/garden/format";
import type { Member, Task } from "@/lib/garden/types";
import { Avatars, Button, cx, fieldClass, Pill } from "./ui";

export function TaskCard({
  task,
  gardenName,
  members,
  showDate,
  onDone,
  onPostpone,
  onEdit,
  onLog,
  onDelete,
}: {
  task: Task;
  gardenName?: string;
  members: Member[];
  showDate?: boolean;
  onDone: () => void;
  onPostpone: (date: string) => void;
  onEdit: () => void;
  onLog: () => void;
  onDelete: () => void;
}) {
  const [when, setWhen] = useState(task.scheduledDate);
  const [openDate, setOpenDate] = useState(false);
  const [confirm, setConfirm] = useState(false);
  const done = task.status === "feita";
  const moved = Boolean(task.postponedFrom) && !done;

  return (
    <article className="rounded-xl border border-line bg-card p-4">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          {gardenName ? <p className="text-xs font-semibold tracking-wide text-leaf uppercase">{gardenName}</p> : null}
          <h3 className={cx("font-display text-xl text-ink", done && "text-muted line-through decoration-line")}>
            {task.title}
          </h3>
          <p className="mt-1 text-sm text-muted">
            {showDate ? dayLabel(task.scheduledDate) : null}
            {showDate && task.notes ? " · " : null}
            {task.notes || (!showDate ? "" : "")}
          </p>
        </div>
        <div className="flex shrink-0 flex-col items-end gap-1">
          <Pill tone={done ? "leaf" : moved ? "clay" : "muted"}>{done ? STATUS_LABEL.feita : moved ? "Adiada" : "Por fazer"}</Pill>
          <Avatars members={members} ids={task.assigneeIds} />
        </div>
      </div>
      {task.notes && !showDate ? <p className="mt-2 text-sm text-muted">{task.notes}</p> : null}
      <div className="mt-3 flex flex-wrap gap-2">
        <Button variant={done ? "secondary" : "primary"} onClick={onDone} className="h-10">
          {done ? <RotateCcw className="h-4 w-4" /> : <Check className="h-4 w-4" />}
          {done ? "Reabrir" : "Feita"}
        </Button>
        <Button variant="secondary" className="h-10" onClick={() => setOpenDate((v) => !v)}>
          <CalendarClock className="h-4 w-4" />
          Adiar
        </Button>
        <Button variant="ghost" className="h-10" onClick={onLog}>
          Registo
        </Button>
        <Button variant="ghost" className="h-10 px-3" onClick={onEdit} aria-label="Editar">
          <Pencil className="h-4 w-4" />
        </Button>
        <Button variant="ghost" className="h-10 px-3 text-clay" onClick={() => setConfirm(true)} aria-label="Eliminar">
          <Trash2 className="h-4 w-4" />
        </Button>
      </div>
      {openDate ? (
        <form
          className="mt-3 flex gap-2"
          onSubmit={(event) => {
            event.preventDefault();
            onPostpone(when);
            setOpenDate(false);
          }}
        >
          <input className={fieldClass} type="date" value={when} onChange={(e) => setWhen(e.target.value)} required />
          <Button type="submit">Mover</Button>
        </form>
      ) : null}
      {confirm ? (
        <div className="mt-3 flex items-center justify-between gap-3 rounded-lg bg-clay-soft px-3 py-2">
          <p className="text-sm text-clay">Eliminar esta tarefa?</p>
          <span className="flex gap-2">
            <Button variant="ghost" className="h-9" onClick={() => setConfirm(false)}>
              Não
            </Button>
            <Button variant="danger" className="h-9" onClick={onDelete}>
              Eliminar
            </Button>
          </span>
        </div>
      ) : null}
    </article>
  );
}
