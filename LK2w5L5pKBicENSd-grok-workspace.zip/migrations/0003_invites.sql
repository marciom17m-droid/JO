-- Convites por email. A primeira conta abre a equipa; as seguintes só entram
-- se o email estiver aqui. Qualquer membro pode convidar. Não há administradores.

create table if not exists invites (
  email text primary key,
  invited_by text not null,
  created_at timestamptz not null default now()
);
