-- Jardins e outros — dados partilhados da equipa.
-- Qualquer conta autenticada lê e escreve (não há papéis de admin).
-- A identidade de quem age vem sempre da sessão, nunca de um id enviado pelo cliente.

create table if not exists gardens (
  id text primary key,
  name text not null,
  location text not null default '',
  notes text not null default '',
  status text not null default 'ativo',
  created_by text not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists garden_photos (
  id text primary key,
  garden_id text not null references gardens (id) on delete cascade,
  data_url text not null,
  created_by text not null,
  created_at timestamptz not null default now()
);

create table if not exists tasks (
  id text primary key,
  garden_id text references gardens (id) on delete set null,
  title text not null,
  scheduled_date date not null,
  status text not null default 'agendada',
  notes text not null default '',
  postponed_from date,
  created_by text not null,
  completed_by text,
  completed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists task_assignees (
  task_id text not null references tasks (id) on delete cascade,
  user_id text not null,
  primary key (task_id, user_id)
);

create table if not exists work_logs (
  id text primary key,
  task_id text not null references tasks (id) on delete cascade,
  user_id text not null,
  minutes integer,
  service_type text not null default '',
  materials text not null default '',
  notes text not null default '',
  created_at timestamptz not null default now(),
  unique (task_id, user_id)
);

create table if not exists work_photos (
  id text primary key,
  work_log_id text not null references work_logs (id) on delete cascade,
  data_url text not null,
  created_at timestamptz not null default now()
);

create table if not exists availability (
  user_id text not null,
  day date not null,
  morning boolean not null default false,
  afternoon boolean not null default false,
  primary key (user_id, day)
);

create index if not exists tasks_date_idx on tasks (scheduled_date);
create index if not exists tasks_garden_idx on tasks (garden_id);
create index if not exists availability_day_idx on availability (day);
create index if not exists garden_photos_garden_idx on garden_photos (garden_id);
